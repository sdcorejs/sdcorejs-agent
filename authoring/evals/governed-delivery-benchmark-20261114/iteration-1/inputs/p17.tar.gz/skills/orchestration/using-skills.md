---
name: sdcorejs-using-skills
description: Session bootstrap and dispatch for sdcorejs skills. Use at session start, onboarding/help/list-skill requests, or matching skill intent. Routes Q&A, bounded fast-fixes and governed execution with approval, verification and finish gates. Runtime-localized.
required-actions: artifact.read, artifact.write, context.pass, verification.run, user.choose
---

# Using sdcorejs Skills

Read `_refs/shared/session-authority.md` before classification or any approval/finish
transition. Reuse scoped session authority; preserve unresolved risk decisions.

## Bootstrap

Match descriptions before reading skill bodies. Load
`_refs/shared/runtime-protocols.md`, then only task-relevant references.
Current instructions/evidence override stored context. Resolve route semantics
from `_refs/shared/system-registry.json`; read needed fields.

Priority when several skills match:

1. Explicit skill named by the user.
2. Approved plan: `sdcorejs-subagent-driven-development` for explicit
   delegation; otherwise `sdcorejs-execute-plan`.
3. Social editorial work: `sdcorejs-content` (brief through draft/review; no
   engineering artifact chain or publishing authority). Product, design, and direct test work: `sdcorejs-product`,
   `sdcorejs-design`, `sdcorejs-test`; failing-test diagnosis uses
   `sdcorejs-debug`.
4. Dedicated intent: `sdcorejs-cleanup`, `sdcorejs-simplify`, `sdcorejs-explore`,
   `sdcorejs-documentation`, `sdcorejs-review`, `sdcorejs-repair-loop`,
   `sdcorejs-debug`, `sdcorejs-ship`, or `sdcorejs-git`.
5. Confirmed implementation: `sdcorejs-ai-agent`, `sdcorejs-angular`,
   `sdcorejs-nestjs`, or `sdcorejs-nextjs`.
6. Open-ended, ambiguous, or under-specified change:
   `sdcorejs-brainstorming`.

## Entry Gate

Choose one path before loading a full workflow:

- Pure Q&A with no authorized write: answer directly.
- UI work selects topics via `_refs/design/uiux/index.md`; backend/Q&A load none.
- Small, explicit, low-risk fix: targeted context, smallest scoped edit,
  focused verification, and concise review. Behavior, acceptance criteria,
  ownership, and verification must already be bounded.
- Ambiguous, architectural, cross-cutting, security-sensitive, destructive,
  concurrency-sensitive, or public-contract change: full workflow.

`implement`, `build` and `create` express write intent, not spec or plan approval.
Apply the selected entry criteria and required artifacts regardless of wording;
a fixture, lab, benchmark, disposable repository or scoped prompt never waives
a required approval gate or artifact.

A non-trivial implementation request without a valid approved plan must
route to `sdcorejs-brainstorming`; it is not confirmed implementation. Do not load a track
executor as an escape from the governed workflow.

Fast-fix excludes flaky/root-cause work or inferred behavior. Scope, ownership,
risk or public behavior growth returns to brainstorming. Working-tree safety,
artifact lifecycle, evidence and required finish gates still apply.

## Governed Workflow

```text
brainstorming
  -> spec (explicit approval + immutable approved snapshot)
  -> plan (explicit approval + immutable approved snapshot)
  -> execute-plan (track detection + execution policy)
  -> delegated or parent executor/generic harness
  -> finish gate and mandatory tail
```

Silence is never spec or plan approval; ambiguous/unconfirmed scope cannot
generate code. Product/design/test/AI-agent stay first-class; unsupported
stacks use the generic execute-plan harness.

`sdcorejs-subagent-driven-development` owns approved-plan delegation.
Debug/review/explore assess 2+ substantial independent read-only domains via
`sdcorejs-parallel-dispatch` without parallel wording. Owner hooks retain
authority, execution-choice and non-recursion gates.

## Invariants

- Run current verification before claiming pass, fixed, built, or done.
- Apply `_refs/harness/communication-economy.md` just in time for response
  profiles, progress, runtime-context handoff, or related-artifact selection.
  Default routine output to compact professional sentences; expand for
  approval, security, destructive action, ambiguity, failure, or blockers.
- Keep authoritative typed context available to its exact consumer without
  echoing it to the user. When `runtime_context_channel` is unsupported or
  unknown, use the validated portable handoff for `context.pass`.
- Keep live progress in the runtime, never in `.sdcorejs/**` session files.
- Every durable `.sdcorejs/**` producer propagates `artifact_context`.
- Finish gates, verification-before-done, and no-writes-after-branch-ready stay
  mandatory where the selected workflow requires them.
- Open user choices, including direct Design: apply
  `_refs/sdlc/visual-offer-policy.md` before deciding; preserve `visual_companion`
  across routing. Fixed work needs no visual loading or invitation.
- Use `_refs/shared/user-choice-prompt.md` only for real decisions. Supported
  native interaction may be used, but numbered Markdown is always available.
- Match the user's language at runtime; keep reusable skill/reference prose and
  identifiers in English.
- Do not add scope, dependencies, migrations, environment changes, commits,
  pushes, tags, releases, or new skills without the authority required by the
  selected contract.
- Keep `track` (workflow/executor), `stack_profile` (stack), `capability_profile`
  (approved domain), `repository_role` (topology),
  `artifact_owner_repository_id` (durable artifact write owner) and
  `execution_host_repository_id` (execution host/coordinator) separate.
  Never infer artifact ownership from the current working directory.
- Resolve aliases and unsupported stacks through
  `_refs/shared/system-registry.mjs`. Unknown stacks use the declared generic
  harness fallback; unknown runtime capabilities use the portable fallback
  from the capability contract.

## Track Map

This display is checked deterministically against
`_refs/shared/system-registry.json`; consumers resolve the registry rather than
copying this table into durable artifacts.

| Canonical track | Executor |
|---|---|
| `ai-agent` | `sdcorejs-ai-agent` |
| `angular` | `sdcorejs-angular` |
| `design` | `sdcorejs-design` |
| `documentation` | `sdcorejs-documentation` |
| `fullstack` | `sdcorejs-execute-plan` generic harness |
| `general` | `sdcorejs-execute-plan` generic harness |
| `nestjs` | `sdcorejs-nestjs` |
| `nextjs` | `sdcorejs-nextjs` |
| `node` | `sdcorejs-execute-plan` generic harness |
| `product` | `sdcorejs-product` |
| `react` | `sdcorejs-execute-plan` generic harness |
| `test` | `sdcorejs-test` |
| `workflow` | `sdcorejs-execute-plan` generic harness |

Output/asset/doc hygiene -> `sdcorejs-cleanup` (default read-only); offers grant
analysis only. Load `_refs/cleanup/workflow.md` for exact mutation authority.
Source refinement -> `sdcorejs-simplify`; test/data teardown -> `sdcorejs-test`;
quality review -> `sdcorejs-review`.

Broad simplification/refactor, under-specified AI-agent work, or unapproved
production SDLC expansion returns to brainstorming. Project summary/code-map
work belongs to `sdcorejs-explore`; documentation does not own project context.

Consistency and convention intent - "consistency review", "review naming
consistency", "review API conventions", singular/plural or casing drift - routes
to `sdcorejs-review` with the `consistency` dimension. Review stays read-only.
Reading or persisting `.sdcorejs/conventions/**` belongs to `sdcorejs-explore`
(`conventions-read` and `conventions-sync-write-approved`); `sdcorejs-git` never
generates or updates conventions.

Keep the risk baseline in `_refs/shared/finish-gate.md` on fast-fix paths.
