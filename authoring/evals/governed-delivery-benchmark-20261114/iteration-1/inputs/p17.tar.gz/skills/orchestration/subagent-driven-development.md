---
name: sdcorejs-subagent-driven-development
description: Execute an approved plan through fresh, bounded worker contexts. Use when the user explicitly asks to delegate, use subagents, split an approved plan across agents, run a worker fleet, or when execute-plan selects delegated execution for two or more substantial units. Supports safe parallel waves and sequential fresh-worker fallback. Runtime-localized.
required-actions: artifact.read, artifact.write, context.pass, verification.run, progress.create, progress.update, agent.dispatch, agent.resume, agent.interrupt, workspace.isolate
---

# Subagent-Driven Development

## Purpose

Own how an approved plan is executed through fresh worker contexts. Keep worker
context isolation, unit review, owner-scoped repair, and deterministic fan-in
consistent whether ready units run concurrently or one at a time.

`sdcorejs-parallel-dispatch` is the low-level safety scheduler: it decides which
ready units may overlap and enforces path, resource, workspace, failure, and
fan-in rules. This skill owns the higher-level development lifecycle around that
decision. Do not rename or duplicate the scheduler.

## Preconditions

For write-capable work, require an immutable approved plan and a verified
`plan_context`. A direct request to delegate unapproved implementation returns
to `sdcorejs-plan`; it is not a planning bypass. Read-only parallel reviews or
audits route directly to `sdcorejs-parallel-dispatch`.

A missing, stale, or legacy project summary is not a gate. Continue with targeted
source reads or a scoped code map before dispatch, and never infer missing facts.

Read these references completely before dispatch:

- `_refs/shared/runtime-protocols.md`
- `_refs/harness/runtime-attestation.md`
- `_refs/harness/delegation-policy.json`
- `_refs/harness/task-brief.md`
- `_refs/orchestration/parallel-protocol.md`
- `_refs/orchestration/workspace-isolation.md` for write-capable isolated units

Use `_refs/harness/runtime-attestation.mjs` for current-session capability
evidence and `compileParallelContext` from
`_refs/orchestration/parallel-protocol.mjs` for the dependency waves and
parallel opportunity report.

## Execution workflow

### 1. Verify and compile

1. Verify approved spec/plan identity, source revision, repository ownership,
   allowed/prohibited paths, dependency/env/migration boundaries, and working
   tree state exactly as `sdcorejs-execute-plan` requires.
2. Attest delegation, concurrent dispatch, worker-CWD binding, native/manual
   worktree support, cancellation, result refs, and effective maximum
   concurrency from current-session evidence. Unknown stays unknown.
3. Compile compact `parallel_candidates.units` into dependency waves and the
   opportunity report. Complete workspace, dispatch-envelope, integration,
   verification, failure, and final-tail fields before any write dispatch.
4. Preserve the approved `execution_policy`:
   - `parallel-preferred` selects safe concurrent waves and degrades safely;
   - `sequential` uses sequential fresh workers;
   - `auto` selects concurrent waves only when the report proves positive
     benefit and every safety gate passes.

### 2. Choose the execution path

Apply this fallback order without collapsing delegation into parallelism:

1. **Parallel fresh workers** when delegation and concurrency are attested, the
   current wave has at least two ready units, ownership/resources are disjoint,
   and workspace strategy is safe.
2. **Sequential fresh workers** when delegation is supported but concurrency,
   isolation, dependency readiness, or overlap safety blocks parallelism.
3. **Parent execution** only when delegation is unsupported/unknown or worker
   dispatch fails before a unit starts.

Do not repeatedly ask sequential-versus-parallel after the plan has an approved
execution policy. A missing policy uses the existing explicit-choice contract.

### 3. Dispatch fresh bounded workers

Create one fresh worker context for each ready implementation unit. Pass only
the bounded task brief, contract and artifact references, owned/readable paths,
do-not-touch paths, dependencies, acceptance criteria, verification commands,
expected output, semantic model tier, workspace identity, and escalation
conditions.

Workers must not spawn more workers, approve or mutate plan/spec artifacts,
change shared durable context, cross Git roots, alter unowned paths, or create
Git artifacts. Git mutations are deny. The integration owner creates any
immutable result snapshot only after mechanically validating the worker diff.

Wait for the current wave, record immutable result identity and current
verification evidence, then unlock dependent units. Do not dispatch a dependent
unit from optimistic status or commentary. Respect attested maximum concurrency.

### 4. Review each unit twice

For every implemented unit:

1. **Stage A - contract compliance.** A fresh reviewer checks the exact plan
   step, acceptance criteria, allowed/prohibited paths, and missing or extra
   behavior. Repair blocking Stage A findings before continuing.
2. **Stage B - quality and maintainability.** A separate fresh reviewer checks
   correctness, security, tests, clarity, and repository conventions only after
   Stage A passes.

Reviewer claims do not replace tests or mechanical boundary validation. A unit
is fan-in eligible only when path validation, unit verification, Stage A, and
Stage B are current for the same result identity.

### 5. Repair, integrate, and verify

Return a valid finding to the original unit through owner-scoped repair in the
same workspace. A new worker may take over only through an explicit ownership
transfer. Any repair invalidates prior unit and review evidence.

Invoke `sdcorejs-parallel-dispatch` for deterministic fan-in. Integrate in the
approved order, validate every immutable ref or exact diff, probe after each
application, run global verification on the integrated state, then execute the
mandatory finish and final read-only branch-ready gates. `sdcorejs-git` may run
only after fan-in and current ship evidence; workers must not commit, push, or
open pull requests.

## Runtime output

Emit a compact `delegated_execution_context` containing:

```yaml
delegated_execution_context:
  schema_version: 1
  approved_plan_ref: <path and approval hash>
  runtime_attestation: <validated runtime-only reference>
  execution_policy: auto | sequential | parallel-preferred
  selected_mode: parallel | delegated-sequential | parent-sequential
  opportunity_report: <runtime-only reference>
  waves: []
  unit_results: []
  stage_a: []
  stage_b: []
  repairs: []
  integration_result: pending | blocked | verified
  global_verification: pending | failed | passed
  final_tail: pending | blocked | passed
```

Keep raw prompts, logs, diffs, and mutable progress in the harness. Pass the
full typed context through `context.pass`; show the user only meaningful mode,
progress, blockers, evidence, and final result.

## Stop conditions

Stop new dispatch when contract identity changes, a worker crosses ownership,
the base becomes stale, an unapproved dependency/env/migration change appears,
capability evidence becomes invalid, or fail-fast policy triggers. Report
in-flight work honestly: without proven cancellation, already-started units may
still finish and must not be described as cancelled.

## Cross-references

- `sdcorejs-execute-plan` - verifies the approved plan and selects this lifecycle
- `sdcorejs-parallel-dispatch` - low-level scheduler, safety verdict, and fan-in
- `sdcorejs-repair-loop` - validates and executes selected owner-scoped repairs
- `sdcorejs-ship` - current verification and final branch readiness
- `sdcorejs-git` - post-fan-in Git artifacts only
