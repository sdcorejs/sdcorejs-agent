---
name: sdcorejs-git
description: Git artifact workflow. Use for commit/save changes, create PR, push verified branch, changelog, release notes, diff since tag, or PR text. An explicit worktree request is a compatibility handoff to the orchestration workspace-isolation contract, not a Git artifact mode. Do not use for readiness/ship gates; use sdcorejs-ship first. Runtime-localized.
required-actions: artifact.read, artifact.write, context.pass, verification.run, user.choose, user.approve
---

# Git

Read `_refs/shared/git-disposition.md` and `_refs/shared/session-authority.md`
before artifact handoff. Keep acceptance disposition separate from hygiene.

## Purpose

One skill for Git artifacts:

- create a scoped Conventional Commit
- push a verified branch
- open or update a pull request
- write release notes or CHANGELOG entries

Readiness and final delivery gates live in `sdcorejs-ship`.

`sdcorejs-git` creates artifacts only. It is not the readiness gate, it must not
repair source files, and it must not create commits, pushes, or PRs as a
substitute for verification.

## Shared Protocols

Read `_refs/shared/runtime-protocols.md`. Apply
`_refs/shared/artifact-lifecycle.md` and run SDCoreJS Artifact Closure before staging, commit, or push. For multiple worktrees, nested repositories, or
submodules, load `_refs/shared/git-closure-contract.mjs`; it verifies approved artifacts, emits exact repository-local path sets, and delegates freshness to
`_refs/shared/convergence-contract.mjs#evaluateConvergenceHandoff` with its verified receipt.

## Mode Selection

| Mode | Trigger examples | Output |
|---|---|---|
| `commit` | "commit", "commit changes", "save changes" | one scoped Conventional Commit |
| `pr` | "create PR", "open PR", "gh pr create", "PR text" | pushed current branch plus PR URL or local PR draft |
| `changelog` | "write changelog", "update CHANGELOG", "release notes", "what changed since vX.Y.Z" | Keep a Changelog entry plus semver recommendation |

If multiple modes match, choose the narrowest explicit artifact request:
`commit`, `pr`, and `changelog` are artifact modes; readiness,
delivery, dependency updates, release readiness, and "is this ready" belong to
`sdcorejs-ship`.

An explicit worktree/isolation request is not an artifact mode. Forward it to
the canonical `workspace.isolate` owner in
`_refs/orchestration/workspace-isolation.md`, then return the resulting
workspace identity to the execution caller. Do not perform commit, PR, push, or
changelog work during that handoff.

## Mode Precedence Guard

Before any artifact mode, classify the user's intent.

Delegate to `sdcorejs-ship` first when the prompt includes readiness or delivery
intent such as ship, ready, done, push, merge, release, create PR, open PR,
submit PR, or ready to merge and current ship evidence is missing or stale for
the current `HEAD` or diff.

Use the shared Git disposition table for every artifact action. Artifact-only
intent is authorization for that action, not an exemption from read-only hygiene
or artifact closure. Verified delivery consumes current Ship evidence; explicit
acceptance deferral permits only the table's local/draft actions with a risk note.

When `ship_context` is available, consume it before artifact creation. Git
handoff is allowed only when `ship_context.git_handoff_allowed` is true, the
`associated_HEAD_or_diff` matches the current `HEAD` or dirty diff,
`writes_after_branch_ready` is empty, and `branch_ready_evidence` is current.
For governed-plan delivery, missing, blocked, deferred, or stale convergence always refuses handoff; so does unreceipted, vacuous, or plan-mismatched convergence.
When cleanup occurred, pass the exact runtime `cleanup`, mapped `evidence`, and
`branch_ready_cleanup_receipt_ids` to repository closure. Apply and restore have
separate sealed event identities; stale or unverified cleanup blocks staging.

Do not create commits, pushes, or PRs as a substitute for verification. If the
prompt is delivery-oriented and evidence is absent or stale, stop and delegate:
"Run `sdcorejs-ship` first so verify-before-done and branch-ready evidence can
be tied to the current `HEAD` or diff."

## Mode-Specific Write Boundaries

- `commit` mode may inspect, stage explicit included paths, and create a commit. It must not edit source files.
- `pr` mode may push the current branch and create or update PR text after gates pass. It must not edit source files.
- `changelog` mode may edit `CHANGELOG.md`, release note files, or repo-defined release artifact files only when the user explicitly requested changelog or release-note work and the scope is clear.
- No mode may auto-run source formatting, mirror sync, code generation, or patch fixes unless the user explicitly requested that operation or the verified caller delegated a known artifact sync step.
- If mirror sync is required by repo policy, report that source and mirrors are out of sync and delegate to the appropriate sync/test workflow. Do not silently edit generated mirrors.

## Shared Pre-Flight

Run relevant read-only checks first:

```bash
git rev-parse --show-toplevel
git branch --show-current
git rev-parse HEAD
git status --short
git remote -v
```

Protected branches are hard stops for commit, PR, and push modes:

- `main`
- `master`
- `trunk`
- `production`
- `stable`
- `release/*`
- any repo- or user-named protected branch convention

Never commit directly from main, master, trunk, production, stable, or
release/* by default. Never create a PR directly from those branches. Do not ask
the user whether to continue directly on a protected branch.

Offer only safe choices:

1. Create a feature branch and continue.
2. Create an isolated worktree.
3. Stop.

There is no continue on protected branch option.

If a repo has a different protected branch convention, let the user name it,
record it in the ledger, and still refuse direct commit, PR, or push from that
protected branch.

## Secret Redaction Protocol

Run secret screening before printing diff details, commit messages, PR bodies,
or changelog excerpts.

Rules:

- Never echo secret values from `.env`, local config, CI files, shell output, source files, Git diffs, or grep output.
- Never print full lines that contain likely secret values.
- If a command would print secret values, do not run it; use redacted summaries instead.
- For suspected secret findings, report only file path, line number if available, key or category name, reason it is risky, and redacted evidence such as `API_KEY=[REDACTED]`.
- Do not include secret values in commit messages, PR bodies, changelog entries, release notes, or final summaries.
- If suspected secrets are staged or inside the PR diff, stop before commit or PR and require remediation.

## SDCoreJS Artifact Closure

Run this read-only workflow before staging, commit, or any push:

```bash
git status --short -- .sdcorejs
git diff --name-status -- .sdcorejs
git diff --cached --name-status -- .sdcorejs
```

Use `_refs/shared/artifact-lifecycle.md` as the normative contract. When the
mirrored helper is available, the following produces a deterministic
classification without staging:

```bash
node <skill-pack-root>/_refs/shared/artifact-lifecycle.mjs \
  --root <target-root> \
  --change-ref <change-ref> \
  --mode <commit-or-push>
```

Do not print artifact contents during discovery. Consume the caller's
`artifact_context` first. When Git is invoked from a new thread, reconstruct
the closure from artifact frontmatter, `source_spec`, `source_plan`,
`change_ref`, current Git diff, explicit user scope, and repository
conventions.

Classify every changed `.sdcorejs/**` path:

- `required_with_change`;
- `shared_owned`;
- `conditional`;
- `local_only`;
- `unrelated`;
- `unknown`.

Rules:

1. Automatically include `required_with_change`.
2. Include `shared_owned` only when the current workflow or integration role
   proves ownership.
3. Include `conditional` only when both its condition and ownership are proven.
   In particular, do not generate or edit `.sdcorejs/summary.md`; include an
   existing summary change only when the current workflow owns a valid refresh.
4. Exclude `local_only` and `unrelated`.
5. Block when a required artifact is missing.
6. Return `ambiguous` and stop when an unknown artifact may belong to the
   change.
7. Screen included paths for secrets and PII without printing values.
8. Stage only the explicit `included_paths`.
9. Never use dot-all staging, all-index staging, or directory-wide
   `.sdcorejs` staging.
10. After commit, verify that no required artifact owned by the change remains
    outside the commit.

For multi-root, thread, worktree, nested-repository, or submodule changes, the
repository-local helper output is normative. Bind and verify owner, active
contract/plan, approval hash, source/evidence revision, and exact paths per Git
root. Module and portal closure/commit units stay independent; parents never
stage nested content, and stage a gitlink only with active-plan approval.
Exclude other-thread/worktree/owner, unrelated, local-only, secret, stale, and
unknown paths. Never create or stage either `.sdcorejs/current-session.md` or
`.sdcorejs/tasks/current-session.md`; the direct ledger reference has details.

When closure is complete, do not ask the user whether to include each required
spec, plan, execution doc, feature ledger, or approved documentation asset.
The request to commit the change already covers those artifacts.

For parallel writes, closure runs only after deterministic fan-in. A worker
cannot run Git artifact creation for its partial unit.

## Commit Scope Ledger

Before staging or commit, read `_refs/shared/git-commit-scope.md` completely
and show its visible Commit Scope Ledger. At minimum preserve this ownership
projection:

```yaml
Commit Scope Ledger:
  branch:
  current_HEAD:
  staged_paths:
  unstaged_paths:
  untracked_paths:
  included_paths:
  excluded_dirty_paths:
  sdcorejs_artifacts: {closure_result: complete | incomplete | ambiguous}
  secret_scan_result:
  ship_evidence: {associated_HEAD_or_diff:}
  branch_ready_evidence: {result:, associated_HEAD_or_diff:}
  commit_type:
  commit_scope:
  commit_message_preview:
```

Use explicit path staging only. Never use dot-all staging or all-index staging flags.
Do not sweep unrelated work into the ledger or treat `.sdcorejs/**` as one
staging unit. The full dirty-tree, generated-mirror, docs/task, and ambiguity
rules live in the reference.

Documentation preferences are project artifacts. When a commit or PR includes
work that used or changed saved documentation settings, include
`.sdcorejs/documentation/**` with the same feature change unless the user
explicitly asks for a separate commit. Do not treat these files as disposable
session state.

## Verification Evidence Rules

- Feature/source-code commits should have current `sdcorejs-ship (verify-before-done mode)` and `sdcorejs-ship (branch-ready mode)` evidence tied to the current `HEAD` or diff.
- If `ship_context.writes_after_branch_ready` is non-empty, branch-ready evidence
  is stale and Git artifacts must wait until branch-ready runs again.
- When `sdcorejs-test` emitted current `test_context` or `test_evidence`, include that test evidence in commit/PR verification notes when relevant.
- Consume independent `test_status` fields; written tests are not execution
  evidence, and a run is not a pass unless its result and current
  `associated_HEAD_or_diff` say so.
- Treat browser `storageState`/auth state, traces, videos, raw reports, and
  diagnostic screenshots as `local_only`; exclude them even when generated by
  a verified run.
- Include a verified guide screenshot or other documentation asset only when
  its `ui_capture_context` is current, PII-safe, hashed, referenced by the
  changed guide, passes Layout v2 containment, and is `required_with_change`.
- If capture provenance or artifact ownership is unknown or ambiguous, stop
  closure instead of guessing or staging the file.
- When `sdcorejs-debug` emitted current redacted `debug_context`, include the
  root cause, repro status, regression verification, and ship handoff summary
  only after ship and branch-ready evidence is current.
- Docs-only, prompt-only, or chore-only commits may not need full product acceptance verification, but they still need appropriate hygiene checks and a clear verification note.
- A stale verification run from before the current diff is not sufficient.
- If verification is deferred, do not present the commit or PR as verified.
- If verification is deferred or not applicable, include one of these exact lines in the commit body or final summary:
  - `Verification: deferred by user`
  - `Verification: not applicable, docs-only change`
- PR mode requires current verify-before-done and branch-ready evidence unless the PR is documentation-only or the user accepts an unverified draft with a clear warning.

## Mode: commit

1. Inspect:

```bash
git branch --show-current
git rev-parse HEAD
git status --short
git diff --stat
git diff --staged --stat
git diff --staged --name-status
git log -5 --oneline
```

2. Apply the protected branch hard stop before staging or committing.
3. Run the secret redaction protocol before printing diff details.
4. Run SDCoreJS Artifact Closure and stop on `incomplete` or `ambiguous`.
5. Build and show the Commit Scope Ledger.
6. Stop or ask when:
   - no staged, unstaged, or untracked changes exist;
   - changes span unrelated concerns;
   - suspected secrets are present;
   - generated mirrors are stale;
   - feature readiness has not passed through `sdcorejs-ship` for the current `HEAD` or diff and has not been explicitly deferred;
   - `.sdcorejs/documentation/**` changed but is outside the requested feature commit scope.
7. Stage only explicit included paths, including the resolved required
   `.sdcorejs/**` closure, when staging is needed.
   For multiple repositories, execute each repository's exact staging commands
   from its own Git root; never run parent staging over nested module content.
8. Infer Conventional Commit type from included paths and change summary, not from excluded dirty files.
9. Use a scope when obvious from module, package, or skill name.
10. Write a multi-line message to a UTF-8 temporary file owned by the current
    run, then commit with `git commit -F <message-file>`. Remove only that exact
    temporary file after the command finishes.
11. Verify with `git status --short`, `git log -1 --stat`, and a second artifact
    closure check that proves no task-owned required artifact remains
    uncommitted.

Conventional Commit format:

```text
<type>(<scope>): <imperative subject>
```

Types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`, `perf`, `ci`,
`build`, `style`, `revert`.

Scope hints:

- `skills/tracks/angular/` -> `angular`
- `skills/tracks/design/` -> `design`
- `skills/tracks/test/` -> `testing`
- `skills/shared/workflow/git.md` -> `git`
- `skills/shared/workflow/ship.md` -> `ship`
- `skills/shared/workflow/review.md` -> `review`
- `skills/shared/` -> `shared`
- `skills/orchestration/` -> `orchestration`
- `_refs/orchestration/` -> `orchestration`
- `.github/` -> `github`
- `.claude/` -> `claude`
- mixed concerns -> omit scope or use the smallest honest shared parent

Commit message bodies may include concise verification status:

```text
Verification: <pm> run test; <pm> run lint
Verification: deferred by user
Verification: not applicable, docs-only change
```

Do not claim tests passed unless they actually ran and passed. Do not include
secret values or huge generated summaries.

## Mode: pr

PR mode must use explicit base and range commands.

Required flow:

1. Detect `gh` with the current shell's command-lookup mechanism; do not assume
   a POSIX shell.
2. Run `gh auth status`.
3. If `gh` is missing or unauthenticated, do not attempt `gh repo view` or `gh pr create`; generate a local PR title/body draft and stop with manual instructions.
4. Run `git branch --show-current`.
5. Apply the protected branch hard stop.
6. Run `git status --short`; require a clean tree unless the user explicitly asked for draft/manual PR instructions only.
7. Require current verify-before-done and branch-ready evidence unless docs-only or explicitly deferred.
8. Resolve the default branch explicitly:

```text
gh repo view --json defaultBranchRef -q .defaultBranchRef.name
git fetch origin <resolved-base> --quiet
git log --no-merges origin/<resolved-base>..HEAD --pretty=format:<hash-and-subject-format>
git diff --stat origin/<resolved-base>...HEAD
git diff --name-status origin/<resolved-base>...HEAD
```

9. Stop if the branch has zero commits ahead of `origin/<resolved-base>`.
10. Stop or explain if the base cannot be resolved.
11. Detect existing PRs for the current branch before creating a new one:

```text
gh pr view --json number,url,title,baseRefName,headRefName
gh pr list --head <current-branch> --json number,url,title,baseRefName,headRefName
```

12. If an existing PR exists and the session already requested its update,
    update it within scope without another confirmation. Otherwise ask:
    `1. Update existing PR body` / `2. Create a new PR only if the platform allows and user confirms` / `3. Stop`.
13. Push only the current branch if needed, using the explicit branch name.
14. Write the PR body to a UTF-8 temporary file owned by the current run. Create
    with `gh pr create --body-file <body-file>` or update with the equivalent
    body-file option using existing scoped session authority, or after resolving an unapproved existing PR action or
    ambiguity. Remove only that exact temporary file afterward.

Never use unqualified two-dot or three-dot HEAD ranges in PR mode. Bind PR
commit and diff ranges to `origin/<resolved-base>..HEAD` and
`origin/<resolved-base>...HEAD`.

PR body requirements:

- Include a summary derived from `origin/<resolved-base>...HEAD`.
- Include change bullets from diff name/status or stat, not full diffs.
- Include verification evidence from `sdcorejs-ship`, branch-ready, docs-only rationale, or deferred verification warning.
- Include review/repair evidence when the PR came from a review/repair loop.
- Include risk and rollback notes when meaningful.
- Do not paste full diffs.
- Do not paste secret values or raw suspicious lines.
- If verification was deferred, mark the PR as unverified or draft and state the risk.

Suggested PR body sections:

- Summary
- Changes
- Verification
- Review/Repair evidence, if applicable
- Risks and rollback
- Notes for reviewer

For `ai_agent_context`, preserve redacted IDs/hashes/paths/evidence/deferrals; classify raw traces, serialized run state, prompts, tool payloads, approval tokens, provider responses, credentials, tenant data, and diagnostics as `local_only` or prohibited. For `simplify_context`, consume the final diff association and file list, but do not stage runtime-only `simplify_context`, temporary baselines/snippets, raw prompts, or sensitive evidence; require current ship and branch-ready evidence after every write.

## Push Safety

If pushing is part of PR or delivery:

- Run SDCoreJS Artifact Closure in `push` mode first. If a required spec, plan,
  execution doc, ledger, or approved documentation asset remains uncommitted,
  stop with `artifact closure incomplete`.
- Never force push.
- Never push protected branches directly.
- Push only the current branch.
- Use the explicit branch name.
- If upstream is missing, set upstream only after confirming branch name and remote.
- If remote is missing, stop and provide a local commit summary.
- If push fails due to non-fast-forward or permissions, stop; do not retry with force.
- Unrelated dirty changes from another thread do not by themselves block
  pushing the current commit when they are clearly classified, unstaged, and
  repository policy permits the push. Required, unknown, staged unrelated, or
  local-only artifact ambiguity still blocks.

## Mode: changelog

Read `_refs/orchestration/release-changelog.md` completely, then generate or
update release notes:

- inspect `git status --short` before writing;
- avoid mixing changelog edits with unrelated dirty source changes;
- locate the baseline from explicit user range, latest tag, latest `CHANGELOG.md` entry, or explicit base branch;
- read the real commit range with `git log --no-merges`;
- redact suspected secrets from commit bodies or diff-derived notes;
- classify Conventional Commits into Keep a Changelog sections;
- suggest the semver bump and explain the reason in chat;
- create a missing `CHANGELOG.md` when the user explicitly requested it;
  versioned release operations still require their matching authorization;
- surface untyped commits, breaking changes, and security-adjacent fixes for human review.

Do not tag, push tags, bump versions, create GitHub releases, or create release
artifacts beyond changelog/release-note files unless the user
explicitly requested and approved that release operation after verification.

## Release/Tag Safety

If release or tag behavior is mentioned:

- Do not create tags by default.
- Do not push tags by default.
- Do not bump versions by default.
- Do not create GitHub releases by default.
- Delegate release readiness to `sdcorejs-ship` or a dedicated release workflow when present.
- Only create release/tag artifacts after explicit user approval and clean verification evidence.

## Rules

### MUST DO

- Choose and state the mode before acting.
- Apply the mode precedence guard before artifact creation.
- Run current commands and read their output before claiming pass, fixed, built, ready, or done.
- Hard-stop protected branches for commit, PR, and push.
- Show the Commit Scope Ledger before staging or commit.
- Use explicit path staging only.
- Use current-run UTF-8 files plus `git commit -F` and PR body-file options for
  multi-line commit and PR bodies.
- Redact suspected secrets before printing evidence.
- Match the user's language for explanation; keep commands, branches, scopes, URLs, and env keys exact.

### MUST NOT

- Force-push.
- Commit, PR, or push directly from a protected branch.
- Offer any "continue on protected branch" path.
- Sweep unrelated files into a commit.
- Use dot-all or all-index staging shortcuts.
- Bypass `sdcorejs-ship` when the user asks whether work is ready.
- Tag, push tags, bump versions, or create releases without explicit approval.
- Edit source files from commit or PR mode.
- Print raw secret-bearing lines.

## Cross-References

- `sdcorejs-ship` - final gate, verify-before-done, branch readiness, release readiness
- `_refs/orchestration/workspace-isolation.md` - canonical orchestration owner for workspace/worktree isolation
- `_refs/orchestration/tail/branch-ready.md` - branch hygiene checklist
- `_refs/orchestration/release-changelog.md` - release notes and CHANGELOG workflow
