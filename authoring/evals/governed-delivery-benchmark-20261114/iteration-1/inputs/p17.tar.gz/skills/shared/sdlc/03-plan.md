---
name: sdcorejs-plan
description: Plan authoring and approval gate. Use after approved spec, or when the user asks to write/review/approve/change an implementation plan. Produces numbered file/task plans, self-reviews, resolves explicit approval or scoped session delegation, then persists the approved snapshot under .sdcorejs/plans/ before execute-plan. Applies across tracks. Runtime-localized.
required-actions: artifact.read, artifact.write, context.pass, verification.run, user.approve
---

# 03 - Plan
Read `_refs/shared/session-authority.md` before classification or any approval/finish
transition. Reuse scoped session authority; preserve unresolved risk decisions.

## Shared Protocols

Read `_refs/shared/runtime-protocols.md`. Draft and approved plan artifacts apply
`_refs/shared/artifact-lifecycle.md` and emit `artifact_context`. Resolve track,
profile, and repository semantics from `_refs/shared/system-registry.json`; use
`_refs/shared/approved-artifact.mjs` for approval identity and
`_refs/shared/decision-coverage.md` and its `.mjs` authority for schema-v2 coverage and goal-backward gates.
Read `_refs/sdlc/architecture.md`. From `_refs/shared/architecture-contract.mjs`, use
`validateArchitecturePrePlanHandoff` before drafting, `validateArchitectureDraftPlanHandoff`
for draft self-review, and `validateArchitecturePlanHandoff` only after approval and in execution.

Forward runtime `requirement_context.visual_companion` via `context.pass` (portable
`state_delta.visual_companion`); preserve identity, scopes, surface and
consent. Apply `_refs/sdlc/visual-offer-policy.md` for unresolved choices; never
persist runtime permission in approved artifacts or reopen settled choices.

## Purpose
Translate an authorized spec into the exact contract `sdcorejs-execute-plan` runs, resolve authority, and persist the approved plan corpus inside this skill.
## Preconditions
- A spec has explicit user approval or scoped session delegation recorded with its real instruction reference.
- `sdcorejs-spec` has written the approved spec snapshot.
- The plan consumes `spec_context`, the approved spec path/hash, and its repository ID,
  repository-relative path, source revision, and artifact ID.
- `architecture_gate` is an exact valid classifier result. Required work has the immutable
  artifact plus validated `architecture_context`; not-applicable work uses null plus its bypass.

If the spec is missing or unapproved, route to `sdcorejs-spec`.
Run `validateArchitecturePrePlanHandoff` before drafting. Required work uses approved spec ->
approved architecture -> approved plan; a concrete bypass uses approved spec -> approved plan.
Missing parents, identity drift, mutation, unknown profiles, or owner mismatch block planning.

Before drafting, apply `_refs/shared/project-context.md` with:

```text
caller_context: sdcorejs-plan
context_mode: summary-read
side_effects_allowed: true
```

Plan writes are limited to owned draft/approved plan artifacts; stale summary never authorizes
a refresh. Preserve contract/requirement/target/track/profile and repository identities plus the
approved spec path/revision/hash from `spec_context`. Preserve `decision_coverage`,
`goal_backward_review`, the exact `architecture_gate`/`architecture_context`, and any required
approved architecture path/hash/reference without renumbering or inference.

## Process

### 1. Load inputs
Read:

- Approved spec.
- `spec_context`, including `approved_spec_path`, `approved_spec_hash`,
  `target_root_kind`, `stack_profile`, assumptions, risks, non-goals, and
  approval metadata.
- The exact conditional architecture handoff from `sdcorejs-spec` or
  `sdcorejs-architecture`, including the verified artifact when required.
- Relevant `_refs/sdlc/<track>.md` for angular / nestjs / nextjs / ai-agent.
- For ai-agent, also read `_refs/ai-agent/manifest.json`,
  `_refs/ai-agent/profile-contract.json`, and
  `_refs/ai-agent/profiles/common.md`.
- `_refs/shared/testing-philosophy.md`, target stack test ref, and `_refs/shared/validation-map.md` for the approved AC-to-evidence authority.
- Existing `.sdcorejs/docs/product/` ledgers for product-track plans.
- Directly related approved plans under `.sdcorejs/plans/<track>/`, selected by
  metadata and request scope; use an unrelated prior plan only as explicit
  style evidence.
- `package.json`, `packageManager`, lockfiles (`package-lock.json`,
  `pnpm-lock.yaml`, `yarn.lock`, `bun.lockb`/`bun.lock`), workspace config, and
  `package.json` scripts. Record package manager/script evidence instead of
  guessing commands.

Keep the approved spec as the `what`, `why`, constraints, and acceptance source
of truth. The plan references its path/hash and carries only the short scope
delta needed to explain the `how`, order, commands, and file-level changes; it
must not copy the full spec body.

For any non-trivial frontend task, also read
`_refs/shared/frontend-architecture.md` and inspect nearby route/page,
component, state, service/data-access, provider/registration, public API, and
test evidence. The approved plan must carry the completed frontend architecture
contract; planning from a generic folder recipe is not sufficient.

### 2. Check paths
Before drafting:

- Confirm every CREATE path does not already exist.
- Confirm every EDIT path does exist.
- Surface conflicts instead of silently overwriting.
- For generic harness plans, mark unknown paths as `VERIFY THEN EDIT` instead of pretending they are known.
- Define `allowed_paths`, `prohibited_paths`, `generated_artifacts`, and
  `docs_artifacts`. If a path is unknown, say "discover target path during
  execution" and give the path-selection rule instead of inventing a path.
- Mark shared files such as `package.json`, lockfiles, routing modules,
  app-level providers, generated mirrors, global configs, env files, public API
  files, and frozen contracts as coordination-risk paths.
- Record dependency, env, and migration boundaries. Dependency, env, package
  manifest, lockfile, or migration writes require explicit plan approval.
- Every mutable `CREATE`, `EDIT`, or `VERIFY-THEN-EDIT` step names exactly one
  `owner_repository_id` and one matching Git root. Validate/split the result
  with `_refs/shared/repository-contract.mjs`.
- A module-owned plan and its editable steps stay in the module repository, not
  the portal. The portal plan owns only shell/composition/cross-module
  integration, aggregate runner/report, and exact child references.
- For multi-repository work, emit a parent integration plan plus repository-local
  child plans, or repository-local steps with exact deterministic cross-repo
  references. Record semantic owner, execution host, integration owner,
  dependency order, and whether a Gitlink update is approved.

For a non-trivial frontend task:

- complete the `Frontend architecture plan` from
  `_refs/shared/frontend-architecture.md` before creating file tasks;
- derive every component, service/collaborator, provider, registration, public
  export, and test path from that approved component tree and service boundary;
- preserve the target project's detected layout and import conventions;
- treat any example `pages/components/services` structure as a greenfield
  fallback only;
- do not reduce an entity or routed feature to one list component plus one
  detail component when the approved responsibilities require cohesive
  feature-local children;
- do not extract trivial wrappers or add a facade/store without a documented
  state or orchestration reason.

### 2.1 Working-tree and write-scope preflight plan
The plan must tell `sdcorejs-execute-plan` to run this preflight before edits:

- `git status --short`
- staged diffstat
- unstaged diffstat
- untracked files
- current branch
- current HEAD
- allowed_paths and prohibited_paths from `plan_context`
- unrelated dirty files
- `target_root_kind` authoring-repo guard

Only unknown ownership or unrelated overlapping dirty files require a decision;
proven disjoint changes stay untouched. If the affected scope is blocked, ask:

```text
1. Continue but restrict edits to approved plan-scoped files
2. Continue and allow touching selected dirty files
3. Stop so the user can clean or stash changes first
```

Do not plan edits to prohibited paths, env values, secrets, generated/vendor/
build output, lockfiles, or package manifests unless the approved plan allows
them.

### 2.2 Run the goal-backward approval gate

Run the `sdcorejs-plan:goal-backward` mode from
`_refs/shared/decision-coverage.mjs`; this is a mode of `sdcorejs-plan`, not a
new public skill. Work backward from each goal and every `R-###`, `AC-###`,
`D-###`, and `INV-###` record to concrete `TASK-###` entries. Each `AC-###`
also appears in at least one `EVIDENCE-###` row owned by a task in that AC's
`task_refs`. Each task declares one repository owner, explicit dependencies,
planned paths, evidence, and justification. Each invariant maps to both an
enforcing task and planned evidence. Decision records, goals, tasks, and
repository inventory must each be non-empty.

Build `repository_inventory` from inspected repository paths. The checker
derives each planned path as `existing`, `intended-new`, or `missing`:

- `existing` paths appear in the inspected inventory;
- `intended-new` paths have exactly one explicit declaration whose
  `owner_task_id` matches the task using the path;
- every other path is `missing` and blocks approval.

Require safe normalized repository-relative paths with forward slashes for all
task and repository inventory paths. Reject absolute, drive-qualified,
backslash, empty-segment, dot-segment, and traversal forms.

Reject duplicate or conflicting path ownership, dangling/mismatched task or
evidence references, uncovered records or goals, unjustified task scope,
dependency cycles, and invariant enforcement gaps. Record each deterministic
self-critique round with the exact checker version and partition every blocker
into resolved or unresolved. Carry unresolved blockers into the next round.
Stop after at most three rounds; unresolved blockers after three rounds block
approval and execution, and a fourth round is forbidden.

### 3. Draft the plan

Read `_refs/sdlc/plan-template.md` when producing the plan. Its `plan_context`
is the canonical producer shape; verification commands live at
`plan_context.verification_strategy.commands_planned`. Populate substantive
scope, owner, paths, dependencies, AC/evidence mappings and chosen TDD/post-hoc
order. Do not fill unrelated framework schema merely to create boilerplate.

### 4. Self-review before showing the user
Fix the plan before presenting if any checklist item fails:

- No placeholders.
- Every task has a number, action marker, target path or command, and one-line intent.
- Acceptance criteria map to at least one task.
- `decision_coverage` passes strict `plan`-stage validation and embedded `goal_backward_review` has no unresolved blocker.
- `assertValidationMap(plan_context.validation_map)` passes against approved `decision_coverage`; missing/partial AC proof blocks approval.
- `validateArchitectureDraftPlanHandoff` passes self-review. Required plans preserve the exact
  approved architecture path/hash/reference and every profile-specific block
  proves relevant `INV-*` conformance; not-applicable plans retain a concrete
  bypass and `architecture_context: null`.
- Verification section has commands discovered from package manager/script
  evidence or explicit manual checks. If no script exists, record
  `commands_skipped` with the reason instead of inventing one.
- Path conflicts are surfaced.
- Test coverage matches the spec's coverage approach.
- Choose TDD or post-hoc before implementation. Order test authoring before
  code only for TDD; post-hoc still requires mapped verification before completion.
- Parallel candidates are identified, not executed, and include an approved `execution_policy` from the parallel protocol.
- The plan does not hardcode `npm`, `npx`, `tsc`, Playwright, browser installs,
  or any package manager as universal defaults. Do not hardcode npm/npx as
  universal commands, and do not use `npx --yes` or downloading probes without
  explicit approval.
- The plan does not mix package managers.
- Dependency/env/migration/package manifest/lockfile writes are explicitly
  approved or marked out of scope.
- Every non-trivial frontend plan has a complete `frontend_architecture` block
  sourced from `_refs/shared/frontend-architecture.md`; backend-only and trivial
  frontend plans record a concrete `not_applicable_reason`.
- Every AI-agent plan has a complete `agent_architecture` block sourced from
  `_refs/sdlc/ai-agent.md`; its two profile IDs resolve independently in the
  manifest, target paths and dependencies are approved, security-floor fields
  are complete, deterministic checks are offline, and live checks are
  separately authorized or explicitly deferred.
- AI-agent plan review fails generic tools, model/client-owned tenant or
  permissions, missing exact mutation approval, implicit provider storage,
  unbounded execution, missing deterministic/security gates, or unapproved
  dependency/package/lockfile changes.
- Frontend task paths and file decisions match the approved component tree,
  data flow, service boundaries, provider/registration decisions, public API
  policy, and architecture tests.
- Reuse decisions name exact candidate symbols/paths when evidence exists and
  distinguish `reuse`, `extend`, `wrap`, feature-local creation, shared
  creation, and intentional inline markup.
- The component tree protects both sides of the boundary decision: route/page
  containers do not absorb unrelated responsibilities, and trivial markup is
  not extracted only to reduce line count.
- No write-producing step occurs after final branch-ready.

### 5. Present the approval gate
After self-review, resolve authority from `_refs/shared/session-authority.md`.
With current scoped delegation, summarize the concrete plan and continue to
step 6 without asking again. Record `approval_source: delegated-session-scope`,
the real `instruction_reference`, and `document_review_performed: false`.
Scope growth or unresolved material decisions still block affected work.
Without that authority, show this summary and wait for an explicit decision:

```text
Plan ready: <N> tasks across <M> phases.

Phases:
- Phase 1: tasks 1-K
- Phase 2: tasks K+1...

Verification:
- <command>
- Manual: <check>

Do you approve this plan?

Options:
1. Approve - snapshot the plan and move to execute-plan.
2. Change - name the step or phase to update, then I will revise it.
3. Cancel - stop here.

Reply with `1`, `2`, or `3`. If you choose `2`, describe the change.
```

Translate at runtime.

### 6. Persist authorized decisions or handle user response

Explicit Approve or current scoped delegation:

1. Read `_refs/sdlc/plan-approval-artifact.md` completely.
2. Write its immutable approved-plan snapshot in the semantic owner repository.
   Create and immediately verify the `sha256:v1` identity through
   `_refs/shared/approved-artifact.mjs`; `approved_plan_hash` is the
   compatibility projection of canonical `approval_hash`. Supply the approved plan body excluding frontmatter and the hash field as the helper body input;
   the omitted field is self-referential.
3. Record the approved spec, required approved architecture (when applicable),
   draft plan, and approved plan under
   `artifact_context.required_with_change`; set `source_plan` to the approved
   snapshot.
   The approved plan has exactly one parent: the approved architecture when
   required, otherwise the approved spec. Verify the resulting graph rather
   than copying or recomputing any approval hash.
4. Build final `plan_context` with the approved path/hash, write scope,
   verification and package-manager evidence, parallel candidates,
   dependency/env/migration boundaries, and change control; then run
   `validateArchitecturePlanHandoff` against the verified approved snapshot.
5. Handoff to `sdcorejs-execute-plan` only after the snapshot succeeds. Pass
   the full context through `context.pass` or the validated portable handoff;
   reference the approved spec by `contract_id`, path, and hash instead of
   repeating its body in runtime output.

Change request:

1. Edit the plan.
2. Re-run self-review.
3. Re-present the summary.
4. Cap at 3 revision rounds, then suggest returning to `sdcorejs-spec`.

Abort:

1. Stop the workflow.
2. Do not write an approved snapshot.

## Rules

### Must do
- Keep code generation out of this skill.
- Require explicit plan approval unless current scoped delegation covers the plan; never infer it from silence or self-review.
- Snapshot the approved plan before execution.
- Create a new approved snapshot every time; snapshots are immutable history.
- Treat approved plans as immutable snapshots. If scope changes after approval,
  create a new plan revision with `supersedes` and `change_reason`.
- Preserve the latest approved plan that matches the current
  `approved_spec_hash`. If spec_context and plan_context hashes mismatch, stop
  and ask for plan regeneration.
- Preserve `contract_id`, `requirement_id`, exact approved-spec reference,
  artifact owner, source revision, execution/integration owners, repository
  split, dependency order, and Gitlink scope.
- Preserve the exact architecture gate and, when required, approved
  architecture path/hash/reference. Never downgrade a required gate to a
  bypass inside planning.
- Record write scope, path/artifact boundaries, docs artifacts, dependency/env/
  migration changes, verification and package-manager evidence, parallelization
  metadata, approved `execution_policy`, shared-file risks, and tail ordering.
- Discover package manager from `packageManager`, lockfiles, and workspace
  config; read `package.json` scripts before planning commands.
- Record `commands_planned`, `commands_skipped`, focused checks, and broad
  checks with evidence.
- Capture review decisions honestly; never leave the section blank.
- Pass the approved plan as the exact execution contract to `sdcorejs-execute-plan`.
- Include verification commands.

### Must not
- Dispatch a track orchestrator directly from this skill.
- Modify the plan after handing off without returning to the approval gate.
- Treat silence as approval.
- Hide a path conflict.
- Overwrite an old approved snapshot.
- Mutate an approved plan snapshot in place.
- Plan around a missing/stale/mutated required architecture artifact or replace
  its immutable identity with an unapproved architecture summary.
- Add dependencies, env files, migrations, package manifests, lockfiles, or
  generated/vendor/build output unless the approved plan explicitly allows it.
- Hardcode one package manager, mix package managers, invent missing scripts, or
  present npm/npx/tsc as universal defaults.
- Plan writes after final branch-ready.
- Put a module-owned plan in the portal, copy a full child plan into the parent,
  or allow one mutable step to span two Git roots.

## Cross-references
- `sdcorejs-spec` - approved spec input
- `sdcorejs-execute-plan` - runs the approved plan
- `_refs/sdlc/plan-approval-artifact.md` - approved snapshot schema and handoff
