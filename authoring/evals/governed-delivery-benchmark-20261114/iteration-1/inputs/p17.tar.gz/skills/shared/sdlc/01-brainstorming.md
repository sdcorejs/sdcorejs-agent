---
name: sdcorejs-brainstorming
description: Discovery and requirement-confirmation gate before spec. Use for open-ended ideas, compare approaches, missing blockers, or CRUD/entity/screen/module/backend/site/AI-agent/test/product/design/doc/workflow requests across Angular, NestJS, Next.js, React, Node, fullstack, AI-agent, documentation, workflow, test, product, design, and generic/general tracks. Detects track/profile, explores only when unsettled, then confirms minimum inputs for spec. Runtime-localized.
required-actions: artifact.read, context.pass, web.fetch, verification.run, user.choose, visual.present, visual.session.start, visual.session.publish, visual.session.read, visual.session.stop
---

# 01 - Brainstorming


## Shared Protocols

Read `_refs/shared/runtime-protocols.md`. Load project context, choice, or
visual references only when the current question requires them. Resolve track,
stack profile, repository role, and artifact kinds from the versioned
`_refs/shared/system-registry.json`; do not maintain a local competing enum.
Read `_refs/shared/decision-coverage.md` and preserve stable requirement,
acceptance-criterion, assumption, decision, and invariant identities. Validate
the graph at the `discovery` stage: future task/evidence mappings remain
explicit `future_gaps`, while malformed identities, dangling references, and
blocking assumptions remain blockers.

## Purpose
Turn a request into a confirmed requirement contract. This skill now owns both jobs that used to be split:

1. Explore options when the direction is still open.
2. Confirm the blocking inputs needed before `sdcorejs-spec`.

Output dialogue only. Do not write specs, plans, or code here.

For an unsettled UI question, use `_refs/design/uiux/index.md` to select only
the relevant surface and topic; compare current UI evidence and candidate
improvements. Do not infer a full design-system task from a small UI question.
Q&A and bounded explicit fixes retain their existing lightweight routing.
Backend-only questions do not load UI/UX references.

## Process

### 0. Detect execution context
Detect the target project root, `target_root_kind`, track, and
`stack_profile` before asking blockers. Target-root discovery locates evidence;
it does not establish artifact ownership. Use `_refs/shared/project-context.md`
with:

```text
caller_context: sdcorejs-brainstorming
context_mode: summary-read | code-map-readonly
side_effects_allowed: false
```

Use `summary-read` or `code-map-readonly` by default. If the summary is missing,
stale, or contradictory, keep reading targeted files; missing context is not
permission to write `.sdcorejs/summary.md`. Never use `summary-refresh` from
brainstorming unless the user explicitly approves a context write and the
authoring-repo guard says the target can be written.

```bash
TARGET_ROOT=$(git rev-parse --show-toplevel)
cd "$TARGET_ROOT"
```

If multiple app roots exist, ask the user which root to target with a numbered
list and short aliases from `_refs/shared/user-choice-prompt.md`. If no known
stack is detected, resolve it through the `general` generic-harness fallback in
the central registry.

Classify `target_root_kind`:

- `target-project` - normal app/project root.
- `sdcorejs-agent-authoring-repo` - this repository or a checkout containing
  the SDCoreJS skill-pack sources.
- `skill-pack-authoring-repo` - another reusable skill/plugin pack.
- `unknown` - no reliable root evidence.

Writing to an authoring repo requires explicit confirmation that the authoring
repo itself is the target. Brainstorming remains read-only either way.

### 0.1 Resolve semantic repository ownership

Discover repository topology and stable repository IDs using
`_refs/shared/repository-contract.mjs` before creating the handoff. Record the
repository coordinating this conversation as `execution_host_repository_id`.
Resolve the semantic requirement/spec owner independently:

- A module-scoped requirement is owned by that module repository even when the
  request starts in the portal.
- Portal ownership is limited to its shell, composition, cross-module
  integration, and aggregate runner/report behavior.
- A repository-local or standalone request is owned by its identified target
  repository.
- The current working directory, most recent artifact, and execution host are
  never ownership evidence by themselves.

When module mapping is ambiguous, block before any durable write. When a module
repository is missing, unavailable, or read-only, record an unresolved blocker
and keep `write_target: null`; missing module ownership must never fall back to
the portal. Preserve both owner and execution-host IDs in the context.
Brainstorming remains read-only and does not probe writability by writing.

### 0.2 Stack profile classification
Set `track`, `stack_profile`, `profile_confidence`, and `profile_evidence` from
current evidence. If `sdcorejs-explore` already produced `explore_context`,
consume `stack_profiles` and `profile_evidence` as evidence, not truth.

Angular profiles:

- `core-ui-angular`: Angular plus an installed dependency/import of
  `@sdcorejs/angular`.
- `legacy-core-ui-angular`: Angular plus an installed dependency/import of
  `@sd-angular/core`.
- `plain-angular`: Angular signals such as `angular.json`, `@angular/core`,
  components, routes, or Angular tests, with no Core UI package/import evidence.
- `migration-request`: the user explicitly asks to install, migrate, or adopt
  SDCoreJS Core UI or another framework convention not currently present.

Do not classify an Angular project as Core UI from `angular.json` alone. Do not
classify an Angular project as Core UI from `@angular/core` alone.

NestJS profiles:

- `sdcorejs-nestjs`: NestJS plus `@sdcorejs/nestjs` or strong SDCoreJS Nest
  conventions already present.
- `plain-nestjs`: NestJS signals such as `nest-cli.json`, `@nestjs/*`,
  modules/controllers/providers, or Nest tests, with no SDCoreJS Nest evidence.

Do not assume TypeORM, PostgreSQL, Zod, SdContext, `@HasPermission`, or
`@sdcorejs/nestjs` for `plain-nestjs` unless detected or selected.

Next.js profiles:

- `nextjs-build-website`: Next.js plus strong public-site/build-website
  evidence such as `[locale]` routes, typed i18n navigation, content/public-site
  structure, or prior `sdcorejs-nextjs` build-website context.
- `plain-nextjs`: Next.js signals such as `next.config.*`, `next` dependency,
  app/pages router files, `page.tsx`, `layout.tsx`, `route.ts`, or tests, with
  no build-website evidence.
- `react-next-generic`: use this when Next.js is present but the request is
  generic React/dashboard/app work and build-website profile is absent.

Do not assume `[locale]`, `setRequestLocale`, sitemap/public-site metadata,
typed i18n navigation, or content folders for `plain-nextjs`. Do not assume
build-website conventions for generic Next.js apps.
Do not assume [locale] routes or build-website conventions unless
`nextjs-build-website` evidence is present or the user selected that migration.

React and general profiles:

- `react-vite`: Vite config plus React dependency.
- `react-cra`: `react-scripts`.
- `node-general`: Node/package project without a stronger framework profile.
- `general`: no known stack evidence.
- `unknown`: conflicting or insufficient evidence.

AI-agent profile:

- `ai-agent`: the confirmed primary deliverable is an application agent
  contract/implementation. Under-specified "build an agent" or "use AI"
  remains in explore mode until capability, engine, runtime owner, trust,
  tools, state, evidence, limits, and verification are confirmed.

Use the central registry's `tracks` and `stack_profiles` collections. Treat its
legacy aliases only as deterministic inputs; emit the canonical track in
`requirement_context`.

The Angular `technical-prototype` profile is explicit opt-in only. A
non-technical persona, mockup request, incomplete backend, or ambiguous
requirement must not activate it. Never infer admin/auth/account/role/permission
scope unless an approved requirement or explicitly selected profile includes
that scope. Mark every other inference as an assumption requiring confirmation.

### 1. Load context cheaply
Read only what changes the questions:

- Directly related `.sdcorejs/docs/<track>/*.md`, selected by request scope and
  artifact metadata rather than recency alone.
- `.sdcorejs/memories/<track>/*.md` frontmatter; load relevant bodies only.
- Related approved spec/plan frontmatter selected in order by the same
  `contract_id`, `change_ref`, `supersedes` relationship, requirement, exact
  module, or explicit user selection. Recency only breaks a relationship tie.
- For angular / nestjs / nextjs / ai-agent: `_refs/sdlc/<track>.md`.
- For test: `_refs/shared/testing-philosophy.md`, then the target stack test ref when known.
- For product: product ledgers related to the exact requirement or module.
- `package.json`, lockfiles, and workspace config only enough to identify
  package manager/script evidence; do not run installs or mutate dependencies.

### 2. Decide explore mode vs confirm mode
Use explore mode when the request is unsettled:

- The user describes a goal, not concrete artifacts.
- There are multiple plausible approaches.
- The user compares options or says they are unsure.
- For nextjs, industry / audience / page set is unknown.
- For angular / nestjs, module ownership or workflow shape is unclear.
- For test, the user provided selectors or an inspector export without test cases and assertions.

Use confirm mode when the user already gave concrete artifacts and the remaining work is to lock blockers.

### 3. Explore only when needed
When in explore mode:

1. Ask at most one targeted question if the answer changes the option set.
2. Present 2-3 approaches with stable numeric selectors (`1/2/3`) and tradeoffs.
3. Recommend one approach with a short reason tied to the user's goal.
4. Ask for direction confirmation and state that the user can reply with the selector, alias, or "you decide".

Do not continue to blocker confirmation until the direction is selected or the user explicitly says "you decide".

## Optional Visual Companion

Before presenting or settling an open decision, apply
`_refs/sdlc/visual-offer-policy.md`. Assess actual alternatives and visual
benefit, then invite just in time before choosing a direction. Direct preview
requests already establish intent. Preserve scoped `visual_companion` state
through handoffs; a skill or phase change does not reset a decline or pending
invitation. Load the detailed `_refs/sdlc/visual-companion.md` only to prepare
an accepted/requested surface or its missing runtime consent.

The visual companion remains an optional decision aid. Conversation feedback
owns the direction; convert it to acceptance criteria and preserve normal
spec/plan approval gates before implementation.

### 4. Confirm blockers
Reuse answers already present in the conversation or artifacts. Ask one
approval or high-impact decision per turn. You may group two to four independent
factual blockers only when an earlier answer cannot change a later option set.
Never group approvals or dependent decisions. When a blocker has known
alternatives, label it with stable numeric selectors.

Blockers must be profile-aware. Ask only for decisions that affect
implementation correctness, security, public API, data model, irreversible
scope, verification, or user-visible behavior. For non-technical users,
translate technical consequences into product decisions.

Minimum blockers by profile/context:

| Context/profile | Required before spec |
|---|---|
| `core-ui-angular` / `legacy-core-ui-angular` | module, entity/screen, fields or visible data, layout, workflow/actions, permissions if applicable, Core UI reuse expectations |
| `plain-angular` | local module/screen, installed UI library or existing components, visible data, workflow/actions, route/state shape, verification; do not ask Core UI/admin-screen blockers unless migration or Core UI was explicitly selected |
| `sdcorejs-nestjs` | module, entity/resource, persistence, transaction style, endpoint/action set, permission/profile decisions |
| `plain-nestjs` | resource/API shape, persistence actually present, endpoint/action set, validation/auth expectations, verification; do not ask SDCoreJS Nest/TypeORM/PostgreSQL blockers unless detected or selected |
| `nextjs-build-website` | domain or temporary production URL, target audience, page set, contact channel, languages, hosting/caching, OG/SEO expectations |
| `plain-nextjs` / `react-next-generic` | app/dashboard/page intent, routes/components, data source, auth/session expectations, rendering constraints, verification; do not ask build-website/domain/i18n blockers unless public-site delivery is intended |
| `react-vite` / `react-cra` | feature/component, state/data source, routing, styling system, test runner |
| `node-general` / `general` | goal, files/areas in scope, constraints, acceptance criteria, verification command or manual check |
| `ai-agent` | business capability and non-goals; engine owner; consuming runtime/paths; trusted identity and tenant source; data/storage policy; business-shaped tools and side effects; approvals; sessions/state; evidence; tracing/audit/usage; limits; offline evals; live-verification boundary |
| test | target stack, test level, subject under test, cases with expected results, data/auth/env, selector/source inventory, reuse vs new fixtures |
| product | feature name, business goal, users/personas, scenarios, acceptance criteria seed, source artifacts, impacted tracks, UAT expectations |

Also ask the coverage approach once:

- `post-hoc` (default for UI/content scaffolding).
- `TDD` (default for service logic, validators, workflows, transactions).
- `test-plan-only` when the requested output is a test plan.
- `not-applicable` for pure product/design/discovery artifacts.

Record this answer for `sdcorejs-plan`.

### 5. Infer then confirm
When a semantic default is obvious, propose it instead of asking from scratch:

- Entity fields from entity name.
- Next.js page set from industry and goal.
- Test cases from acceptance criteria or an inspector export.
- Product acceptance criteria from approved requirements, marking inferred items for confirmation.
- Generic harness verification from scripts in `package.json`.

Always present inferred values for confirmation before locking them.

### 6. Output the requirement contract
End with a concise confirmed summary in the user's language. Build the complete
`requirement_context` for `sdcorejs-spec`, but do not echo the full block by
default. Pass it through `context.pass` or the validated portable handoff. Do
not persist it unless a later write-approved skill owns the artifact.

- Track/context.
- Target root and `target_root_kind`.
- Semantic owner repository/module and execution host repository.
- `stack_profile`, confidence, and evidence.
- Chosen direction.
- Required inputs.
- Defaults accepted.
- Coverage approach.
- Acceptance criteria seed.
- Open questions, if any.

If any minimum blocker remains unanswered, stop here and ask only for the missing blocker. When all blockers are confirmed, hand off to `sdcorejs-spec`.

Use this schema:

```yaml
requirement_context:
  source: sdcorejs-brainstorming
  decision_coverage:
    schema_version: 1
    revision: <integer>
    records: []
    history: []
  goal_backward_review:
    schema_version: 1
    mode: sdcorejs-plan:goal-backward
    stage: discovery
    future_gaps: []
  requirement_id: <stable id>
  contract_id: <stable id shared by spec/plan/execute>
  target_root: <absolute or repo-relative target>
  target_root_kind: target-project | sdcorejs-agent-authoring-repo | skill-pack-authoring-repo | unknown
  track: <canonical registry track>
  stack_profile: <registry stack profile>
  profile_confidence: high | medium | low
  profile_evidence:
    - <dependency/config/file/import evidence>
  owner_repository_id: <stable semantic owner repository id>
  owner_repository_role: standalone | portal | module | library | service | documentation
  owner_module_id: <module id or null>
  execution_host_repository_id: <stable repository id coordinating this run>
  ownership_resolution:
    source: topology-manifest | explicit-user-evidence | repository-evidence
    status: resolved | blocked
    write_target: <owner repository id or null>
  user_goal: <summary>
  user_type: technical | non-technical | mixed | unknown
  problem_statement: <summary>
  success_outcome: <summary>
  in_scope:
    - item: <scope item>
      source: explicit | inferred | defaulted
  non_goals:
    - item: <scope item>
      source: explicit | inferred | defaulted
  risks:
    - risk: <material risk>
      mitigation: <confirmed mitigation or unresolved>
  decisions_confirmed:
    - decision: <name>
      value: <value>
      source: explicit | inferred | defaulted
  assumptions:
    - assumption: <text>
      source: inferred | defaulted
      requires_confirmation: true | false
  blockers:
    resolved:
      - item: <text>
    unresolved:
      - item: <text>
  unresolved_blockers:
    - <blocking decision, owner availability issue, or empty>
  coverage_approach: post-hoc | tdd | test-plan-only | not-applicable | unknown
  acceptance_criteria_seed:
    - id: AC-001
      behavior: <observable behavior>
      expected_result: <testable outcome>
  visual_companion:
    schema_version: 1
    decisions: [] # scoped identity, assessment status/reason and actual surface
    responses: [] # pending/accepted/declined with conversation scope
    consents: [] # explicit local-runtime/browser grants with scope and purpose
    artifact_write_approved: true | false # separate artifact lifecycle authority
  redaction_applied: true | false
  next_skill: sdcorejs-spec
```

Redact secrets and PII before the context is shown or passed along. Never store
secret values, credentials, tokens, API keys, database URLs, JWTs, cookies,
customer PII, production payloads, or sensitive logs in requirement/spec/plan
contexts. For env requirements, record key names only and use `[REDACTED]` for
values.

## Rules

### Must do
- Keep the user's language at runtime.
- Preserve locale-specific marks in generated labels and prose.
- Use English identifiers, permission codes, and route paths.
- Block `sdcorejs-spec` until minimum blockers are confirmed.
- Save durable repeated preferences through `sdcorejs-explore (memories-write-approved)` only when relevant and approved.
- Preserve `contract_id`, `target_root`, `target_root_kind`, `track`,
  `stack_profile`, owner repository/role/module, execution host repository,
  explicit user decisions, non-goals, risks, acceptance-criteria seed,
  inferred/defaulted assumptions, unresolved blockers, and profile evidence for
  downstream skills.
- Preserve `decision_coverage` and the discovery-stage
  `goal_backward_review`; downstream planning owns task, path, and evidence
  completion and must not renumber an existing record.
- Keep visual companion artifact writes response-only unless
  `visual_companion.artifact_write_approved` is true.

### Must not
- Generate code, specs, plans, or commits.
- Do not write specs, plans, or code from brainstorming.
- Do not write `.sdcorejs/summary.md`, specs, plans, visual companion files, or
  durable memories by default.
- Treat a plain-language persona as permission to infer or hide technical
  decisions that require owner approval.
- Write a module requirement/spec/plan into the portal because its semantic
  owner repository is unavailable or not writable.
- Show angular blockers to nextjs, or nestjs blockers to test.
- Force SDCoreJS/Core UI/TypeORM/build-website assumptions onto plain profiles.
- Dump every question at once.
- Treat "thanks" or silence as approval.

## Hand-off
Pass `sdcorejs-spec` this authoritative context without repeating the summary
or embedding source artifact bodies:

- target root
- target root kind
- detected context/track
- stack profile and profile evidence
- semantic owner repository/role/module and execution host repository
- confirmed `requirement_context`
- chosen direction and tradeoffs considered
- source artifacts provided by the user
- coverage approach
- explicit decisions, inferred/defaulted assumptions, unresolved blockers, and
  redaction status

## Cross-references
- `_refs/sdlc/<track>.md` - angular / nestjs / nextjs discovery, spec, and plan patterns
- `_refs/shared/testing-philosophy.md` - test-track principles
- `sdcorejs-product` - product ledger and traceability review
- `sdcorejs-spec` - writes and reviews the spec gate
- `sdcorejs-explore (memories mode)` - durable project preferences
