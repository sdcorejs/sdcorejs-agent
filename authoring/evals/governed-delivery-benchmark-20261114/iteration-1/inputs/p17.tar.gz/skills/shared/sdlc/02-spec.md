---
name: sdcorejs-spec
description: Spec authoring and approval gate. Use after brainstorming confirms requirements, or when the user asks to write/review/approve/change a spec or design doc. Writes a draft under .sdcorejs/docs, self-reviews, resolves explicit approval or scoped session delegation, then persists the approved snapshot under .sdcorejs/specs before plan. Applies across tracks. Runtime-localized.
required-actions: artifact.read, artifact.write, context.pass, verification.run, user.approve
---

# 02 - Spec


Read `_refs/shared/session-authority.md` before classification or any approval/finish
transition. Reuse scoped session authority; preserve unresolved risk decisions.

## Shared Protocols

Read `_refs/shared/runtime-protocols.md`. Draft and approved spec artifacts
apply `_refs/shared/artifact-lifecycle.md` and emit `artifact_context`. Resolve
track/profile/repository semantics from `_refs/shared/system-registry.json`.
Create and verify every approval identity with the executable
`_refs/shared/approved-artifact.mjs` helper. Read
`_refs/shared/decision-coverage.md`, validate `decision_coverage` at the `spec`
stage with `_refs/shared/decision-coverage.mjs`, and preserve its stable IDs,
revision history, blockers, and future planning gaps.
Read `_refs/sdlc/architecture.md` and classify the post-spec conditional gate
with `classifyArchitectureGate` from
`_refs/shared/architecture-contract.mjs`. The spec records the classification;
it does not author the architecture artifact.

Preserve `requirement_context.visual_companion` as runtime context through
`context.pass` (portable `state_delta.visual_companion`), including stable decision/thread identity, scoped responses,
actual surface and purpose-bound consent. Do not reset it when changing phase,
persist runtime permission in approved artifacts, or reopen a settled visual
choice. An unresolved choice returns to its owner under
`_refs/sdlc/visual-offer-policy.md`; normal approval/change-control gates remain.

## Purpose
Turn the confirmed requirement contract into a durable spec, resolve scoped authority, and persist the approved spec corpus inside the same skill.

A spec answers what and why. A plan answers which files and in what order.

## Preconditions
- `sdcorejs-brainstorming` has confirmed the minimum blockers and emitted
  `requirement_context`, or the conversation already contains an equivalent
  complete requirement set with explicit decisions, assumptions, target root,
  target root kind, track, stack profile, and acceptance criteria seed.
- Target root and context/track are known.
- `owner_repository_id`, `owner_repository_role`, optional `owner_module_id`,
  and `execution_host_repository_id` are resolved from semantic topology rather
  than the current working directory.
- For non-trivial code/test generation, do not proceed from an unconfirmed idea.

If these are missing, route back to `sdcorejs-brainstorming`.
If the semantic owner repository is unavailable or not writable, block. Do not
write a module spec into the portal as a fallback.

Before drafting, apply `_refs/shared/project-context.md` with:

```text
caller_context: sdcorejs-spec
context_mode: summary-read
side_effects_allowed: true
```

Spec writes are allowed only for the draft/approved spec artifacts owned by this
skill. Missing or stale summary is not permission to refresh context. Use
targeted reads instead unless the user explicitly approved a summary refresh.

## Process

### 1. Load guidance and related artifacts
Read the relevant guidance:

- angular / nestjs / nextjs: `_refs/sdlc/<track>.md`
- ai-agent: `_refs/sdlc/ai-agent.md` plus
  `_refs/ai-agent/{manifest.json,profile-contract.json,profiles/common.md}`
- test: `_refs/shared/testing-philosophy.md` plus the target stack test ref if known
- product: product ledgers related to the same requirement or module
- generic harness: the canonical template plus available project scripts
- package manager evidence: `packageManager`, lockfiles, workspace files, and
  `package.json` scripts, only to set verification expectations. Do not invent
  scripts or hardcode `npm`, `npx`, or `tsc` as universal commands.

Select prior artifacts by relationship, in this order:

1. same `contract_id`;
2. same `change_ref`;
3. an explicit `supersedes` relationship;
4. same requirement or exact module;
5. an artifact selected by the user;
6. the canonical template, frontmatter, and headings.

Recency may break a tie only within the same relationship. If the purpose is
style, read the canonical template or only the frontmatter and headings of one
related artifact. Read a prior body only when its content is a real dependency
of the current change. Do not load unrelated recent specs merely to mirror
style.

Also read relevant `.sdcorejs/memories/<track>/*.md` and any provided
`requirement_context`. Preserve `contract_id`, `requirement_id`,
`target_root`, `target_root_kind`, `track`, `stack_profile`,
`profile_confidence`, owner repository/role/module, execution host repository,
explicit decisions, inferred/defaulted assumptions, unresolved blockers, and
redaction status. Preserve `decision_coverage` and `goal_backward_review`
without renumbering records or hiding future task/evidence gaps. Validate
track/profile against the central registry.

Cross-repository parent references must carry exact `repository_id`,
`artifact_id`, `artifact_kind`, 40-character `revision`, and `approval_hash`.
Reject a stale, missing, or mutated parent reference before drafting.

If the user asks to revise an approved spec, do not mutate the approved
snapshot. Create a new revision with `supersedes` and `change_reason`. If a
draft references stale requirement context, stop and return to brainstorming or
ask for an updated requirement contract.

### 2. Write the draft spec file
Write the editable draft to:

```text
<semantic-owner-root>/.sdcorejs/docs/<track>/<YYYY-MM-DD-HH-mm>-<kebab-topic>-spec.md
```

Use this template:

````markdown
# Spec - <Title> - <YYYY-MM-DD HH:mm>

```yaml
spec_context:
  source: sdcorejs-spec
  decision_coverage:
    schema_version: 1
    revision: <integer>
    records: []
    history: []
  goal_backward_review:
    schema_version: 1
    mode: "sdcorejs-plan:goal-backward"
    stage: spec
    future_gaps: []
  architecture_gate:
    valid: true | false
    required: true | false | null
    status: required | not-applicable | blocked
    signals: []
    bypass: null # or { kind: <canonical bypass>, rationale: <concrete reason> }
    rationale: <required-signal rationale, bypass rationale, or null>
  contract_id: <from requirement_context or newly created>
  requirement_id: <from requirement_context when present>
  approved_spec_path: <empty until approved>
  approved_spec_hash: <empty until approved>
  supersedes: <prior approved spec path or null>
  target_root: <target root>
  target_root_kind: target-project | sdcorejs-agent-authoring-repo | skill-pack-authoring-repo | unknown
  owner_repository_id: <stable owner repository id>
  owner_repository_role: standalone | portal | module | library | service | documentation
  owner_module_id: <module id or null>
  execution_host_repository_id: <stable execution host repository id>
  track: <track>
  stack_profile: <stack profile>
  profile_confidence: high | medium | low
  source_requirement_context: <requirement_context id or embedded summary>
  acceptance_criteria_count: <number>
  manual_criteria_count: <number>
  non_goals:
    - <item>
  risks:
    - <item>
  assumptions:
    - <item>
  redaction_applied: true | false
  approval:
    approved: false
    approved_at: null
    approval_source: explicit-user-choice | delegated-session-scope | imported-approved-spec | equivalent-complete-input
    instruction_reference: <real scoped instruction reference or null>
    document_review_performed: false
  change_control:
    revision: <integer>
    supersedes: <prior approved spec path or null>
    change_reason: <reason or null>
```

## Problem & Goals
<What problem this solves, who it serves, and what success looks like.>

## Requirements
- R-001 - <Observable or contractual requirement, source, status, and semantic owner>

## Decisions
- D-001 - <Question, selected value, source, status, scope, owner, rationale, and supersession>

## Assumptions
- A-001 - <Source, confidence, status, blocking flag, evidence, consequence, validation method, and owner>

## Architecture gate classification
- Status: required | not-applicable
- Signals: <canonical signals or none>
- Rationale/bypass: <concrete reason>

## Non-goals
- <Explicit out-of-scope item>

## Architecture
<How this fits the project, including context/track-specific conventions.>

## Stack profile and technology assumptions
- Track: <track>
- Stack profile: <stack_profile>
- Profile evidence: <short list>
- Technology assumptions: <explicit, inferred, defaulted, or unknown>

## File structure
- `<path>` - <create/edit intent>

## Acceptance criteria
- AC-001 - <Concrete, testable criterion>

## Risks & mitigations
- **Risk:** <risk> -> **Mitigation:** <mitigation>

## Out of scope (deferred)
- <Deferred item> - defer until <trigger>
````

For test-track specs, "File structure" may describe test files, fixtures, page objects, or harness files. For product-track specs, it may describe product ledgers, UAT checklists, traceability matrices, and source artifacts. For generic harness specs, it may describe the files/commands the harness is allowed to touch.

For `track: ai-agent`, the Architecture section must resolve one engine profile
and one independent capability profile, and specify runtime ownership, target
paths, trust/tenancy/data boundaries, provider storage posture,
business-shaped tool contracts, guardrails, approvals, session/state,
evidence, tracing/audit/usage, limits, reliability, deterministic evals,
separate live-verification evidence, rollout, rollback, and non-goals. Apply
`_refs/sdlc/ai-agent.md`; fail closed when any security or ownership decision is
unresolved.

### 3. Self-review before showing the user
Fix the spec before presenting if any checklist item fails:

- No `TBD`, `TODO`, `???`, or placeholder text.
- Every template section is present and populated.
- At least one explicit non-goal.
- At least one acceptance criterion per user-visible behavior.
- Acceptance criteria have stable IDs such as `AC-001`, `AC-002`; mark manual
  or deferred criteria clearly.
- Requirements, acceptance criteria, assumptions, and decisions contain the
  complete type-specific fields from `_refs/shared/decision-coverage.md`.
- Spec-stage decision coverage has no unresolved blocking decision or
  assumption, duplicate ID, invalid enum, or dangling reference.
- Architecture matches the confirmed requirement contract.
- `classifyArchitectureGate` returns a valid required classification or a
  concrete not-applicable bypass. Ambiguous or conflicting classification
  blocks spec approval.
- File paths match the detected context or are clearly marked generic harness paths.
- Language is consistent with the user.
- Scope is not too large; suggest splitting if the spec is over 2 pages.
- Plain profiles stay plain: do not force SDCoreJS/Core UI/build-website
  assumptions for `plain-angular`, `plain-nestjs`, `plain-nextjs`,
  `react-vite`, `react-cra`, `react-next-generic`, `node-general`, or
  `general`.
- Redact secrets and PII; use `[REDACTED]` placeholders and record
  `redaction_applied: true` if sensitive input appeared.
- For `ai-agent`, verify the selected IDs exist in the manifest, provider state
  remains disabled unless governance approval is explicit, generic raw tools
  are absent, and acceptance criteria cover server denial plus the offline/live
  evidence boundary.

### 4. Present the approval gate
After self-review, resolve authority from `_refs/shared/session-authority.md`.
With current scoped delegation, summarize the concrete spec and continue to
step 5 without asking again. Record `approval_source: delegated-session-scope`,
the real `instruction_reference`, and `document_review_performed: false`.
Scope growth or unresolved material decisions still block affected work.
Without that authority, show this summary and wait for an explicit decision:

```text
Spec written: <relative path>

Summary:
- Goal: <1 line>
- Scope: <module/entity/page/test/harness area>
- Files: <N> create, <M> edit
- Acceptance: <N> criteria
- Non-goals: <short list>
- Risks: <short list>

Do you approve this spec?

Options:
1. Approve - snapshot the spec, then route through the conditional architecture gate.
2. Change - tell me what to update, then I will revise the spec.
3. Cancel - stop here.

Reply with `1`, `2`, or `3`. If you choose `2`, describe the change.
```

Translate the prompt at runtime.
Silence is not approval. A thank-you, question, or unrelated follow-up also
does not cross this gate.

### 5. Persist authorized decisions or handle user response

Explicit Approve or current scoped delegation:

1. Write an immutable approved-spec snapshot under:

```text
<semantic-owner-root>/.sdcorejs/specs/<track>/<YYYY-MM-DD-HH-mm>-<kebab-topic>.md
```

Build the approved body and protected metadata as UTF-8, then call
`createApprovedArtifact` (or CLI `create`) from
`_refs/shared/approved-artifact.mjs`. Immediately call
`verifyApprovedArtifact` (or CLI `verify`) before persisting/handoff. The
versioned `sha256:v1` algorithm normalizes line endings and field order,
excludes only the self-referential `approval_hash`, and never includes an
absolute checkout path. Supply the approved contract body excluding frontmatter and the hash field as the helper body input; the omitted field is
self-referential. A non-zero/invalid result blocks the workflow.

2. Include frontmatter:

```yaml
---
artifact_id: spec-<contract-id>-r<revision>
artifact_kind: spec
schema_version: 1
change_ref: <contract id>
source_spec: none
source_plan: none
commit_policy: with-change
owner: sdcorejs-spec
name: <kebab-topic>
description: <one-line future-loading hook>
contract_id: <contract id>
requirement_id: <requirement id>
owner_repository_id: <stable semantic owner repository id>
owner_repository_role: standalone | portal | module | library | service | documentation
owner_module_id: <module id or null>
repository_relative_path: .sdcorejs/specs/<track>/<timestamp>-<topic>.md
source_revision: <40-character Git revision belonging to the owner repository>
parent_repository_id: <stable parent repository id or null>
parent_references:
  - repository_id: <stable repository id>
    artifact_id: <exact parent artifact id>
    artifact_kind: <registry artifact kind>
    revision: <exact 40-character repository revision>
    approval_hash: <exact sha256:v1 hash>
approved_at: <ISO-8601 UTC timestamp>
approved_by: <safe session identity or null>
approval_source: explicit-user-choice | delegated-session-scope | imported-approved-spec | equivalent-complete-input
instruction_reference: <real scoped instruction reference or null>
document_review_performed: true | false
track: <canonical registry track>
target_root_kind: target-project | sdcorejs-agent-authoring-repo | skill-pack-authoring-repo | unknown
stack_profile: <stack profile>
profile_confidence: high | medium | low
sourceDraftPath: .sdcorejs/docs/<track>/<timestamp>-<topic>-spec.md
approval_hash: <sha256:v1 hash created by approved-artifact helper>
approved_spec_hash: <same value, compatibility projection for spec_context>
acceptance_criteria_count: <N>
manual_criteria_count: <N>
redaction_applied: true | false
supersedes: <prior approved spec path or null>
change_control:
  revision: <integer>
  supersedes: <prior approved spec path or null>
  change_reason: <reason or null>
---
```

3. Emit both the draft and approved snapshot in
   `artifact_context.required_with_change`; set `source_spec` to the approved
   snapshot path for downstream producers.

3. Body format:

```markdown
# <Title> - Approved Spec

> Immutable contract authorized by the recorded approval source. Delegated authority does not mean the user reviewed this document. Re-author through `sdcorejs-spec` if the contract changes.

## Approved contract
<verbatim approved spec content>

## Authority and review provenance
- <real instruction/decision reference, scope, and whether user document review occurred>
- <self-review decisions; user review decisions only when observed>

## Skill provenance
sdcorejs-spec (self-review attempt <N> / 3; authority: <recorded approval source>)
```

4. Build the final `spec_context` for the handoff. Include the
   `approved_spec_path`, canonical `approval_hash`, compatibility
   `approved_spec_hash`, approval metadata,
   `change_control`, and source `requirement_context` reference.
5. Only after the approved snapshot succeeds, preserve the exact
   `architecture_gate`. When it is `required`, hand off to
   `sdcorejs-architecture`; when it is concretely `not-applicable`, hand off
   directly to `sdcorejs-plan`. Never treat `blocked` or ambiguous as bypass.
   Pass the draft spec path, approved snapshot path, and `spec_context`. Pass the
   full context through `context.pass`; if the channel is unsupported or
   unknown, use the validated portable handoff. Do not repeat the approved spec
   body in the runtime handoff or final user projection.

Change request:

1. Edit the spec in place.
2. Re-run the self-review checklist.
3. Re-present the summary.
4. Cap at 3 revision rounds, then suggest returning to `sdcorejs-brainstorming`.

Abort:

1. Leave the spec file in place.
2. Do not write an approved snapshot.
3. Stop the workflow.

## Rules

### Must do
- Write draft and approved snapshots in the semantic owner repository. If the
  authoring repo itself is the explicit target, an `sdcorejs-agent-authoring-repo`
  or `skill-pack-authoring-repo` artifact is allowed after explicit confirmation.
- When a module-owned spec is coordinated from a portal, keep the full editable
  spec in the module repository. A portal index may contain only a durable
  reference with exact repository/artifact/revision/hash identity.
- Require explicit approval unless current scoped delegation covers the spec; never infer it from silence or self-review.
- Route required architecture through `sdcorejs-architecture` before planning;
  route not-applicable architecture directly to `sdcorejs-plan` only with the
  concrete classifier reason.
- Create a new approved snapshot every time; snapshots are immutable history.
- Treat approved specs as immutable snapshots. If requirements change after
  approval, create a new spec revision with `supersedes` and `change_reason`.
- Preserve `contract_id`, `target_root_kind`, `stack_profile`, profile evidence,
  explicit decisions, inferred/defaulted assumptions, non-goals, risks, and
  redaction status.
- Include problem statement, goals, non-goals, users/personas when relevant,
  functional requirements, non-functional requirements when relevant, data/API/
  security/permission implications when relevant, UI/UX constraints when
  relevant, acceptance criteria with stable IDs, manual/deferred criteria,
  risks/open questions, migration/dependency changes if requested, and
  test/verification expectations.
- Redact secrets and PII. Never persist credential values, tokens, API keys,
  database URLs, JWTs, cookies, customer PII, production payloads, sensitive
  logs, or raw stack traces containing secrets. Record env key names only.
- Capture review decisions honestly; never leave the section blank.
- Treat silence, "thanks", and follow-up questions as not approved.
- Preserve the user's language in prose.
- Use English identifiers and route paths.

### Must not
- Mix implementation order into the spec.
- Invent approval or user document review; delegated authority must name the real scoped user instruction.
- Skip approved snapshot writing on approval.
- Proceed to `sdcorejs-plan` before the SPEC snapshot is written.
- Skip a required architecture gate or fabricate a not-applicable reason.
- Overwrite an old approved snapshot.
- Mutate an approved snapshot in place.
- Treat stale/missing context as permission to write or refresh `.sdcorejs`
  summary artifacts.
- Add migration or dependency adoption scope unless the requirement context
  explicitly approved it.
- Copy a full module spec into the portal or use the execution host as an owner
  fallback.
- Compute, accept, or describe an approval hash without running the shared
  create and verify helper.

## Cross-references
- `sdcorejs-brainstorming` - requirement contract input
- `sdcorejs-architecture` - conditional approved-spec architecture gate
- `sdcorejs-plan` - consumes the approved spec
