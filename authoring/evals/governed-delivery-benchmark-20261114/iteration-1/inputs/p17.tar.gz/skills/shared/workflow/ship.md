---
name: sdcorejs-ship
description: Final delivery and dependency-update gate. Use for verify-before-done, branch readiness, ready-to-merge, ship/push/release/tag, update dependencies, update package, bump package, npm outdated, audit fix, or consistency checks before handoff. Owns verify-before-done, branch-ready, ship, dependency-update, and release-ready modes; delegates git artifacts to sdcorejs-git. Applies to all tracks and this repo. Runtime-localized.
required-actions: artifact.read, artifact.write, context.pass, verification.run, user.choose, user.approve
---

# Ship

Read `_refs/shared/git-disposition.md` and `_refs/shared/session-authority.md`
before artifact handoff. Keep acceptance disposition separate from hygiene.
## Purpose And Boundary

Own the final delivery readiness boundary: prove the work satisfies the right
contract, prove the branch hygiene evidence is current, and then hand off to
artifact workflows only when the user explicitly asks for them.

`sdcorejs-ship` decides readiness. `sdcorejs-git` creates Git artifacts only
after current ship and branch-ready evidence exists and the user explicitly asks
for commit, PR, push, changelog, tag, or release artifacts.

`sdcorejs-ship` is responsible for:

- feature acceptance verification;
- bugfix verification;
- specless and docs-only hygiene verification;
- dependency-update safety verification;
- release readiness checks;
- final branch-ready checks;
- collecting evidence from explore, review, test, debug, repair-loop, and prior branch-ready contexts;
- producing `ship_context`.

`sdcorejs-ship` is not responsible for:

- committing changes, creating PRs, pushing branches, tagging releases,
  publishing packages, or creating release artifacts directly;
- patching review/debug/test failures from read-only verify or branch-ready
  gates;
- silently installing tools or downloading probe tools;
- bypassing `sdcorejs-review`, `sdcorejs-test`, `sdcorejs-debug`,
  `sdcorejs-repair-loop`, `sdcorejs-git`, or `sdcorejs-explore`.
## Shared Protocols

Read `_refs/shared/runtime-protocols.md` and
`_refs/shared/artifact-lifecycle.md`; consume and pass through the current
change's `artifact_context`. For production/release claims, also load
`_refs/shared/ship-readiness-contract.mjs`; it consumes the common approved
artifact, repository, source revision map, and evidence identities. Redact
suspected secrets before printing evidence. Read
`_refs/shared/decision-coverage.md`, preserve `decision_coverage` and
`goal_backward_review`, and block readiness when either reports an uncovered
record, invariant evidence gap, or unresolved critique blocker.
Preserve `architecture_context` and the exact `architecture_gate`. For required
architecture, verify the immutable spec -> architecture -> plan graph and
current `INV-*` conformance; missing/stale/mutated architecture or mismatched
path/hash/reference blocks readiness. A concrete not-applicable gate retains
`architecture_context: null` and must not be upgraded to PASS by inference.
Read `_refs/shared/validation-map.md`; preserve the validation map's approved evidence evaluation. Read `_refs/shared/convergence-contract.mjs`; verify-before-done evaluates and seals a receipt, while branch-ready verifies both against approved change/mode and current identity.
## Mode Selection

| Mode | Trigger examples | Output |
|---|---|---|
| `verify-before-done` | "verify", "verify acceptance", "is this done", "final gate" | verification report plus `ship_context` |
| `branch-ready` | "ready to merge", "branch ready", "check before PR", "ready to ship" | final read-only hygiene report plus `ship_context` |
| `ship` | "ship", "push it", "ready to merge", "create PR", "release" | write-producing tail steps, verification, final branch-ready, optional git handoff |
| `dependency-update` | "update dependencies", "update package", "bump <pkg>", "outdated", "audit fix" | protected-branch-safe dependency workflow plus regression evidence |
| `release-ready` | "release readiness", "prepare tag", "publish", "next tag" | release ledger, risk notes, final readiness verdict |

If the user asks only for an artifact-only commit, PR, changelog, or release
notes action, route to `sdcorejs-git`; that skill still rejects missing or stale
ship evidence before creating delivery artifacts. If the prompt asks whether
work is ready, should be pushed, can be merged, can be released, or is safe to
ship, stay in `sdcorejs-ship`.
## Verification Mode Classification

Classify `verification_mode` before selecting commands or criteria:

| verification_mode | Use when |
|---|---|
| `feature-acceptance` | A spec, plan, product ledger, test plan, or explicit acceptance criteria exists and must be verified criterion by criterion. |
| `bugfix-verification` | A bug fix must verify original repro, regression evidence, and broader checks when available. |
| `specless-verification` | A small change has no explicit spec or AC; verify changed scope and report manual done confirmation needs. |
| `dependency-regression` | Package manifest or lockfile changes require dependency risk, install, audit where supported, and impacted checks. |
| `docs-only-hygiene` | Documentation, prompt, skill-text, or mirror-only changes need text/mirror/routing hygiene rather than product AC. |
| `release-readiness` | Tag, release, publish, or version preparation needs a release ledger and explicit approval for destructive actions. |
| `branch-ready-only` | The user asked only for final read-only branch hygiene before Git artifact handoff. |

Rules:

- Do not treat every ship request as `feature-acceptance`.
- Bug fixes use `bugfix-verification`, not fabricated feature AC.
- Docs-only work may skip product acceptance but must still run applicable text,
  mirror, frontmatter, routing, and repo hygiene checks.
- Release/tag/publish requests use `release-readiness`; do not run tag, push,
  version bump, publish, or GitHub release commands from ship.
- Record `verification_mode` in `ship_context`.
## Acceptance Scope Selection

Select `acceptance_scope` in this order:

1. Explicit user-provided spec, path, criteria, task ID, or release range.
2. Current task, plan, spec, or active workflow context.
3. Product ledger, plan ledger, or test plan associated with the current task.
4. `review_context`, `repair_source`, `debug_context`, or `test_context` from a
   caller.
5. Changed files and current diff scope.
6. If multiple plausible scopes remain, ask one numbered choice.

Record:

```yaml
acceptance_scope:
  selected_spec:
  selected_plan:
  selected_task:
  changed_files_scope:
  criteria_count:
  manual_criteria:
  deferred_criteria:
  selection_reason:
```

Rules:

- Do not blindly pick the newest spec in a track folder.
- Do not default to Angular examples or any other track-specific sample.
- If no spec exists, use `specless-verification` or `bugfix-verification`
  instead of inventing AC.
- If multiple specs match and caller context does not disambiguate, ask the
  user to choose.

## Evidence And Command Discipline

Discover verification commands from package manager, lockfiles, workspace
configuration, package.json scripts, project config, original failing command,
`test_context`, `debug_context`, `review_context`, `repair_source`, selected
acceptance criteria, and repo docs.

Rules:

- Do not hardcode npm/npx as a universal default.
- Do not mix npm, pnpm, yarn, or bun.
- Do not invent missing scripts.
- Do not assume build, lint, test, e2e, typecheck, content, or i18n scripts
  exist.
- Do not use auto-download probe tools without explicit user approval.
- Missing scripts and unavailable tools go into `commands_skipped` with
  evidence.
- Prefer focused commands first, then broader checks when available and
  appropriate.
- In monorepos, respect workspace/package scope when detectable.
- `commands_run` includes only commands that actually ran.
- Do not mark skipped commands as PASS.

## Mode: verify-before-done

Read `_refs/orchestration/tail/verify-before-done.md` completely, then run the selected verification mode.

Feature acceptance:

- Verify every explicit AC.
- Map each AC to evidence: command, test, manual check, file inspection,
  screenshot/probe, or deferred note.
- Mark each AC `PASS`, `FAIL`, `MANUAL`, `DEFERRED`, or `NOT_APPLICABLE`.
- Do not collapse multiple ACs into a generic "tests passed" claim.
- Manual/deferred criteria require explicit user acknowledgement.
- Any failed required AC makes the verdict `BLOCKED`.

Bugfix verification:

- Consume `debug_context` or repro evidence when present.
- Verify the original repro or evidence-equivalent focused repro.
- Run the focused regression test when available.
- Run broader discovered checks when appropriate.
- Confirm diagnostic instrumentation is removed or explicitly approved.
- If original repro cannot run locally, record the gap and do not claim fixed in
  that environment.

Specless/docs-only verification:

- Use changed file scope plus discovered repo hygiene.
- Do not invent product acceptance criteria.
- For docs-only or skill-text-only work, run mirror sync/check, text hygiene,
  prompt e2e/invariant tests, markdown/frontmatter validation, or equivalent
  discovered scripts when applicable.
- Report manual done confirmation needs when no objective AC exists.

If verification fails, route to:

- `sdcorejs-repair-loop` for fixable collections of findings from
  verify-before-done;
- `sdcorejs-debug` for concrete bug/root-cause failures;
- `sdcorejs-test` for missing or large test coverage work;
- `sdcorejs-review` for quality, security, performance, accessibility, or
  architecture review requests.

Pass this `repair_source` shape when invoking repair-loop:

```yaml
repair_source:
  kind: verify-before-done
  verification_mode:
  acceptance_scope:
  original_commands:
  package_manager:
  failed_criteria:
  associated_HEAD_or_diff:
```

Do not patch source directly inside `verify-before-done`.

## Mode: branch-ready

Read `_refs/orchestration/tail/branch-ready.md` completely, then run its read-only hygiene checks.

Branch-ready is the final read-only gate immediately before `sdcorejs-git`
creates commit, PR, push, tag, or release artifacts. No writes after
branch-ready unless branch-ready is run again.

Rules:

- Branch-ready mode is read-only.
- Evidence must be tied to the current `HEAD` plus dirty diff or exact clean
  `HEAD`.
- If any source, docs, mirror, changelog, release-note, task, memory,
  formatting, codegen, or lockfile write happens after branch-ready, evidence is
  stale and branch-ready must run again.
- Hygiene blockers are not waivable for commit, PR, push, tag, or release.
  Explicit acceptance deferral is separate: apply the shared disposition table
  for local/draft delivery, preserve DEFERRED acceptance and require current
  READY hygiene. Manual notes never authorize a remote draft PR.

## Mode: ship

Use for "done, ship it", "push it", "ready to merge", "create PR", or release
requests.

Preferred order:

1. Preflight and resolve `delivery_type`, `mode`, and `verification_mode`.
2. Collect and freshness-check `explore_context`, `review_context`,
   `test_context`, `debug_context`, `repair_source`, and any prior
   `branch_ready_evidence`.
3. Complete selected write-producing tail steps before final branch-ready:
   code documentation, technical docs, user guide/aggregate, change execution records,
   explicitly owned durable backlog updates, memories, generated mirrors,
   changelog, and release notes when selected or approved.
4. Merge producer `artifact_context` entries for the same change. Preserve
   local-only and unrelated exclusions; require one explicit owner for shared
   artifacts.
5. Run `sdcorejs-cleanup (task-tail-cleanup)` for qualifying known task artifacts after durable finalization; follow `_refs/cleanup/workflow.md`.
6. After mutation, consume exact receipts, independent current cleanup snapshot and current mapped affected checks; failures block readiness.
7. Run `verify-before-done` or the appropriate verification mode over the final
   intended diff.
8. Run `branch-ready`, including read-only SDCoreJS Artifact Closure, as the
   final read-only gate over the final diff.
9. Produce `ship_context`.
10. Delegate to `sdcorejs-git` only if the user explicitly asked for commit, PR,
   push, changelog, tag, or release artifacts and final evidence is current.

If any workflow verifies before docs or changelog writes, re-run branch-ready
after those writes. No writes after branch-ready unless branch-ready is run
again.

## Mode: dependency-update

Use dependency updates as a protected-branch-safe delivery workflow.

### Protected Branch Hard Stop

Dependency updates on protected branches are a hard stop. Protected branches
include `main`, `master`, `trunk`, `production`, `stable`, `release/*`, and any
repo-defined protected branch.

Do not modify package manifests, lockfiles, or config on a protected branch.
There is no continue-on-protected-branch option. Offer only:

1. Create a feature branch and continue.
2. Create an isolated worktree.
3. Stop.

### Dependency Classification

Classify update type:

- `patch`
- `minor`
- `major`
- `security-fix`
- `transitive-lockfile-only`
- `dev-only`
- `runtime`
- `toolchain`

Do not update multiple unrelated dependency groups unless the user approved that
scope. Do not silently change package manager or lockfile format. Do not run
broad update, audit fix, or force commands that modify many packages unless the
user explicitly requested and approved the exact action.

### Package-Manager-Specific Command Matrix

Detect the actual package manager first. If project policy uses a custom
dependency script, follow that script instead of generic commands.

| Package manager | Install existing lockfile | Add/update package | Update existing package | Audit |
|---|---|---|---|---|
| npm | `npm install` or `npm ci` when appropriate and supported by policy | `npm install <pkg>@<version> --save-exact` when exact pinning is desired | `npm update <pkg>` where appropriate | `npm audit` or `npm audit --omit=dev` only if supported |
| pnpm | `pnpm install` | `pnpm add <pkg>@<version> --save-exact` when exact pinning is desired | `pnpm update <pkg>` where appropriate | `pnpm audit` if supported |
| yarn | `yarn install` | `yarn add <pkg>@<version> --exact` when exact pinning is desired | `yarn up <pkg>@<version>` or project-supported equivalent depending on Yarn version | only when supported by Yarn version/tooling |
| bun | `bun install` | `bun add <pkg>@<version> --exact` when exact pinning is desired | project-supported update command only | skip with evidence if unsupported |

Rules:

- Do not run npm commands in pnpm, yarn, or bun repos.
- Do not invent unsupported audit/update commands.
- Record `commands_run` and `commands_skipped`.
- Run impacted tests, build, typecheck, lint, and smoke checks only when
  discovered and relevant.
- Route regressions to `sdcorejs-debug` or `sdcorejs-repair-loop`; do not weaken
  checks to make the update pass.

## Mode: release-ready

Use for release, tag, publish, version, or "next tag" requests.

Collect the complete `release_evidence` schema from
`_refs/orchestration/tail/ship-context.md`. Evaluate `ready_to_ship`,
`commit_ready`, `push_ready`, `pr_ready`, `release_ready`, and
`actually_published` independently.

A local verification pass is not a commit, remote branch, PR, immutable tag,
GitHub Release, or publication. Never collapse these states.

Release readiness is blocked by unresolved Critical/High findings; failed or
mutated approved artifacts; missing/current-source-mismatched Angular golden,
Next.js production build, NestJS production OIDC/JWKS authentication, or Full
E2E evidence; portal/module revision mismatch; or `NOT RUN` evidence for a
release-required module. Supplemental smoke evidence never satisfies a full
matrix. A full live-agent coverage claim requires a current complete live
matrix.

Every evidence row must retain its evidence class, actual command, result,
source SHA/fingerprint, portal SHA, module SHA/pinned-SHA map, environment
fingerprint, and timestamp.

Rules:

- Do not create tags by default.
- Do not push tags by default.
- Do not bump versions by default.
- Do not create GitHub releases by default.
- Do not publish packages by default.
- Do not push release branches by default.
- Every destructive release action requires explicit approval.
- Release readiness may delegate changelog or release-note artifact writing to
  `sdcorejs-git (changelog mode)`, but changelog and release notes are
  write-producing artifacts and branch-ready must run after those writes.
- Final release verdict is `READY`, `READY_WITH_WARNINGS`, `BLOCKED`, or
  `DEFERRED`.
- Mention an immutable tag or Release only when it actually exists. Otherwise
  report `actually_published: NOT_PUBLISHED`.

## Context Freshness

Consume evidence from:

- `explore_context`;
- `test_context` and `test_evidence`;
- `debug_context`;
- `review_context`;
- `repair_source` or repair ledger;
- prior `branch_ready_evidence`.

For test evidence, prefer `test_context.schema_version: 2`,
`test_status`, and `test_evidence.schema_version: 2`. Legacy v1 is readable
only as historical context; map it conservatively and require a current v2 run
for verification. Authored/written tests are not verified until the matching
case ran against the current `associated_HEAD_or_diff` and the independent
result is passing.

Validate multi-run evidence rather than a single last command: required cases
must map to fresh run IDs, cleanup must succeed, skipped commands remain
skipped, and blockers remain blocking. For guide screenshots, consume
`test_evidence.captures` and `ui_capture_context`; capture evidence is valid
only when target state, real-UI auth provenance, PII screening, hash, and
artifact classification are current.

Treat context evidence as stale if files changed after it was produced or if
`associated_HEAD_or_diff` does not match the current diff. Re-run relevant
checks when evidence is stale. Do not substitute review, test, or debug evidence
for an AC unless it actually verifies that criterion.

## AI-agent delivery evidence

When `ai_agent_context` is present, freshness-check its approved spec/plan
hashes, resolved profiles, contract/target paths, validator fixtures,
deterministic evals, server-denial tests, review/repair evidence, and current
diff association. Keep offline conformance, simulated behavioral evidence, and
authorized live engine/model evidence as separate rows. Missing live evidence
is an explicit deferral, never an inferred pass. Any profile drift, provider
storage without governance, raw tool exposure, stale approval behavior,
cross-tenant reuse, invented evidence, unsafe trace payload, or weakened
zero-tolerance gate blocks readiness.

## Simplification delivery evidence

When `simplify_context` is present, freshness-check its diff-scope hash,
selected files/hunks, preserved surfaces, baseline commands, pass ledger,
post-change commands, and current test/review association.

Block readiness when any simplification write has stale post-simplification evidence,
`behavior_verification: not-verified`, protected strings/prompts/contracts
changed, public API/config/dependency drift occurred outside approved scope, a
failed pass was not reverted, or affected test/review evidence is stale.
`behavior_verification: limited` requires an explicit risk and deferral; never
describe it as verified behavior preservation.

## Secret And PII Redaction

Never echo secret values from `.env`, CI files, shell output, source files,
stack traces, audit output, package-manager logs, Git diffs, network logs,
Authorization headers, cookies, JWTs, API keys, database URLs, private keys,
passwords, customer PII, or production payloads.

Rules:

- Never print full lines that contain likely secret values.
- For suspected secrets, report only path, key/category, reason, and redacted
  evidence such as `API_KEY=[REDACTED]`.
- Do not include secrets in `ship_context`, final summaries, changelog, release
  notes, commit messages, or PR bodies.
- Suspected secrets in the diff make branch-ready `BLOCKED`.

## Mode-Specific Write Boundaries

- `verify-before-done` mode is read-only. It may invoke repair-loop, debug,
  test, or documentation as separate workflows, but it must not patch source
  directly.
- `branch-ready` mode is read-only.
- `ship` mode may orchestrate write-producing downstream workflows before final
  branch-ready and must record those writes in `ship_context`.
- `dependency-update` mode may edit package manifests and lockfiles only after
  branch/protected-branch safety and explicit update scope are clear.
- `release-ready` mode may prepare changelog or release notes only when
  selected/approved, but must not tag, push, publish, or bump versions without
  explicit approval.
- Do not commit or create PRs from `sdcorejs-ship`.

## ship_context Output

Read `_refs/orchestration/tail/ship-context.md` completely before emitting the
redacted output. Every mode returns the full contract from that reference; this
compact projection highlights the delivery-critical fields:

```yaml
ship_context:
  source: sdcorejs-ship
  decision_coverage:
    contract: <exact current decision coverage>
  goal_backward_review:
    contract: <exact current goal-backward review>
  architecture_gate: { valid: true, required: true | false, status: required | not-applicable, signals: [], bypass: <exact bypass object or null>, rationale: <exact normalized rationale> }
  architecture_context: null # exact approved object when required
  validation_map: [] # exact approved planning authority
  convergence_result_and_receipt: <compact result plus hash-verified release-evidence receipt>
  mode: verify-before-done | branch-ready | ship | dependency-update | release-ready
  verification_mode: feature-acceptance | bugfix-verification | specless-verification | dependency-regression | docs-only-hygiene | release-readiness | branch-ready-only
  associated_HEAD_or_diff:
  verification:
    result: PASS | FAIL | PARTIAL | SKIPPED
  artifact_context:
    contract: <exact artifact closure context from the canonical lifecycle ref>
  writes_after_branch_ready: []
  cleanup: null # optional exact receipts/current_snapshot/evidence_refs runtime projection
  branch_ready_evidence: { result: <result>, associated_HEAD_or_diff: <sha or diff> }
  final_verdict: READY | READY_WITH_WARNINGS | BLOCKED | DEFERRED
  git_handoff_allowed: true | false
  git_handoff_reason:
```

Never include secrets, skipped commands as passes, stale diff evidence, or a
true `git_handoff_allowed` when writes followed branch-ready or artifact closure
is not complete.

## Cross-References

- `_refs/shared/finish-gate.md` - consolidated post-code options and final branch-ready ordering.
- `_refs/orchestration/tail/verify-before-done.md` - verification mode and acceptance evidence gate.
- `_refs/orchestration/tail/branch-ready.md` - final read-only hygiene gate.
- `_refs/orchestration/tail/ship-context.md` - complete output contract and invariants.
- `sdcorejs-git` - commit, PR, changelog, release notes, tag/release artifacts.
- `_refs/angular/core-version.md` - pinned Core UI version guard for Angular dependency updates.
- `sdcorejs-repair-loop` - fixes failed review or verification findings.
- `sdcorejs-debug` - root-cause workflow for concrete failures.
- `sdcorejs-test` - test authoring and test evidence.
- `sdcorejs-review` - read-only quality evidence.
- `sdcorejs-explore` - project context and recovery evidence.
- `sdcorejs-cleanup` - bounded current-task housekeeping before affected verification and readiness.
