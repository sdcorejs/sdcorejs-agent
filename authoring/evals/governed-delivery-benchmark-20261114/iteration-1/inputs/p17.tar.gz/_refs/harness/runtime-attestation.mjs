const STATUSES = new Set(['supported', 'unsupported', 'unknown']);
const OBSERVABLE_CAPABILITIES = Object.freeze([
  'subagents',
  'concurrent_dispatch',
  'agent_cwd_binding',
  'native_worktree',
  'manual_git_worktree',
  'cancellation',
  'result_ref',
  'workspace_isolation',
]);
const VISUAL_CAPABILITIES = Object.freeze([
  'native_structured_choice', 'visual_surface', 'static_html_artifact',
  'live_visual_companion', 'visual_event_bridge', 'persistent_local_process', 'browser_auto_open',
]);

function validateVisualAttestation(visual) {
  if (!isRecord(visual) || !isRecord(visual.capabilities) || !Array.isArray(visual.observations)) {
    return ['visual attestation requires capabilities and observations'];
  }
  const errors = [];
  const seen = new Set();
  for (const name of Object.keys(visual.capabilities)) {
    if (!VISUAL_CAPABILITIES.includes(name)) errors.push(`unknown visual capability: ${name}`);
  }
  for (const observation of visual.observations) {
    if (!isRecord(observation) || !VISUAL_CAPABILITIES.includes(observation.capability)) {
      errors.push('unknown visual observation'); continue;
    }
    if (seen.has(observation.capability)) errors.push(`duplicate visual observation: ${observation.capability}`);
    seen.add(observation.capability);
    if (!evidenceIsValid(observation.evidence)) errors.push(`${observation.capability} requires evidence`);
    if (!STATUSES.has(observation.status) || visual.capabilities[observation.capability] !== observation.status) {
      errors.push(`visual observation projection differs: ${observation.capability}`);
    }
  }
  for (const name of VISUAL_CAPABILITIES) {
    if (!STATUSES.has(visual.capabilities[name])) errors.push(`invalid visual capability status: ${name}`);
    if (visual.capabilities[name] !== 'unknown' && !seen.has(name)) errors.push(`${name} requires current-session runtime evidence`);
  }
  return errors;
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function normalizeStatus(value) {
  return STATUSES.has(value) ? value : 'unknown';
}

function evidenceIsValid(value) {
  return isRecord(value) &&
    typeof value.source === 'string' && value.source.trim() !== '' &&
    typeof value.detail === 'string' && value.detail.trim() !== '';
}

function statusBoolean(value) {
  if (value === 'supported') return true;
  if (value === 'unsupported') return false;
  return undefined;
}

function derivedWorkspaceStatus(capabilities) {
  if (capabilities.native_worktree === 'supported') return 'supported';
  if (
    capabilities.manual_git_worktree === 'supported' &&
    capabilities.agent_cwd_binding === 'supported'
  ) return 'supported';
  if (
    capabilities.native_worktree === 'unsupported' &&
    (
      capabilities.manual_git_worktree === 'unsupported' ||
      capabilities.agent_cwd_binding === 'unsupported'
    )
  ) return 'unsupported';
  return normalizeStatus(capabilities.workspace_isolation);
}

export function validateRuntimeAttestation(attestation = {}) {
  const errors = [];
  const observedCapabilities = new Set();
  if (!isRecord(attestation)) return ['runtime attestation must be an object'];
  if (attestation.visual !== undefined) errors.push(...validateVisualAttestation(attestation.visual));
  if (attestation.schema_version !== 1) errors.push('schema_version must be 1');
  if (typeof attestation.adapter !== 'string' || attestation.adapter.trim() === '') {
    errors.push('adapter must be a non-empty string');
  }
  if (!isRecord(attestation.capabilities)) {
    errors.push('capabilities must be an object');
    return errors;
  }
  for (const capability of OBSERVABLE_CAPABILITIES) {
    if (!STATUSES.has(attestation.capabilities[capability])) {
      errors.push(`${capability} must be supported, unsupported, or unknown`);
    }
  }
  if (!Array.isArray(attestation.observations)) {
    errors.push('observations must be an array');
  } else {
    for (const [index, observation] of attestation.observations.entries()) {
      if (!isRecord(observation) || !OBSERVABLE_CAPABILITIES.includes(observation.capability)) {
        errors.push(`observations[${index}] has an unknown capability`);
        continue;
      }
      if (observedCapabilities.has(observation.capability)) {
        errors.push(`duplicate observation for ${observation.capability}`);
      }
      observedCapabilities.add(observation.capability);
      if (!STATUSES.has(observation.status)) {
        errors.push(`observations[${index}] has an invalid status`);
      }
      if (!evidenceIsValid(observation.evidence)) {
        errors.push(`observations[${index}] requires evidence`);
      }
      if (attestation.capabilities[observation.capability] !== observation.status) {
        errors.push(`observation projection differs for ${observation.capability}`);
      }
    }
  }
  for (const capability of OBSERVABLE_CAPABILITIES) {
    if (
      capability !== 'workspace_isolation' &&
      attestation.capabilities[capability] === 'supported' &&
      !observedCapabilities.has(capability)
    ) errors.push(`${capability} support requires current-session runtime evidence`);
  }
  if (
    attestation.capabilities.workspace_isolation === 'supported' &&
    !observedCapabilities.has('workspace_isolation')
  ) {
    const nativeEvidence =
      attestation.capabilities.native_worktree === 'supported' &&
      observedCapabilities.has('native_worktree');
    const manualEvidence =
      attestation.capabilities.manual_git_worktree === 'supported' &&
      observedCapabilities.has('manual_git_worktree') &&
      attestation.capabilities.agent_cwd_binding === 'supported' &&
      observedCapabilities.has('agent_cwd_binding');
    if (!nativeEvidence && !manualEvidence) {
      errors.push('workspace_isolation support requires current-session runtime evidence');
    }
  }
  if (
    !Number.isInteger(attestation.effective_max_concurrency) ||
    attestation.effective_max_concurrency < 1
  ) errors.push('effective_max_concurrency must be a positive integer');
  if (
    attestation.capabilities.concurrent_dispatch === 'supported' &&
    attestation.capabilities.subagents !== 'supported'
  ) errors.push('concurrent_dispatch requires supported subagents');
  if (
    attestation.capabilities.concurrent_dispatch === 'supported' &&
    attestation.effective_max_concurrency < 2
  ) errors.push('supported concurrent_dispatch requires max_concurrency of at least 2');
  if (
    attestation.capabilities.concurrent_dispatch !== 'supported' &&
    attestation.effective_max_concurrency !== 1
  ) errors.push('non-concurrent execution must have effective_max_concurrency 1');
  if (
    attestation.capabilities.workspace_isolation !==
    derivedWorkspaceStatus(attestation.capabilities)
  ) errors.push('workspace_isolation does not match worktree and worker-CWD evidence');
  return [...new Set(errors)].sort();
}

export function attestRuntimeCapabilities({
  adapter,
  defaults = {},
  observations = {},
  max_concurrency: maxConcurrency = null,
  visual_observations: visualObservations,
} = {}) {
  if (typeof adapter !== 'string' || adapter.trim() === '') {
    throw new TypeError('adapter must be a non-empty string');
  }
  if (!isRecord(defaults)) throw new TypeError('defaults must be an object');
  if (!isRecord(observations)) throw new TypeError('observations must be an object');
  for (const capability of Object.keys(observations)) {
    if (!OBSERVABLE_CAPABILITIES.includes(capability)) {
      throw new TypeError(`unknown runtime capability observation: ${capability}`);
    }
  }
  if (maxConcurrency !== null && (!Number.isInteger(maxConcurrency) || maxConcurrency < 1)) {
    throw new TypeError('max_concurrency must be a positive integer or null');
  }

  const capabilities = Object.fromEntries(
    OBSERVABLE_CAPABILITIES.map((capability) => [
      capability,
      normalizeStatus(defaults[capability]),
    ]),
  );
  const evidence = [];
  for (const [capability, observation] of Object.entries(observations)) {
    if (!isRecord(observation) || !STATUSES.has(observation.status)) {
      throw new TypeError(`${capability} observation requires a tri-state status`);
    }
    if (!evidenceIsValid(observation.evidence)) {
      throw new TypeError(`${capability} observation requires evidence`);
    }
    capabilities[capability] = observation.status;
    evidence.push({
      capability,
      status: observation.status,
      evidence: {
        source: observation.evidence.source.trim(),
        detail: observation.evidence.detail.trim(),
      },
    });
  }

  if (!Object.hasOwn(observations, 'workspace_isolation')) {
    capabilities.workspace_isolation = derivedWorkspaceStatus(capabilities);
  }
  const effectiveMaxConcurrency = capabilities.concurrent_dispatch === 'supported'
    ? (maxConcurrency ?? 1)
    : 1;
  const attestation = {
    schema_version: 1,
    adapter: adapter.trim(),
    capabilities,
    effective_max_concurrency: effectiveMaxConcurrency,
    observations: evidence.sort((left, right) =>
      left.capability.localeCompare(right.capability, 'en')),
  };
  // Opt-in group: existing orchestration attestations retain their exact shape.
  if (visualObservations !== undefined) {
    if (!isRecord(visualObservations)) throw new TypeError('visual_observations must be an object');
    const visual = { capabilities: Object.fromEntries(VISUAL_CAPABILITIES.map((name) => [name, 'unknown'])), observations: [] };
    for (const [capability, observation] of Object.entries(visualObservations)) {
      if (!VISUAL_CAPABILITIES.includes(capability)) throw new TypeError(`unknown visual capability: ${capability}`);
      if (!isRecord(observation) || !STATUSES.has(observation.status) || !evidenceIsValid(observation.evidence)) {
        throw new TypeError(`${capability} requires a tri-state status and runtime evidence`);
      }
      visual.capabilities[capability] = observation.status;
      visual.observations.push({ capability, status: observation.status, evidence: {
        source: observation.evidence.source.trim(), detail: observation.evidence.detail.trim(),
      } });
    }
    attestation.visual = visual;
  }
  const errors = validateRuntimeAttestation(attestation);
  if (errors.length > 0) {
    throw new Error(`invalid runtime attestation: ${errors.join('; ')}`);
  }
  return attestation;
}

export function toParallelRuntimeCapabilities(attestation = {}) {
  const errors = validateRuntimeAttestation(attestation);
  if (errors.length > 0) {
    throw new Error(`invalid runtime attestation: ${errors.join('; ')}`);
  }
  const capabilities = attestation.capabilities;
  return {
    runtime: attestation.adapter,
    supports_subagents: statusBoolean(capabilities.subagents),
    supports_parallel_dispatch: statusBoolean(capabilities.concurrent_dispatch),
    supports_agent_cwd: statusBoolean(capabilities.agent_cwd_binding),
    supports_native_worktree: statusBoolean(capabilities.native_worktree),
    supports_manual_worktree: statusBoolean(capabilities.manual_git_worktree),
    supports_result_ref: statusBoolean(capabilities.result_ref),
    supports_cancellation: statusBoolean(capabilities.cancellation),
    effective_max_concurrency: attestation.effective_max_concurrency,
  };
}

// Connector tools for source.read / tracker.write come only from the host's
// current-session exposure. Classification is fail-closed: a tool counts as a
// reader only when the host itself marks it read_only; a tool that claims
// source.read without that mark is treated as a writer and goes through the
// tracker.write gate. Connector-supplied descriptions are never trusted for this.
export function observeConnectorTools(runtime, action) {
  if (!['source.read', 'tracker.write'].includes(action) || !runtime ||
      typeof runtime.session_id !== 'string' || !runtime.session_id.trim() ||
      typeof runtime.mode !== 'string' || !runtime.mode.trim() || !Array.isArray(runtime.tools)) {
    return { status: 'unknown', tools: [], reason: 'current connector exposure and mode are unobserved' };
  }
  const usable = runtime.tools.filter(tool => tool && typeof tool.name === 'string' && tool.name.trim() &&
    Array.isArray(tool.actions) && Array.isArray(tool.modes) && tool.modes.includes(runtime.mode) &&
    tool.disabled !== true &&
    (tool.forbidden_actions === undefined || Array.isArray(tool.forbidden_actions) && !tool.forbidden_actions.includes(action)));
  const tools = usable.filter(tool => action === 'source.read'
    ? tool.actions.includes('source.read') && tool.read_only === true
    : tool.actions.includes('tracker.write') || (tool.actions.includes('source.read') && tool.read_only !== true)).map(tool => tool.name);
  return { status: tools.length ? 'supported' : 'unsupported', tools: [...new Set(tools)],
    reason: tools.length ? 'connector tool exposed and permitted for current action/mode' : 'no exposed permitted connector tool' };
}
