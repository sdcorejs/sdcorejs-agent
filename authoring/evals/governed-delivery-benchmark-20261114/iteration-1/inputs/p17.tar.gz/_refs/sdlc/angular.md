# Angular Portal — SDLC Reference

This file is loaded by `skills/shared/sdlc/0[1-3]-*.md` when the detected track is `angular`. It collects only the track-specific bits the cross-track skills need; do NOT duplicate the cross-track workflow here.

## Angular Classification Gate

Before writing an Angular spec/plan, classify the target project:

- `core-ui-angular`: existing Angular app depends on or imports `@sdcorejs/angular`.
- `legacy-core-ui-angular`: existing Angular app depends on or imports `@sd-angular/core`.
- `plain-angular`: Angular app exists, but neither Core UI package is installed/imported.
- `migration-request`: the user explicitly asks to install/adopt/migrate to SDCoreJS Core UI.
- `non-angular`: no Angular evidence.

The Core UI portal patterns below (`src/libs/<module>/features/<entity>`,
`MockCrudStore`, `Sd*` components, admin screens, Core UI usage summaries, and
Core UI utility classes) apply only to `core-ui-angular`,
`legacy-core-ui-angular`, new SDCoreJS portal creation, or an approved
`migration-request`. For `plain-angular`, keep the plan on the generic harness:
reuse local/shared/design-system components first, follow the existing folder
structure, use installed UI libraries only when already present, and ask for
explicit approval before adding `@sdcorejs/angular`, `@sd-angular/core`, or
`@angular/material`.

---

## Brainstorming: exploration

### Approach palette
When the user wants 2-3 options for a CRUD/workflow feature, present from this matrix:

| Approach | Summary | Pros | Cons | Best when |
|---|---|---|---|---|
| **Side-drawer CRUD** | Quick create/update drawer plus compact read-only detail facts | Fast nav, less code, less route work, scannable simple detail | Cramped >6 fields, no deep workflow | One section, <=6 fields, no approval flow |
| **UnifiedCompact (full-page)** | Same compact layout for CREATE / UPDATE / DETAIL | Simple, predictable, low cognitive load | No visual hint of mode | Medium form, mixed user skill |
| **UnifiedSplit (full-page)** | Same split layout (left title, right form) for all 3 states | Title context always visible | Slightly more layout code | Forms where the "what is this record" context matters |
| **AdaptiveSplitDetail** | CREATE/UPDATE use editable split; DETAIL uses read-only split | Rich UX, clear mode distinction | More layout code + state | Heavy workflow, many sections, trained operators |

### Workflow brainstorm
- No workflow → keep CRUD straight
- Single-step submit-approve → add `31-actions` to plan
- Multi-step (draft → review → approve → publish) → spec must list each transition + permission

### Questions to seed
- "<localized text>"
- "<localized text>"
- "<localized text>"
- "<localized text>"

---

## Brainstorming: required confirmations

### Minimum-required (blocking)
1. **Module name** — which existing module, or "create new module" with name
2. **Entity name** (camelCase identifier, e.g. `product`, `purchaseOrder`)
3. **Display label** (VI: full diacritics, e.g. "<localized text>")
4. **Detail layout** — one of: `side-drawer`, `UnifiedCompact`, `UnifiedSplit`, `AdaptiveSplitDetail` (or "let me infer from field count + workflow")
5. **Workflow** — yes / no; if yes, list transitions

### Useful-optional (defaults safe)
- Test coverage + approach (default: `standard` + `TDD` RED-first — tests are ALWAYS written, never gated behind a question; ask ONLY to override to `minimal`/`full` or `post-hoc`)
- Key list columns (auto-infer ≥3 from entity semantics if user skips)
- Key detail fields grouped by section (auto-infer if user skips)
- Validation rules (auto-infer required-vs-optional, range bounds for numerics)
- Import/export needs (default: none)
- Permission codes (default: derive from entity name)
- Architecture mode (default: `standalone-first`; ask only if portal mixes NgModule + standalone)
- Side-drawer width override (default: `md`)

### Question grouping (3-4 per turn)
**Block A — Identity**
1. Module name (existing or new?)
2. Entity name + display label

**Block B — Layout & workflow**
4. Detail layout (default UnifiedCompact)
5. Workflow yes/no; if yes, transitions
6. Side-drawer vs full-page (auto-infer if user skipped)

**Block C — Fields**
7. Key fields (or "infer from entity semantics")
8. Validation peculiarities (or "use defaults")

### Field inference rules
When user skips fields, infer from entity name + portal conventions:
- Business identifier: `code`, `projectCode`, `orderNo`, `number`, `slug`, `sku`, `username`, `employeeCode` (stable identity; create-only editable unless explicitly mutable)
- Primary display: `name` / `title` / `displayName`
- Classification/status: `category` / `type` / `status` / `state` / `active` / `enabled` / `approvalStatus` (with enum candidates from entity domain)
- Quantitative: `amount` / `price` / `quantity` / `total` (currency = VND default for VI portals)
- Temporal: `effectiveDate` / `dueDate` / `createdAt` / `updatedAt`
- Owner: `ownerId` / `assigneeId` / `departmentId`
- Notes: `description` / `note` / `remarks` (textarea, optional; full-width in read-only detail when long)
- Visual identity: `icon` / `color` / `avatar` / `logo`
- Attachments: `attachments[]` if entity domain implies file upload
- Audit: `createdAt`, `updatedAt`, `createdBy`, `updatedBy` (always in DTO; never in SaveReq)

For VI portals, all labels use full diacritics.

### Summary template
```
## Confirmed - ready for spec

| | |
|---|---|
| **Module** | <module> (existing | new) |
| **Entity** | <entityCamel> - "<Localized display label>" |
| **Layout** | <UnifiedCompact | UnifiedSplit | AdaptiveSplitDetail | side-drawer> |
| **Workflow** | <none | submit-approve-reject | …> |
| **Fields** | <N> SaveReq + <M> read-only DTO fields |
| **Tests** | <minimal | standard | full> |

Next: run `sdcorejs-spec` to draft the spec and ask for confirmation in the same gate.
```

---

## Spec

### Path conventions
Detect and preserve the target project's module, route, component, service,
public API, alias, and test layout first. The paths below are a greenfield Core
UI fallback only; they must not override an established project convention.

- Module folder fallback: `src/libs/<module>/`
- Module bootstrap fallback: `src/libs/<module>/<module>.configuration.ts`, `<module>.module.ts`, `routes.ts`, `guards/`, `configurations/`
- Entity folder fallback: `src/libs/<module>/features/<entity>/`
- Route/page shell fallback: `pages/<screen>/<screen>.component.ts`
- Feature-local child fallback: `components/<cohesive-region>/<cohesive-region>.component.ts`
- Data/collaborator fallback: use detected `services/`, `data-access/`, `mappers/`, `validators/`, or equivalent; create only justified files
- Tests: follow the detected convention; colocate `.spec.ts` only when that is the project pattern

### Architecture section emphasis
Capture:
- Standalone-first vs hybrid NgModule mode
- Which Core UI components are central (sd-table, sd-section, sd-anchor, etc.)
- Mock-first vs real-API readiness
- Permission codes introduced
- Upload-file configuration if relevant (must be at app root in `main.ts`)
- The completed `Frontend architecture plan` from
  `_refs/shared/frontend-architecture.md`: detected conventions, reuse
  decisions, route/page and feature-local component tree, responsibility and
  state ownership, service/data flow, provider lifecycle, declarations/imports,
  route registration, feature-private symbols, public exports, and tests
- Why each extracted component is cohesive and why smaller regions remain inline

### Acceptance criteria examples
- [ ] User can navigate to `/<module>/<entity>` and see ≥20 seed rows
- [ ] Create form validates: `<field>` required, `<other>` range 0-100 if `<condition>`
- [ ] Update preserves audit fields; `createdAt` unchanged after edit
- [ ] List filter by `<field>` returns only matching rows
- [ ] All Vietnamese labels render with full diacritics
- [ ] Permission `<MODULE>:<ENTITY>:CREATE` blocks non-authorized users
- [ ] (If workflow) Submit moves status DRAFT → PENDING; Approve moves PENDING → APPROVED

---

## Plan

> **Default coverage approach = `TDD` RED-first** (the orchestrator TDD gate enforces it; tests are always written, never gated behind a question). Use the **TDD phase grouping** below by default. The `post-hoc` grouping is the OVERRIDE — use it only when the user explicitly asked for post-hoc ordering.

For image, screenshot, Figma, PRD, user story, acceptance-criteria, or mixed
visual/text input, include an early implementation step that loads
`_refs/angular/write-code/input-analysis.md` and produces Core UI reuse
analysis plus the matching UI decomposition, requirement mapping, or image+PRD
mapping before code is written.

For every non-trivial Angular screen, load
`_refs/shared/frontend-architecture.md` and complete the architecture block
before generating files. Task paths come from the approved component tree and
service boundaries. A routed list/detail page is the minimum container boundary,
not the maximum number of components.

### Phase grouping — `post-hoc` coverage (OVERRIDE — only when the user explicitly chooses post-hoc)
1. **Module bootstrap** (only if new module): configuration, api configuration, guard, module, routes, register in app.routes + main.ts
2. **Entity model + service + mock**: model.ts, mock-data.ts, service.ts (MockCrudStore), index.ts
3. **Entity routes + approved component tree**: route/page containers plus only the feature-local children justified by the frontend architecture plan
4. **Form refinement (if non-trivial)**: custom validators, FormArray, cross-field rules, form sections, and child-collection editors without duplicated form/entity state
5. **Actions (if any)**: workflow transitions, bulk operations, custom side-effects via `31-actions`
6. **Tests** (at `standard` coverage by default): `.routes.spec.ts`, `.list.component.spec.ts`, `.detail.component.spec.ts`

### Phase grouping — `TDD` RED-first coverage (DEFAULT)
TDD is the default ordering: test bones come earlier. The mechanical "Module bootstrap" + "Entity model" phases don't change, but business-logic phases (form, workflow, route guards) get a test-first phase pair:

1. **Module bootstrap** — same as post-hoc
2. **Entity model + service + mock** — same as post-hoc (these are scaffold; TDD adds little here)
3. **TDD test bones** (NEW, before any business-logic code): write *failing* tests from each acceptance criterion in the spec. Empty `it()` bodies are OK; what matters is each acceptance criterion has a named test that currently fails. Targets:
   - `*.routes.spec.ts` — permission guards (test that unauthorized request is blocked)
   - `*.list.component.spec.ts` — filter behavior, sort, bulk action visibility
   - `*.detail.component.spec.ts` — state transitions (CREATE / UPDATE / DETAIL), validator triggers, side-effect (e.g. workflow action call)
4. **Entity routes + approved component tree** — implement route/page orchestration and each meaningful child contract to make Phase 3 tests pass; verify each `it` flips red → green
5. **Workflow (if enabled)** — extends Phase 3 with workflow tests, then implements actions
6. **Form refinement** — same TDD loop for custom validators (validators are easy to TDD — pure functions)
7. **Tests fill** — fill remaining `*.spec.ts` bodies that weren't covered in Phase 3 (e.g. edge cases beyond acceptance criteria)

The verification command between phases is: `npm run test -- --watch=false --include=src/libs/<module>/**/*.spec.ts` — track the red→green transition. Plan steps include explicit "expect N tests failing" → "expect 0 tests failing" markers at each phase boundary.

**Heuristic for when TDD pays off in Angular-portal**:
- High pay-off: custom validators, workflow state machines, derived/computed business logic, route guards
- Moderate pay-off: form field interdependencies (conditional fields, async validators)
- Low pay-off: list table cell rendering, simple CRUD wiring through MockCrudStore (mostly mechanical)

### Verification commands
```bash
npm install                                                                                                   # only if new portal
npm run build-dev                                                                                             # expect exit 0
npm run test -- --watch=false --include=src/libs/<module>/**/*.spec.ts
# Manual smoke
# Open http://localhost:4200/<module>/<entity> — verify list renders 20+ seed rows
# Click "<localized text>" → fill form → save → expect record appears in list
```

### Side-drawer variant
If layout is `side-drawer`, omit `pages/detail/` and add `components/detail-side-drawer/detail-side-drawer.component.ts` instead. Keep `pages/list/list.component.ts`.

- CREATE/UPDATE drawer states remain Core UI forms.
- DETAIL/view drawer state uses compact read-only facts by default for simple data: promoted business identifier in the header, optional status badge/chip near the title, label-left/value-right rows for short facts, and full-width long text only when needed.
- Do not duplicate header-promoted code/status in body facts unless the spec asks for audit/full-field view.
- A cohesive drawer with a few fields, no child collection, and no independent
  async workflow may remain one component. Do not generate one component per
  field or a facade/store without a concrete coordination need.

### Provider and public API decisions

- Detect standalone, NgModule, or hybrid style before choosing imports,
  declarations, exports, and providers. Never declare a standalone component in
  an NgModule.
- Name every service/facade scope and lifecycle reason. Stateless shared API
  services may follow the existing app/root convention; mutable feature
  facades/stores belong at route/feature/page scope; overlay coordinators belong
  at component scope; pure mappers/validators remain functions when appropriate.
- Record lazy route registration and which parent imports every feature-local
  standalone child.
- Keep route pages and feature-local children out of global barrels. Export only
  contracts with verified external consumers, and avoid cross-feature deep
  imports or `export *` barrels that can create cycles.

### Standard-coverage spec layer
- `*.routes.spec.ts` — routing guards + permission gating
- `*.list.component.spec.ts` — list rendering + filter + bulk action
- `*.detail.component.spec.ts` — form validation + CREATE/UPDATE/DETAIL state switching

### Final-step expectations
Documentation gate supplement: immediately after the finish gate's test
decision, load `_refs/documentation/gate.md`. It may save
`.sdcorejs/documentation/preferences.md`, captures `user_guide` and
`technical_doc` creation/update approval, and must ask before creating missing
corresponding user-guide or technical-doc files for a new feature.
`code-documentation` runs automatically for touched source files and is not
controlled by this gate.

The last numbered step should reference the mandatory tail-call chain (sdcorejs-test -> optional sdcorejs-simplify -> affected focused tests -> sdcorejs-review -> sdcorejs-repair-loop -> sdcorejs-documentation (code-documentation mode, automatic) -> Angular UI check when UI-affecting -> sdcorejs-documentation (write-technical-doc mode, if approved) -> _refs/orchestration/tail/auto-docs.md -> sdcorejs-documentation (write-user-guide mode, if approved) -> _refs/orchestration/tail/auto-task-tracker.md -> sdcorejs-explore (memories mode) -> sdcorejs-ship (verify-before-done mode) -> sdcorejs-ship (branch-ready mode as the final read-only gate)). Simplification is visible opt-in, never automatic, and any write invalidates affected earlier evidence. The reviewer of the plan checks that this chain is implicit, not omitted, and that no writes happen after branch-ready unless branch-ready is run again.
