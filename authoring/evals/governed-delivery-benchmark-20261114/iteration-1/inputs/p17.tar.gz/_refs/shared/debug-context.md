# Debug Context Schema

> Loaded by `sdcorejs-debug` to make bug investigations reproducible and safe to
> hand off to `sdcorejs-ship`, `sdcorejs-review`, `sdcorejs-repair-loop`, and
> `sdcorejs-git`.

## Required Runtime Context

Every debug session builds a redacted `debug_context` for its exact consumer.
Pass it through `context.pass`; do not echo the full block in the user-facing
result by default. The projection keeps outcome, root cause, touched paths,
verification, blockers, skipped checks, risk, and next action. If
`runtime_context_channel` is unsupported or unknown, send the validated
portable handoff from `_refs/harness/communication-economy.md`.

```yaml
debug_context:
  source: sdcorejs-debug
  schema_version: 1
  registry_version:
  subject_track:
  intent: diagnose-only | fix
  artifact_identity:
    owner_repository_id:
    owner_module_id:
    execution_host_repository_id:
  failing_implementation:
    repository_id:
    path:
    source_revision:
  source_fingerprint:
  source_revision_map: {}
  environment_fingerprint:
  approved_plan_step:
    step_id:
    approval_hash:
    owner_repository_id:
    allowed_paths: []
  test_evidence:
    repository_id:
    source_revision:
    source_fingerprint:
    status: current | stale
  debug_mode: runtime-error | failing-test | wrong-behavior | flaky | ci-only | prod-only | performance-anomaly | environment-config | dependency-regression | security-sensitive | data-integrity | build-compile | browser-device-specific | unknown
  bug_class: null-or-undefined | async-race | state-lifecycle | validation | permission-authz | authentication | routing | database-query | transaction-consistency | serialization-deserialization | caching-staleness | timezone-locale | dependency-version | configuration | environment | network-third-party | type-contract | test-contract | performance-regression | memory-leak | unknown
  stack_profile: core-ui-angular | legacy-core-ui-angular | plain-angular | sdcorejs-nestjs | plain-nestjs | nextjs-build-website | plain-nextjs | react-vite | react-cra | react-next-generic | node-general | general
  repro_status: local-confirmed | evidence-confirmed | flaky-confirmed | blocked
  observed:
  expected:
  root_cause:
  root_hypothesis_id:
  confidence: high | medium | low
  files_touched:
    - path
  diagnostic_instrumentation:
    added:
    removed:
    remaining:
  regression_tests:
    added:
    updated:
    delegated_to_sdcorejs_test:
  commands_run:
    - command:
      result:
      exit:
      notes:
  commands_skipped:
    - command_or_probe:
      reason:
  package_manager:
  environment:
  secret_redaction:
    applied: true | false
    notes:
  verification:
    original_repro:
    focused_regression:
    broader_checks:
    flaky_retry_summary:
  ship_handoff:
    needed: true | false
    reason:
```

## Rules

- Do not include secrets, PII, raw production payloads, or full secret-bearing
  lines.
- `commands_run` must contain only commands that actually ran.
- Missing scripts, unsafe probes, and blocked environments belong in
  `commands_skipped` with evidence.
- Do not claim tests, build, lint, repro, CI, staging, or production passed
  unless the command or environment verification actually passed in the current
  session.
- If `repro_status` is `evidence-confirmed`, record what evidence replaces
  local reproduction and what original environment verification remains.
- If `repro_status` is `flaky-confirmed`, record pass/fail counts and sample
  size.
- Validate identity, freshness, plan authority, and write scope through
  `_refs/shared/debug-contract.mjs`. `diagnose-only` is always read-only.
- A single successful retry is not fix evidence. Retried flaky verification
  remains bounded and records its sample; no infinite retry loop is allowed.
- Do not mutate an approved spec, plan, approval hash, or acceptance criterion
  to make a failure disappear.
- If `repro_status` is `blocked`, record the missing evidence and do not report
  the bug as fixed.

## Handoff Use

- `sdcorejs-ship` consumes `debug_context.verification`, changed files,
  regression test evidence, and `ship_handoff`.
- `sdcorejs-review` can use `debug_context` for a follow-up security,
  performance, architecture, accessibility, or code review.
- `sdcorejs-repair-loop` preserves original finding IDs and may include
  `debug_context` when a repair item became a single-bug investigation.
- `sdcorejs-git` may summarize current redacted `debug_context` in commit or PR
  artifacts only after ship gates pass and the user asks for those artifacts.
