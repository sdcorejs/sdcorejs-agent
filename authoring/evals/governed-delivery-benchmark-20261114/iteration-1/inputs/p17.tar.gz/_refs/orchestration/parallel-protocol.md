# Parallel Dispatch Protocol v2

Normative protocol for `sdcorejs-parallel-dispatch`. The skill must apply every
required validation below before it treats a unit or integration state as safe.
The distributed `_refs/orchestration/parallel-protocol.mjs` module implements
the mechanically enforceable subset. Passing its tests is not evidence that an
external runtime invokes it or enforces the remaining orchestration rules.
It consumes `_refs/shared/approved-artifact.mjs` and
`_refs/shared/system-registry.json`; local enums or unverified plan identity
cannot authorize dispatch.

## Contents

- [Contract Union](#contract-union)
- [Read-only Opportunity Discovery](#read-only-opportunity-discovery)
- [Required Context](#required-context)
- [Working-tree Preflight](#working-tree-preflight)
- [Runtime Capability Fallback](#runtime-capability-fallback)
- [Plan Compilation And Opportunity Report](#plan-compilation-and-opportunity-report)
- [Topology And DAG Rules](#topology-and-dag-rules)
- [Isolation And Resource Validation](#isolation-and-resource-validation)
- [Mechanical Path-boundary Validator](#mechanical-path-boundary-validator)
- [Deterministic Fan-in](#deterministic-fan-in)
- [Repair Assignment](#repair-assignment)
- [Contract Revision](#contract-revision)
- [Failure Policy](#failure-policy)
- [Evidence And Redaction](#evidence-and-redaction)
- [State Machine](#state-machine)
- [Final Tail](#final-tail)

## Contract Union

`contract.source` is the discriminator.

```yaml
contract:
  source: approved-plan
  contract_id: <stable id>
  approved_plan_path: <immutable snapshot path>
  approved_plan_hash: <hash>
  frozen_contract_path: <path or embedded>
  frozen_contract_hash: <hash>
  revision: <integer>
  supersedes: <prior contract id or null>
```

The `approved-plan` branch is mandatory if any unit can write.

```yaml
contract:
  source: read-only-request
  request_hash: <hash of normalized request>
  scope_hash: <hash of file/report scope>
  write_policy: deny
```

The `read-only-request` branch must omit approved-plan fields. Its unit
allowlists are empty, workspace strategy is `shared-readonly`, result type is
`report`, and before/after changed paths must be empty. A detected write is
`PATH_VIOLATION -> UNIT_FAILED`.

## Read-only Opportunity Discovery

`sdcorejs-debug`, `sdcorejs-review`, and `sdcorejs-explore` screen substantial
independent domains after their initial scoped reads, without requiring the
user to say "parallel". Call `assessReadOnlyOpportunity` before constructing a
full read-only contract. This small runtime projection is not a durable artifact
or a second scheduler:

| Input | Evidence required |
|---|---|
| `owner_skill` | The selected debug/review/explore owner, or direct parallel-dispatch entry. |
| `task_mode` | `read-only` for this investigation phase; fixing remains a later owner action. |
| `delegation_allowed` | `true` only when the actual host/session policy permits this delegation. An explicit-only host needs an actual user request; capability alone is not authority. |
| `worker_context` | `false` only for the coordinating owner; workers never recurse. |
| `execution_policy` | `auto` or `parallel-preferred`; explicit sequential/no-agent choices suppress fan-out. |
| `independence` | `status: confirmed` and nonempty `evidence` paths/report references from the initial investigation. Unknown or coupled work stays with the owner. |
| `units` | At least two units with unique `id`, specific `objective`, bounded `readable_paths`, `substantial: true`, and explicit empty `depends_on`. |
| `units[].ownership` | Empty `allowed_paths`, classified `exclusive_resources` and `shared_readonly_resources`. Reads may share source; mutable resources cannot overlap another unit's readers or writers. |

The host derives these facts from current instructions and inspected evidence,
not by trusting a user-supplied JSON object, file names, or task counts. A unit is
substantial when its investigation has enough independent analysis to justify a
fresh context and result review; a one-command lookup or a tiny diff is not.
Classify shared fixtures, common services, initialization, mutable caches, ports,
database namespaces and output dependencies before claiming independence. A
different test filename is not evidence of a different problem domain.

`evaluate-scheduler` is only a discovery result. It always carries
`dispatch_authorized: false`, `contract_source: read-only-request`, and
`write_policy: deny`. The owner must still bind the actual request/scope hashes,
attest the current runtime, fill and validate the complete v2 contract, and call
`compileParallelContext`. Unknown capability, unavailable isolated context, or
missing evidence retains a parent/sequential fallback. `continue-in-owner`
keeps work moving without prompting merely to make parallelism possible.

Examples:

- Auth and billing failures with separate repro evidence and no common failing
  dependency: one evidence-only investigation per problem domain.
- Two substantial module reviews: scoped reviewers, with shared invariants and
  cross-module checks retained by the parent.
- Two unrelated feature traces: bounded explorers return paths and edges;
  the parent reconciles shared relationships.
- Ten failures caused by one fixture, an unknown regression, a dependent trace,
  one cheap command, or an explicit no-agent request: keep one investigation.

Issue ready worker dispatches without waiting for each prior result when the
runtime actually supports concurrency; tool-call grouping alone is not proof
of parallel execution. Bound the wave by current concurrency limits. Start
fresh isolated contexts, not forks of the parent conversation. Every brief
contains one objective, exact scope, relevant failures/questions, bounded source
references, constraints, expected evidence and escalation conditions.

For report fan-in, the owner verifies unchanged workspace/source identity,
spot-checks citations and hypotheses, deduplicates findings, reconciles conflicts,
and reports missing/failed units. A newly discovered shared cause returns to one
investigation. Read-only fan-in applies no patches, reruns no mutating repros,
refreshes no summaries, and creates no Git artifacts. Only write-capable
execution has the implementation repair and final ship tail; report verification
is proportional to the original question.

## Required Context

Keep the complete structure as authoritative runtime state. Do not echo it in
routine user output. Pass it to the execute-plan parent or final ship consumer
through `context.pass`; when `runtime_context_channel` is `unsupported` or
`unknown`, the Communication Economy Policy portable matrix must preserve the
contract, target, working-tree identity, capability verdict, topology,
integration, units, failure/redaction policy, global verification, and final
tail. Missing or malformed state fails closed.

```yaml
parallel_context:
  schema_version: 2
  source: sdcorejs-parallel-dispatch

  contract:
    source: approved-plan | read-only-request
    # Include exactly one complete union branch from Contract Union above.

  target:
    repo_root:
    target_root:
    target_root_kind:
    track:
    stack_profile:
    repository_revision_map: {}

  working_tree:
    repo_root:
    current_branch:
    current_head:
    expected_branch:
    expected_head:
    status_snapshot_hash:
    dirty_diff_hash:
    staged_paths: []
    unstaged_paths: []
    untracked_paths: []
    unrelated_dirty_paths: []
    intended_output_paths: []
    user_dirty_tree_decision:

  runtime_capabilities:
    runtime:
    supports_subagents:
    supports_parallel_dispatch:
    supports_agent_cwd:
    supports_native_worktree:
    supports_manual_worktree:
    supports_result_ref:
    supports_timeout:
    supports_cancellation:
    effective_max_concurrency:

  topology:
    kind: READ_ONLY_FANOUT | INDEPENDENT_WRITE_UNITS | CONTRACT_BOUND_ROLES | SEQUENTIAL_DAG
    verdict: SEQUENTIAL | PARALLEL-CANDIDATE | ROLE-SPLIT

  integration:
    integration_owner_repository_id:
    workspace_path:
    branch:
    base_head:
    merge_strategy: cherry-pick | patch | disjoint-same-tree
    merge_order: []
    atomicity: all-or-nothing | independent-successes | user-decision
    rollback_strategy: <required executable strategy for all-or-nothing>

  units:
    - id:
      role:
      wave:
      depends_on: []
      produces: []
      consumes: []
      contract_hash:

      dispatch_envelope:
        schema_version: 1
        contract_id:
        plan_artifact_id:
        plan_approval_hash:
        repository_id:
        repository_role:
        module_id:
        git_root:
        source_revision:
        allowed_paths: []
        prohibited_paths: []
        authority: read-only | read-write
        git_mutations: deny
        approved_artifact_mutation: deny
        required_validations: []
        output_evidence_contract:
          result_type: report | commit | patch | working-tree-diff
          required_fields: []

      workspace:
        strategy: shared-readonly | disjoint-same-tree | worktree
        path:
        branch:
        base_head:
        created_by_current_run:
        mechanically_disjoint: true | false

      ownership:
        allowed_paths: []
        prohibited_paths: []
        generated_outputs: []
        shared_config_paths: []
        module_gitlinks:
          - repository_id:
            path:
        shared_files:
          - path:
            repository_id:
            owner: integration-unit
        exclusive_resources: []
        shared_readonly_resources: []
        allocated_ports: []
        database_namespace:
        temp_root:
        cache_root:
        coverage_root:

      task:
        exact_scope:
        approved_plan_slice:
        out_of_scope: []

      verification:
        command:
        cwd:
        timeout_seconds:
        expected_artifacts: []

      result:
        type: report | commit | patch | working-tree-diff
        ref:
        base_head:
        associated_head_or_diff:
        changed_paths: []
        exit_code:
        output_digest:
        blockers: []
        repository_id:
        repository_role:
        module_id:
        source_revision:

      status: PENDING | RUNNING | PASSED | FAILED | BLOCKED | CANCELLED | STALE
      attempts: 0

  failure_policy:
    mode: fail-fast | best-effort
    max_attempts:
    timeout_seconds:
    cancel_pending_on_blocker:
    merge_successful_units_on_partial_failure:
    retry_transient_failures:
    rollback_on_global_failure:
    checkpoint_path:

  redaction:
    excluded_paths: []
    excluded_patterns: []
    secret_scan:
    pii_redacted:
    logs_sanitized:
    notes:

  global_verification:
    commands_planned: []
    commands_skipped: []
    associated_head_or_diff:
    output_digest:

  final_tail:
    verify_before_done: true
    branch_ready_final_gate: true
    no_writes_after_branch_ready: true
```

Fields are operational:

- hashes select the immutable contract/result state;
- the dispatch envelope binds each unit to the verified artifact, semantic
  repository/module owner, one Git root, authority, and evidence contract;
- workspace fields select the unit checkout and prohibit wrong-cwd execution;
- ownership fields feed repository-aware path, generated-output, shared-config,
  gitlink, and runtime-resource conflict validation;
- dependency fields generate waves;
- verification and result fields bind evidence;
- failure fields decide retries, partial integration, rollback, and checkpointing;
- redaction fields constrain briefs and logs;
- final-tail booleans reject invalid write-workflow combinations.

## Working-tree Preflight

For write work, record branch, HEAD, porcelain status, staged/unstaged/untracked
paths, a canonical status hash, dirty diff hash, unrelated dirty paths, and
whether intended outputs already exist or overlap dirt. Compare branch and HEAD
with the approved baseline. Reuse the decision prompt from
`sdcorejs-execute-plan` for unrelated changes.

Fail closed when branch/HEAD mismatch, target-root identity, existing output,
or dirty ownership cannot be resolved. Read-only mode records HEAD and a status
snapshot so an after-snapshot can prove zero writes.

## Runtime Capability Fallback

| Capability result | Required behavior |
|---|---|
| no subagents | sequential parent execution |
| subagent calls serialize | sequential fresh workers; report no concurrency |
| no agent cwd | read-only or mechanically proven `disjoint-same-tree` only |
| no immutable result ref | exact changed-path/diff snapshot bound to evidence |
| no timeout/cancellation | best-effort reporting; no fail-fast cancellation claim |
| unknown isolation for write-heavy work | sequential fresh workers when delegation is supported; parent only when it is not |

The effective concurrency is the smaller of runtime capacity, safe unit count,
and repository/resource limits.

Build current-session evidence with
`_refs/harness/runtime-attestation.mjs`. Static adapter capability values are
defaults, not proof that a capability is exposed now. An unknown observation
never becomes `true` in the parallel capability projection.

## Plan Compilation And Opportunity Report

`compileParallelContext` accepts compact `parallel_candidates.units` from the
approved plan plus validated parallel runtime capabilities. Parallel eligibility
requires `parallel_candidates.allowed: true`; each unit needs an ID, dependency
IDs, non-empty owned paths, and optional exclusive resources and positive
estimated cost. Missing approval or ownership produces sequential blockers and
repair suggestions. The compiler normalizes ownership, calls the same
`planWaves` algorithm used by topology classification, and returns:

- a schema-v2 `parallel_context` scaffold with `dispatch_ready: false` until
  workspace, envelope, integration, verification, and final-tail evidence is
  complete;
- deterministic waves;
- topology/verdict and selected mode;
- effective maximum parallelism;
- estimated serial cost, bounded parallel cost, and savings;
- blockers and concrete repair suggestions.

The approved `execution_policy` is `auto`, `sequential`, or
`parallel-preferred`. `auto` selects parallel only for a safe positive-savings
wave. A policy never bypasses capability, ownership, resource, workspace, or
contract validation.

## Topology And DAG Rules

Classification uses dependency edges; repository ID and Git-root identity;
normalized allowed, generated-output, shared-config, coordinated-file, and
module-gitlink overlap; exclusive resource overlap; expected benefit;
coordination/review cost; blast radius; runtime capability; and integration
complexity. Equal relative paths in different repositories are disjoint, but
two repository identities on one physical Git root are invalid. Unit count and
role names alone are insufficient.

Topologically sort units into deterministic waves. A cycle or missing dependency
is blocking. Derive roles from the plan; do not manufacture Product, Design,
Backend, Frontend, or QC units. Test authoring may run before integration when
its inputs are frozen. Cross-stack execution consumes integrated results and
therefore runs in a later wave.

## Isolation And Resource Validation

`shared-readonly` compares before/after Git and filesystem snapshots and fails
on any change.

`disjoint-same-tree` is allowed only when normalized ownership does not overlap
and commands cannot mutate shared state. Repository-wide formatters, install or
lockfile operations, generators, Git index/staging, shared databases, shared
outputs/caches, ports, browser profiles, Compose project names, test accounts,
snapshot directories, and coverage roots require unique allocation or a
separate wave.
Set `mechanically_disjoint: true` only after these checks are recorded; absence
or `false` demotes the unit to worktree or sequential execution.

Normalize typed resource claims before comparison: a declared `port:3000` and
`allocated_ports: [3000]` are the same claim. Temp/cache/coverage roots use
canonical separators and case rules; equal or parent/child roots conflict.

`worktree` uses one worktree/branch per unit, a common approved base, and a
separate integration workspace. Verify result ancestry/base before fan-in.
The runtime must attest native worktree support or both manual-worktree support
and worker-CWD binding before a worktree unit can dispatch.
Record which worktrees the current run created. Cleanup may remove only those
recorded worktrees after verifying their resolved paths; never remove a
pre-existing or nested worktree.

Before each worker operation, validate the dispatch envelope against the
current repository ID and resolved Git root. Workers cannot cross roots, write
an unassigned shared/coordinated path, mutate an approved artifact, or stage,
commit, or push. When the result protocol calls for an immutable commit, the
primary integration agent creates it from the validated exact diff.

## Mechanical Path-boundary Validator

The parent/integration owner, not the unit report, performs this algorithm:

1. Obtain actual tracked, staged, unstaged, untracked, added, deleted, and
   renamed paths from Git plus relevant filesystem evidence.
2. Expand a rename into source deletion and destination addition.
3. Normalize separators and `.` segments; reject absolute paths and `..`
   escapes. Apply filesystem case rules.
4. Resolve existing symlinks and every existing ancestor of new paths. Reject
   an escape from the repository real path.
5. Detect submodule and nested-repository boundaries; allow them only when the
   approved contract explicitly owns that repository operation.
6. Match every normalized actual path against the unit allowlist and prohibited
   list. Lockfiles, manifests, env/migration files, frozen contracts, and shared
   generated artifacts remain prohibited unless explicitly approved.
7. Detect repository-aware parent/child and glob overlap, generated output,
   shared config, module gitlink, and Git-root conflicts before dispatch.
8. Compare the computed list with the unit's report. A mismatch is failure, not
   a warning.
9. Store the exact normalized actual list in result/evidence.

Any formatter, generator, install, or other command that spills outside scope
causes `PATH_VIOLATION -> UNIT_FAILED`.

## Deterministic Fan-in

For each ID in `integration.merge_order`:

1. Require status `PASSED` and an existing result ref/snapshot.
2. Verify expected base and commit ancestry or patch/diff base binding.
3. Recompute actual paths and run the path-boundary validator.
4. Run Stage A scope/result validation.
5. Run Stage B review and permitted owner-bound repair.
6. Apply exactly one result using `merge_strategy`.
7. Run its required integration probe before continuing.
8. Record the new integration HEAD/diff and invalidate assumptions tied to the
   prior integration state.

After all accepted results, run complete global verification. A conflict,
patch failure, failed probe, or unit that fails only after another integration
transitions to `INTEGRATION_BLOCKED`.

Path/Stage A and Stage B verdicts are parent-owned structured evidence bound to
the unit result identity. Missing callbacks, `undefined`, stale identities, or
unit-authored boolean claims are not pass verdicts.

Atomicity:

- `all-or-nothing`: preserve the pre-fan-in base and roll back only results
  created/applied by this run when integration/global verification fails. Mark
  the transaction dirty before each apply so a partially mutating apply that
  throws also triggers rollback; verification exceptions do the same;
- `independent-successes`: preserve verified independent results but do not
  represent the overall run as passed;
- `user-decision`: stop before partial fan-in and request the numbered choice.

Never perform destructive rollback on unrelated user state. Retry only a
classified transient integration failure within `max_attempts`; conflicts,
path violations, contract violations, stale bases, and deterministic test
failures are not automatic retries.

## Repair Assignment

```yaml
repair_assignment:
  finding_id:
  original_unit_id:
  repair_owner: original-unit | integration-owner
  workspace_path:
  base_result_ref:
  contract_hash:
  allowed_paths: []
  ownership_transfer_approved: false
```

Default to original unit, original workspace, original scope, current contract
hash, and exact result. A repair write stales prior evidence. A cross-unit
finding may transfer to an integration owner only after explicit classification,
recorded ownership transfer, updated scopes, and invalidation of affected
results/evidence. Re-run path validation, Stage A, Stage B, and verification.
Deferred blocking findings remain `BLOCKED` and cannot fan in.

## Contract Revision

The frozen contract records path, hash, revision, approved-plan source hash,
and superseded identity. A non-semantic erratum still creates a new explicit
hash/revision and causes affected units to acknowledge it and evidence to be
re-evaluated.

A behavioral, scope, permission, ownership, API/data shape, route, validation,
acceptance, or deliverable change is material:

```text
CONTRACT_CHANGED -> PLAN_REVISION_REQUIRED
```

Stop affected dispatch/fan-in, create and approve a new immutable plan snapshot,
issue a new contract identity, mark dependent prior results/evidence `STALE`,
then re-brief and rerun affected units.

## Failure Policy

Record timeout per unit, transient/deterministic classification, bounded retry
count (at most three attempts),
runtime cancellation support, straggler handling, partial-success policy,
rollback, checkpoint path, and idempotency key (`contract_hash + unit_id +
attempt + base_head`). A crash/no result, claimed success with non-zero exit,
fake path report, timeout, or deterministic violation is not `PASSED`.

`runUnitsWithPolicy` remains sequential unless concurrent dispatch is explicitly
supported and a positive effective maximum concurrency is supplied. It then
runs a bounded worker pool and returns results in input order. Fail-fast stops
new scheduling; already-started units remain in flight and retain their actual
result. It marks never-started work cancelled only when the runtime supports
cancellation; otherwise those units remain pending with best-effort status.
Best-effort may finish independent units but does not fan in blocked results.

## Evidence And Redaction

```yaml
verification_evidence:
  repository_id:
  repository_role:
  module_id:
  source_revision:
  command:
  cwd:
  started_at:
  finished_at:
  exit_code:
  associated_head_or_diff:
  output_digest:
  environment_fingerprint:
```

The associated identity must be the exact commit, patch, or canonical diff and
must repeat the envelope's repository/module identity and source revision.
Wrong owner, cwd, old HEAD, output digest mismatch, or any later write makes
evidence stale. Integration requires new integration evidence. Global
verification must run after the final accepted result. Read-only evidence also
stores the empty changed-path proof and retains write authority as denied.

Redaction excludes secret/env/key/credential paths and configured patterns from
briefs and logs, runs an available secret scan, records PII/log sanitation, and
never copies unnecessary repository/customer content.

## State Machine

Normal progression:

```text
PRECHECK -> CLASSIFIED -> ISOLATED -> BRIEFED -> DISPATCHED
-> UNIT_REVIEWED -> UNIT_VERIFIED -> FAN_IN -> GLOBAL_VERIFIED -> BRANCH_READY
```

Exceptional transitions:

```text
CONTRACT_CHANGED -> PLAN_REVISION_REQUIRED
PATH_VIOLATION -> UNIT_FAILED
BLOCKING_FINDING -> UNIT_BLOCKED
UNIT_REPAIRED -> UNIT_REVIEWED
WRITE_AFTER_VERIFY -> GLOBAL_VERIFICATION_STALE
WRITE_AFTER_BRANCH_READY -> BRANCH_READY_STALE
MERGE_CONFLICT -> INTEGRATION_BLOCKED
```

Invariants:

1. No write unit dispatches without base, workspace, ownership, verification,
   result, and evidence protocols.
2. Only `PASSED` units fan in.
3. Any out-of-scope path fails the unit.
4. Contract revision stales affected results/evidence.
5. Repair writes stale affected evidence.
6. Integration changes require integration verification.
7. Writes after verification or branch-ready invalidate that state.
8. Read-only units produce zero changed paths.
9. Deferred blocking findings are `BLOCKED`.

## Final Tail

Write-capable contexts cannot represent `verify_before_done: false`,
`branch_ready_final_gate: false`, or `no_writes_after_branch_ready: false`.
Run every write-producing tail step first. Verify-before-done and branch-ready
are read-only. A later write transitions to stale and requires both relevant
checks to rerun before any Git artifact handoff.
