> **Reference for the `sdcorejs-angular` orchestrator.** Loaded on demand when the
> confirmed plan adds a new entity with full CRUD pages (model + service + routes + list +
> detail). Not a standalone skill — the orchestrator reads this file when its dispatch table
> routes a step here. For list-only refinement see `./screen-list.md`; for detail/form work see
> `./screen-detail.md`; for action buttons see `./actions.md`.

# Init Entity — Entity CRUD Module

## Contents

- [Reference and Description](#1-reference-name)
- [Rules](#3-rules)
- [Templates and Code Samples](#4-templates-and-code-samples)
- [Example Input](#5-example-input)
- [Functional Test Templates](#5-spec-templates-functional-testing)
- [Example Output](#6-example-output)
- [Implementation Checklist](#implementation-checklist)

## 1. Reference Name
**Entity CRUD Module Generation**

## 2. Description
Generates a complete entity management feature following sdcorejs architecture
patterns. It creates the approved service/model boundaries, routed page
containers, and any meaningful feature-local child components required for CRUD,
forms, tables, child collections, or workflows.

This reference can synthesize UI structure from PRD text, screenshot/attribute images, mock API contracts, OpenAPI/Swagger/Postman artifacts, JSON examples, and sample cURL payloads, then map those into CREATE/UPDATE/DETAIL rendering strategies. When those artifacts are present, first complete `./input-analysis.md` so Core UI reuse, local project reuse, image decomposition, requirement mapping, and API/service assumptions are explicit before files are created.

Before generating a non-trivial screen, complete
`_refs/shared/frontend-architecture.md`. The approved component tree and service
boundaries are the generation manifest; this reference must not collapse them
back into a fixed list/detail pair.

This reference assumes the target feature module is already known. If the request does not specify a module, the agent must resolve that first using the request intake flow.

For common entity forms with around 5-6 fields, prefer a side-drawer detail UI before using a full page detail.

Before generating or extending any model, interface, type, service, store, repository, or API client, read `./reuse-existing-entities.md` and complete its reuse preflight.

Before writing formatter, validator, mapper, pipe helper, mock-data helper, paging/filter helper, random-id helper, query-param helper, upload/download helper, or clipboard/browser helper code, read `_refs/shared/sdcorejs-utils.md` and reuse `@sdcorejs/utils` when it covers the behavior. Do not create local Date/Number/String/Validation/Array/Filter/Object/Color/Browser utility functions unless the shared package does not cover the required behavior.

## 3. Rules

### MUST DO ✅
- Confirm target module before generating entity files
- Generate the feature module first if it does not exist (see `./init-module.md`)
- For PRD, user story, acceptance criteria, screenshot, wireframe, Figma, mockup, mock API, OpenAPI/Swagger, Postman/Insomnia, JSON fixtures, sample cURL, or mixed visual/text input, read `./input-analysis.md` before deriving UI structure or creating components
- Read `_refs/shared/frontend-architecture.md`, inspect existing project
  conventions, and complete the Frontend architecture plan before creating any
  non-trivial page/component/service file
- For mock API, OpenAPI/Swagger, Postman/Insomnia, MSW/WireMock/Prism/JSON Server specs, endpoint tables, schemas, JSON fixtures, or sample cURL, read `./mock-api-input.md` before deriving model/service/screen contracts
- Identify the primary entity and every related entity from API docs, mock API contracts, PRDs, Figma/image/screenshot input, business descriptions, cURL payloads, or schemas before creating files
- Before creating model/interface/type/dto/service/store/repository/API-client files, scan the target codebase for existing contracts and symbols using the variants listed in `./reuse-existing-entities.md`
- Decide `reuse`, `extend`, or `create new` for each entity and present a short pre-code summary of found contracts, imports to reuse, existing files to extend, truly new files to create, and why duplicates are not created
- Check `@sdcorejs/utils` before adding utility/helper functions; reuse `DateUtilities`, `NumberUtilities`, `StringUtilities`, `ValidationUtilities`, `ArrayUtilities`, `FilterUtilities`, `Utilities`, `ObjectUtilities`, `ColorUtilities`, `BrowserUtilities`, models, and constants when applicable
- Generate mock CRUD only for an explicitly approved `technical-prototype`
  whose assumptions include `mock-service`.
- Generate `services/[entity].mock-data.ts` only when `seed-data` is approved;
  use the approved row count rather than an implicit range/default.
- In explicit technical-prototype mode, missing API/backend/design is tolerable
  only when the approved assumptions define the substitute. Derive a safe
  EntitySchema from approved requirements and record assumptions.
- In explicit technical-prototype mode, generate only approved
  list/detail/create/update states by customizing the
  established entity templates and Core UI component gates. Do not self-design an
  alternate listing, detail, form, dashboard, or page layout system for speed.
- When `seed-data` is approved, generate it immediately after `SaveReq` and
  `DTO` are finalized; if row count is absent, block for approval rather than
  inventing a default.
- Seed rows must use domain-realistic values derived from the inferred field schema; never use generic placeholders like `"Name 1"`, `"Code 01"`, or repeated identical values across all rows
- Ensure mock store reseeds automatically when stored JSON is missing, empty array, or corrupted JSON
- For an approved technical prototype with `mock-service` and no runnable
  backend, keep mock-first service mode while matching the approved contract.
- If a runnable backend endpoint, base URL/configuration, auth expectation, and project service convention are provided explicitly, service may switch to `BaseService`-based API integration
- Treat Service public models as the Service-Component contract, not as a forced exact copy of the raw backend API:
  - `SaveReq` / `CreateReq` / `UpdateReq` describe what the Service accepts and sends after mapping.
  - `DTO` / `ListRes` / `DetailRes` describe what the Service returns or guarantees to components.
  - Raw backend-only fields live in internal API types near the Service/mapper (for example `<Entity>ApiRes`) and are mapped before reaching components.
  - Every field exposed by a Service model must be accepted, processed, returned, or derived by that Service/mapper.
- When deriving fields for UI convenience (for example `displayName`, `label`, `color`, `icon`), decide ownership explicitly:
  - Service-owned derived fields belong in the Service DTO and are populated by the mapper.
  - Screen-only fields belong in a component-local ViewModel such as `<Entity>RowVM`, `<Entity>TreeNodeVM`, or `<Entity>DetailVM`.
- Parse and normalize input artifacts when available:
  - PRD text sections
  - screenshot or attribute image hints
  - mock API endpoint tables
  - OpenAPI/Swagger/Postman/Insomnia/MSW/WireMock/Prism/JSON Server artifacts
  - JSON request/response fixtures
  - sample cURL request/response
- Derive a field matrix from artifacts before coding:
  - list columns
  - create/update editable fields
  - detail read-only fields
  - validators and enum candidates
  - request/response field mapping
- Classify every field by UI/business role before selecting a primitive control:
  - Business identifier / business key: `code`, `projectCode`, `orderNo`, `orderNumber`, `number`, `slug`, `sku`, `username`, `employeeCode`, and similar stable user-facing identifiers.
  - Primary display: `name`, `title`, `displayName`.
  - Lifecycle/status: `status`, `state`, `active`, `enabled`, `approvalStatus`.
  - Long text: `description`, `note`, `notes`, `remark`, `remarks`.
  - Visual identity: `icon`, `color`, `avatar`, `logo`, `image`.
  - Server identity/audit: `id`, `uuid`, `createdAt`, `updatedAt`, `createdBy`, `updatedBy`, and backend-managed metadata.
- Treat business identifiers as stable identity by default, not as ordinary editable strings:
  - CREATE: editable only when the create API accepts the value.
  - UPDATE: disabled/read-only unless the artifact explicitly says the business key can change.
  - DETAIL: read-only and eligible for header promotion in simple detail/side-drawer views.
  - After any whole-form `enable()` in UPDATE, re-apply immutable-control locks from the detail screen rules so `code`-like fields do not become editable again.
  - Build CREATE/UPDATE payloads from an explicit mapper: omit immutable fields when the update API excludes them, or preserve the originally loaded value when the update API requires a full payload. Do not rely on disabled UI controls as the API contract.
- Keep server identifiers and audit fields out of SaveReq unless the API contract explicitly accepts them. Render them as read-only DTO facts only when useful for detail/audit views.
- Apply API contract mapping by state:
  - request payload fields -> CREATE/UPDATE editable controls
  - response meta/status/audit fields -> DETAIL read-only blocks
  - list endpoint lightweight fields -> LIST columns
  - custom action endpoints -> workflow/action buttons
  - lookup/select endpoints -> relation controls
- API URL convention is PROJECT-SPECIFIC, NOT fixed by this reference. Scaffold defaults:
  - `BaseService.register('<entity>')` — no version prefix
  - `<entity>-select` template: `url="<entity>"` — same, no prefix
  - When generating against a real project, FIRST inspect existing services in that project (e.g. `BaseService.register('v1/booking')` in `portal-agency`, or `register('api/v2/customer')` elsewhere). Match the project's convention exactly. Do NOT impose `v1/` or any prefix the project doesn't already use.
- Create separate files: `model.ts`, `service.ts` for each entity
- Define `<Entity>SaveReq` (POST/PUT payload) + `<Entity>DTO = Required<<Entity>SaveReq> & BaseEntity` (used for BOTH list and detail responses — scaffold default). Do NOT generate a separate `<Entity>Detail` in scaffold.
- The scaffold default `DTO = Required<SaveReq> & BaseEntity` is a starter contract only. If the real Service maps a different raw API shape, replace or extend it with an explicit Service DTO plus mapper; do not pretend fields exist just because the raw API or UI wants them.
- `<Entity>SaveReq` can be split into more specific request types when business needs differ:
  - `<Entity>CreateReq` — POST /create payload (e.g. excludes `id`)
  - `<Entity>UpdateReq` — PUT /:id payload (e.g. allows partial fields, excludes immutable fields)
  - `<Entity>ImportReq` — POST /import payload (e.g. batch import with row-level metadata)
  - Default scaffold uses single `<Entity>SaveReq` for both create + update; split only when shapes diverge.
- Workflow action payloads use convention `<Entity><Action>Req`:
  - `ProductApproveReq`, `OrderCancelReq`, `BookingRejectReq`
  - Action name in PascalCase matches the route action (e.g. POST `/:id/approve` → `ProductApproveReq`)
- Permission code convention is **flexible per project, consistent within a project**. Order is always Module → Entity → Action (large → small). Acceptable shapes — pick ONE per project and stay consistent:
  - `<MODULE>_<ENTITY>_<ACTION>`   — scaffold default (e.g. `CRM_PRODUCT_LIST`)
  - `<MODULE>_C_<ENTITY>_<ACTION>` — common variant (e.g. `CRM_C_PRODUCT_LIST`)
  - `<MODULE>_<ENTITY>:<ACTION>`   — colon-separator variant (e.g. `CRM_PRODUCT:LIST`)
  - When applying to an existing project, detect the established convention and follow it. Never mix two conventions in the same project.
- Choose API service, facade/store, overlay coordinator, and pure collaborator
  lifecycles explicitly. Use root/app scope only when the existing project and
  stable cross-feature consumers justify it; use route/feature/page scope for
  mutable feature state, component scope for overlay coordinators, and pure
  functions for stateless collaborators when appropriate
- Use `FormGroup` for all forms with validation
- Implement 3-state pattern (CREATE/UPDATE/DETAIL) for detail component
- Use `@SdTabComponent` decorator on list components
- Lazy-load child routes with `loadComponent()`
- Use two-way binding: `[(model)]="entity.field"` with `[form]="form"`
- Define table columns with explicit type and width
- Use `SdTable` with server-side pagination (`type: 'server'`)
- Prioritize Core UI components first for all generated screens/forms/tables/actions
- If a required UI piece has no Core UI equivalent, explicitly mark it as custom and warn developer in generation summary
- Style utility-first per [`_refs/angular/styling.md`](../styling.md): put Core UI utility classes (`d-flex`, `gap-16`, `col-md-6`, `text-primary`, `T14M`, `rounded-8`) on templates; keep component `.scss` near-empty. Use Tailwind instead only if the consumer app ships it. Spacing/sizing is px-based 0–200 (multiples of 4). Custom `.scss` only when no utility fits — token-based (`var(--sd-*)`), with a `// why:`. Fetch the full class list on demand: `node _refs/angular/core-docs-fetch.mjs --print assets/STYLE-GUIDE`.
- Do not modify global CSS/SCSS during entity generation (`src/styles.scss` and shared global theme files are out of scope)
- Add `data: { permission: '<CODE>' }` to every route entry using the standard permission code format; the module guard reads this to block unauthorized navigation automatically
- When module uses keyed permission configuration, add `data.permissionKey` on each route and keep it consistent inside the same module flow
- When module uses keyed upload-file configuration, set `[key]` on `sd-upload-file` to match module upload configuration key
- When routes have `data.permission` guard, do NOT add extra `canViewList` / `canCreate` manual checks inside list/detail components
- For filters rendered outside table columns, define them in `tableOption.filter.externalFilters` instead of custom controls above table
- Mark blocking external filters as `required: true` and rely on table filter validation instead of rendering guidance text like "<localized text>"
- Do not bind template interpolation/properties/classes/conditions to component methods or getters that compute displayed or derived values each change-detection cycle. Compute once with `computed()`, `signal()`, a pure pipe, or an explicit view model and bind to that.
- Keep naming concise and domain-focused (`projects` over `projectOptions`)
- Use `externalFilters[].option.items` as a function when list data is only needed by filter UI; avoid storing extra component state if not reused
- Keep variable scope minimal:
  - component-only internals -> `#privateField`
  - single-function usage -> local `const` inside that function
  - avoid unnecessary intermediate component fields
- Auto-calculate external filter layout with this deterministic rule:
  - `filterCount = externalFilters.length`
  - `externalFilterPerRow = 4` when `filterCount <= 4`, otherwise `6`
  - `rowCount = ceil(filterCount / externalFilterPerRow)`
  - `hideExternalFilterToolbar = true` when `rowCount <= 1`, otherwise `false`
- Only add score cards when user explicitly requests score/summary metrics for that screen
- If score cards are present, use the dedicated score-card component once Core UI provides it; do not handcraft ad-hoc score-card UI
- When score cards exist above table, keep cards fixed in page flow and constrain table area so only table region scrolls (`tableOption.style.maxHeight` + container `overflow: hidden`)
- Include 4 audit columns at the end of every **primary list page** that displays a top-level entity table:
  - Created timestamp (e.g. `createdAt`, `createdDate`, `createTime`) → `type: 'datetime'`, `width: '180px'`
  - Created by (e.g. `createdBy`, `creatorId`, `creator`) → `type: 'string'`, `minWidth: '180px'`
  - Updated timestamp (e.g. `updatedAt`, `modifiedAt`, `lastModifiedDate`) → `type: 'datetime'`, `width: '180px'`
  - Updated by (e.g. `updatedBy`, `modifiedBy`, `lastModifiedBy`) → `type: 'string'`, `minWidth: '180px'`
- Always check the actual DTO/BaseEntity field names — do NOT assume `createdAt`; field names vary per backend framework (Spring, .NET, Django, Laravel all differ)
- For related entity fields, reuse an existing imported model/summary/option type when available; use `<entity>Id` when the API only returns an id; do not inline the full related object if that entity already has its own contract
- When a related entity's data is needed, reuse the existing related service; add the smallest compatible method to that service if needed instead of creating a duplicate service
- Skip audit columns when:
  - The table is embedded inside a detail/form page (sub-table, child entity list)
  - The entity is a simple lookup/enum table (code + name only, no meaningful timeline)
  - The table appears in a dialog or compact drawer with space constraints
  - The user explicitly asks to exclude them
- Upload files BEFORE saving entity (separate step)
- Choose detail style by complexity:
  - 5-6 common fields -> side-drawer
  - complex multi-section workflows -> full page
- For full-page detail with many fields/sections, combine section grouping with `sd-anchor` for fast scroll navigation
  - Use `sd-anchor ellipsis` as wrapper
  - Use one `sd-anchor-item` per business section (for example: "<localized text>", "<localized text>", "<localized text>")
  - Keep each anchor item body inside `sd-section` so navigation and section collapse can work together
- Support 3 page-layout variants for CREATE/UPDATE/DETAIL, and choose based on context:
  - `UnifiedCompact`: CREATE/UPDATE/DETAIL share one unified layout, no split title/form columns
  - `UnifiedSplit`: CREATE/UPDATE/DETAIL share one unified split layout (left title block, right form/content block)
  - `AdaptiveSplitDetail`: CREATE/UPDATE use editable split layout, DETAIL uses a different read-only split layout (like dashboard cards/sections)
- For `AdaptiveSplitDetail`, DETAIL screen should prefer `sd-section` + `sd-section-item` for read-only display blocks instead of editable form controls
- Regardless of DETAIL rendering style (`sd-section-item` or viewed controls), code/name must always render in DETAIL state
- In DETAIL load flow, when entity ID is stale/not found, show a warning and navigate back to list instead of leaving empty placeholders
- When the request does not clearly define expected detail layout, ask one clarification question before final generation:
  - "<localized text>"
- Reserve extension points for workflow actions in both list and detail (wired by `./actions.md`)
- Every routed list/detail screen must have a route/page container. That shell is
  the minimum boundary, not the maximum component count:
  - keep route/query parameters, navigation, load/save orchestration, overall
    form or query state, and screen composition in the page container;
  - extract summary, filter, table, bulk-action, form-section, line-item,
    workflow, modal/drawer, or other regions when they own a cohesive contract,
    state/lifecycle, accessibility behavior, or independent test;
  - keep small cohesive markup inline when extraction would only forward inputs,
    duplicate state, add disproportionate prop drilling, or reduce line count;
  - let typed child form sections receive the parent `FormGroup`/subgroup by the
    detected convention; never create a second entity/form state;
  - child components emit meaningful events and do not call raw API/router
    boundaries unless current project architecture assigns that responsibility;
  - a simple drawer with a few fields, no independent async region, and no child
    collection may remain one cohesive component with no facade/store.
- Preserve URL-state behavior when full-page routes are approved:
  - `/create` -> CREATE
  - `/update/:id` -> UPDATE
  - `/detail/:id` -> DETAIL (read-only)
- If required UI is not available in Core UI, generate a custom UI skeleton instead of skipping:
  - add `// CUSTOM_UI: <reason>` comment in component
  - render placeholder block for that UI area
  - render its actions disabled with a `<localized label>` hint that the action is not implemented yet (no alert calls or TODO tags)
  - include warning in generation summary: `Custom UI required: <ComponentName> - no Core UI equivalent`
- Run tests immediately after module/entity generation:
  - preferred: `npm run test -- --watch=false --include=src/libs/<module>/**/*.spec.ts`
  - fallback: `npm run test -- --watch=false`
  - report pass/fail and failing specs
  - fix failing tests before marking generation complete
- Use `inject()` function (not constructor injection) for all service and dependency injection inside components, services, and directives:
  ```typescript
  readonly #router = inject(Router);
  readonly #myService = inject(MyService);
  ```
- Set `changeDetection: ChangeDetectionStrategy.OnPush` on every generated or modified component; import `ChangeDetectionStrategy` from `@angular/core`
  - If component state is updated asynchronously after initialization (i.e., there is an `await` before a state assignment), inject `ChangeDetectorRef` and call `this.#cdr.markForCheck()` after the assignment; or migrate that state to a `signal()`
- Use **signal-first UI state style** for generated components:
  - Use `signal()` for mutable UI state (`loading`, `state`, `tableOption`, selected ids, dialog flags)
  - Keep editable entity/form models as plain objects/ViewModels when using Core UI `[model]` / `[(model)]` binding; do not wrap entity objects in `signal()`
  - Under `ChangeDetectionStrategy.OnPush`, inject `ChangeDetectorRef` and call `markForCheck()` after async assignment to a plain object/ViewModel
  - Use `computed()` for derived state (`isDetail`, button visibility, header title)
  - Use `effect()` only for side effects (reload, sync route params), not as a replacement for `computed()`
  - Keep `FormGroup` as-is, but surrounding UI/view state should be signals
  - Example:
    ```typescript
    readonly state = signal<'CREATE' | 'UPDATE' | 'DETAIL'>('CREATE');
    entity: Partial<ProductSaveReq & { id?: string }> = {};
    readonly isDetail = computed(() => this.state() === 'DETAIL');
    ```
- Follow this import order in every component/service file:
  1. Angular framework (`@angular/core`, `@angular/router`, `@angular/common`, `@angular/forms`)
  2. RxJS (if used)
  3. Third-party / library (Core UI imports — see `_refs/angular/core-version.md` for current package name; templates use `<CORE_UI_PACKAGE_NAME>/...` placeholder)
  4. Internal shared / cross-module imports
  5. Relative imports within the same module (models, services, sibling files)
  - Separate each group with a blank line
- Monitor signal invocation efficiency in templates:
  - If a signal is used **2 or more times** in the template, consider:
    - Extract to a `readonly #memoized = computed(() => ...)` in the component to cache the value
    - OR use `@let` syntax (where supported): `@let _varName = signal();` then use `_varName` throughout
  - If a signal is used **only once**: invoke it directly at the point of use, no caching needed
  - Goal: reduce unnecessary signal getter invocations during change detection cycles
- Template call rule:
  - Event handlers are fine: `(click)="onSave()"`, `(modelChange)="onFieldChange('name', $event)"`.
  - Signal reads are fine: `state()`, `saving()`; use `@let` when repeated.
  - Plain object/ViewModel reads are fine for editable Core UI models: `[model]="entity.name"`, `[(model)]="entity.code"`.
- Display/derived bindings must NOT call component methods/getters: avoid `{{ formatName(row) }}`, `[title]="buildTitle()"`, `[disabled]="isSaveDisabled()"`, `@if (canEdit())`, `[class.error]="hasError('code')"`.
- Replace them with `computed()` values, prebuilt maps (`fieldErrors()`), pure pipes, or table/view-model fields.
- If table/tree/form UI needs fields such as `checked`, `selected`, `disabled`, `expanded`, `children`, `label`, `displayName`, `color`, or `icon`, generate a local ViewModel mapper (`DTO -> VM`) unless the Service DTO explicitly derives and guarantees those fields.
- Ensure interactive elements exposed to users have accessible text: use `title` or `aria-label` on buttons/actions so screen readers can describe them; use semantic HTML where possible (`<nav>`, `<main>`, `role="toolbar"`)
- Generate a companion `*.spec.ts` skeleton alongside every new list and detail component; use Arrange-Act-Assert pattern; the skeleton must at minimum assert the component creates successfully:
- Generate companion `*.spec.ts` files alongside service/routes/list/detail with runnable tests; use Arrange-Act-Assert pattern; specs must include at minimum component/service/route creation and one behavior assertion each:
  ```typescript
  describe('ListComponent', () => {
    it('should create', () => { expect(component).toBeTruthy(); });
  });
  ```
- **Generate spec files at `standard` coverage by DEFAULT — do NOT block on a question.** Tests are mandatory; never skip them and never ask "<localized text>" before writing. Write the spec RED-first (before its production file) per the orchestrator TDD gate. Coverage levels (use the matching template set from Section 5):
  - `standard` (DEFAULT): `should create` + permission validation + data visibility + sort/navigation + detail save-flow/state tests — emit this unless the user explicitly overrode it
  - `minimal`: only `should create` test (fastest) — only on explicit user request
  - `full`: + all unit tests from Section 5 (comprehensive coverage) — only on explicit user request
- Make generated spec files runnable out-of-the-box (not placeholder-only):
  - Provide minimal dependency mocks for `inject()` dependencies (`Router`, `ActivatedRoute`, services)
  - Isolate template with `TestBed.overrideComponent(..., { set: { template: '<div>...</div>' } })` when Core UI dependencies are heavy
  - Ensure `fixture.detectChanges()` runs without DI/template errors
- Generate functional test cases (not only `should create`) for standard/full coverage level:
  - **Route permission coverage**: verify every route has `data.permission` and follows the project's chosen convention (Module → Entity → Action order, single consistent shape)
  - **Data visibility coverage** (list): verify missing required external filter returns empty data, and valid filter triggers service call
  - **Data ordering coverage** (list): verify domain sort behavior (if defined) is applied correctly
  - **Action flow coverage** (detail): verify invalid form blocks save, create path calls `create`, update path calls `update`, and navigation is correct
  - **Signal state coverage**: verify state transitions (`CREATE/UPDATE/DETAIL`) and computed flags (`isDetail`, title) work as expected
- After generating a new module or entity, run tests immediately and report result:
  - Preferred command: `npm run test -- --watch=false --include=src/libs/[module]/[featureRoot]/[entity]/**/*.spec.ts`, after replacing `[featureRoot]` with the detected feature directory (`features` only as a greenfield fallback)
  - If include filter is not supported, run full `npm run test -- --watch=false` and summarize spec results
  - If environment lacks headless browser, report blocker explicitly and provide exact command for developer to run locally
- Reserve extension points for workflow actions in both list and detail
- Always run a final double-check pass: route data, permission keys, upload keys, service wiring, and basic build/test status
- Support hybrid NgModule + standalone integration when target codebase still uses NgModule boundaries

### TESTING CHECKLIST FOR DEVELOPERS ⚠️
**When applying this reference to generate a new entity module, developers MUST verify these points before committing:**

1. **Signal Invocation Syntax**
   - [ ] Check all UI-state signals are invoked with `()` in templates: `state()`, `saving()`
   - [ ] Check editable entity/form models are plain object/ViewModel bindings: `entity.name`, `entity.code` (do not invoke entity as a signal)
   - [ ] Verify no double invocations like `state()()` exist
   - [ ] Confirm `@let` declarations are used for signals referenced 2+ times
   - [ ] Verify single-use signals invoke directly without `@let` wrapper

2. **Dependency Injection**
   - [ ] All services use `inject()` function: `readonly #service = inject(MyService)`
   - [ ] No constructor injection used; verify 0 occurrences of `constructor(private service: MyService)`
   - [ ] All private dependencies use `#` prefix: `readonly #router = inject(Router)`

3. **Change Detection & Performance**
   - [ ] Verify `changeDetection: ChangeDetectionStrategy.OnPush` on list and detail components
   - [ ] Check that `ChangeDetectionStrategy` is imported from `@angular/core`
   - [ ] If async assignments update a plain object/ViewModel under `OnPush`, verify `ChangeDetectorRef.markForCheck()` is called after the assignment
   - [ ] Verify no template interpolation/property/class/condition binding calls a component method/getter for displayed or derived values

4. **Component Field Scope**
   - [ ] Verify all non-exported fields use `#private` prefix
   - [ ] Check no unnecessary component fields exist (push local vars or `#privateFields` instead)
   - [ ] Confirm FormGroup, signals for state are properly scoped

5. **Import Organization**
   - [ ] Verify 5-group import order is followed (Angular → RxJS → @sd-angular → shared → relative)
   - [ ] Check each group is separated by a blank line
   - [ ] Ensure no legacy imports like `from 'sd-angular'` exist; use `<CORE_UI_PACKAGE_NAME>/...` paths (substituted from `_refs/angular/core-version.md`)

6. **Accessibility**
   - [ ] Check action toolbars have `role="toolbar"` attribute
   - [ ] Verify all buttons have `title` or `aria-label` for screen reader support
   - [ ] Confirm use of semantic HTML where possible

7. **Audit Columns (List Page)**
   - [ ] Verify primary list tables include all 4 audit columns at the end: `createdAt`, `createdBy`, `updatedAt`, `updatedBy`
   - [ ] Check field names match actual DTO (vary by backend: `createdAt` vs `CreatedDate` vs `created_at`)
   - [ ] Confirm skip conditions are documented if audit columns are intentionally omitted

8. **Route Permission Guards**
   - [ ] Check every route has `data: { permission: '...' }` defined
   - [ ] Verify permission codes follow the project's chosen convention: Module → Entity → Action order, UPPERCASE, single consistent shape across the whole project (no mixing of `_C_` and plain underscore variants)
   - [ ] Confirm NO duplicate permission checks inside components if route guard is defined
   - [ ] Verify module guard reads `data.permission` automatically (no manual implementation needed)

9. **Spec File Generation**
   - [ ] Verify specs were generated at `standard` coverage by default (minimal/full only on explicit request) — never skipped, never blocked on a coverage-level question
   - [ ] Check generated spec files are NOT placeholders; each test is fully defined and runnable
   - [ ] Confirm mocks are provided for all `inject()` dependencies (Router, ActivatedRoute, services, SdNotifyService, SdLoadingService)
   - [ ] Verify TestBed.overrideComponent isolates templates to avoid heavy UI library dependency errors
   - [ ] Check [entity].routes.spec.ts exists and validates permission codes on all routes
   - [ ] Ensure list.component.spec.ts includes external filter and sort tests (if standard/full coverage chosen)
   - [ ] Ensure detail.component.spec.ts includes state transition and save-flow tests (if standard/full coverage chosen)
   - [ ] Run post-generation test command to verify all specs pass immediately

10. **Build Verification**
   - [ ] Run `npm run build` or equivalent; confirm **no TypeScript errors** (warnings are acceptable for unused code)
   - [ ] If `ChangeDetectionStrategy.OnPush` + async state updates, verify no change detection race conditions in browser console
   - [ ] Test component creation in browser DevTools to confirm signal state initializes correctly

10. **Testing Skeletons**
    - [ ] Verify `*.spec.ts` file exists alongside component
    - [ ] Check AAA pattern is used (Arrange-Act-Assert)
  - [ ] Confirm at minimum `should create` test passes: `expect(component).toBeTruthy()`
  - [ ] Verify spec contains required mocks for `inject()` dependencies so test runs without NullInjector errors
  - [ ] Verify route permission tests exist (`data.permission` presence + naming format)
  - [ ] Verify list data tests exist (required filter behavior + sorted output/asserted data order)
  - [ ] Verify detail save-flow tests exist (invalid/create/update paths)
  - [ ] Run target test command after generation and attach result (pass/fail + error summary if fail)

### MUST NOT ❌
- Guess the module silently when module ownership is ambiguous
- Create a duplicate model, interface, DTO, type, service, store, repository, or API client for a domain entity that already has a suitable contract in the project
- Inline a full related entity shape inside the primary model when an imported related model or summary type exists
- Create near-duplicate names such as `OrderCustomerService` when `CustomerService` already owns the matching customer API logic
- Rename or reshape existing model/service fields without checking usages and preserving backward compatibility
- Do not force a full standalone migration when developer requests hybrid NgModule + standalone compatibility mode
- Use ad-hoc permission code naming that breaks Module → Entity → Action order, or mix two conventions within the same project
- Hard-code API URLs (use configuration tokens)
- Put API/data-access or multi-service workflow logic in presentational child
  components; keep UI event handling and local transient state in components and
  delegate transport/orchestration to the approved boundary
- Skip form validation before save
- Create circular dependencies between modules
- Deep-import across feature boundaries or export feature-private route/child
  components through broad barrels; within one feature, use direct local imports
  when that is the detected convention
- Force page detail for short common forms that can fit in side-drawer
- Hard-wire workflow actions into all entities when not requested
- Build ad-hoc top filter UIs that duplicate table external filter capability
- Depend on warning/help text to enforce required filter preconditions
- Auto-add score cards to listing screens when the requirement does not ask for them
- Keep external filter toolbar visible when there is only one external-filter row and no toolbar actions are needed
- Hard-code external filter layout values without applying the auto-calculation rule above
- Expose extra component fields/getters when a local variable or `#privateField` is sufficient
- Use template-bound method/getter calls for displayed/derived values, permission checks, boolean guards, titles, disabled states, classes, colors, labels, or field errors
- Omit `data.permission` from route definitions
- Do not omit `data.permissionKey` when the module is designed to use keyed permission configuration
- Do not omit `sd-upload-file [key]` when the module is designed to use keyed upload-file configuration
- Duplicate route-level permission guard as in-component `canViewList` / `canCreate` checks
- Use constructor injection; always use `inject()` function instead
- Omit `changeDetection: ChangeDetectionStrategy.OnPush` from list/detail component declarations
- Reorder imports arbitrarily; always follow the 5-group import order convention
- Generate mutable UI state as plain class fields/getters when `signal()`/`computed()` can represent that state
- Use `effect()` for pure derivations that should be `computed()`
- Omit the 4 audit columns from primary list pages unless an explicit skip condition applies
- Hard-code audit field names without inspecting the DTO definition
- Overuse signal invocations in template without considering the 2+ times rule (apply `computed()` or `@let` when signal is referenced 2+ times)
- Skip spec files, defer them, or block spec generation behind a coverage-level question — default to `standard` and write them RED-first without asking
- Generate placeholder specs with `// TODO add tests` or similar; all specs must be runnable and pass on first `ng test`
- Render long multi-section page forms without anchor navigation when `sd-anchor` is already available
- Use editable inputs in DETAIL read-only summary sections when `AdaptiveSplitDetail` layout is selected
- Leave DETAIL page in broken state when `detail(id)` fails (`Entity not found`) without user feedback or recovery navigation
- Ignore provided mock API/OpenAPI/Postman/cURL contract or PRD image when they define API fields or UI sections
- Switch from mock-first prototype mode to live API integration from contract text alone; require runnable endpoint/configuration and project convention evidence
- Add UI-only fields (`checked`, `selected`, `disabled`, `expanded`, `children`, `label`, `displayName`, etc.) directly to `<Entity>SaveReq` or `<Entity>DTO` when the Service does not accept/return/derive them
- Force Service models to mirror raw backend request/response fields 1:1 when the Service layer intentionally maps, normalizes, or hides that raw API shape


## 4. Templates and code samples

All `.ts` code templates this reference emits live in template files — this file stays slim by linking out:

- **Component + service + routes templates** — `_refs/angular/templates/entity-skeleton.md`
  - Preconditions, layout-variant decisions, anchor heuristic
  - Permission keyed route template (route/page containers + URL states)
  - Permission directive template
  - Test coverage selection
  - Detail UI mode + pattern selection
  - Workflow extension points
  - Side-drawer vs full-page project structure tables
  - `[entity].model.ts`, `[entity].service.ts`
  - `components/[entity]-select/[entity]-select.component.ts`
  - `list.component.ts` (page variant) and `list.component.ts` (side-drawer variant)
  - `routes.ts` (side-drawer variant)
  - `detail.component.ts` (UnifiedCompact) and `detail.component.ts` (AdaptiveSplitDetail variant)
  - `[entity].routes.spec.ts` (permission validation)
  - `index.ts` (intentional public API only)

- **Architecture-driven feature boundary templates** —
  `_refs/angular/templates/feature-component-boundaries.md`
  - route/page orchestration shell with standalone child imports
  - feature-local filters, table, bulk-action, form-section, and child-collection contracts
  - optional feature facade, form builder, and mapper collaborators
  - page orchestration, child contract, and provider lifecycle tests

- **Spec.ts templates** — `_refs/angular/templates/entity-tests.md`
  - Default coverage note (`standard` unless the user explicitly overrode it — no clarify prompt)
  - `list.component.spec.ts` and `detail.component.spec.ts` at Standard coverage
  - `[module]-[entity].routes.spec.ts` permission validation tests

- **Worked example (Product entity)** — `_refs/angular/templates/example-product.md`
  - Reference output to verify shape and conventions; do NOT copy-paste — emit the parameterized templates above with the user's confirmed inputs.

Load the relevant ref file ON DEMAND when the corresponding sub-step runs; do NOT pre-load all of them.

## 5. Example Input

```
Create a "Product" entity inside module "catalog" with fields: code, name, description, price, stock, category, isActivated
- List page should display: code, name, price, stock, category with inline edit for isActivated
- Detail page should support file upload for product images
- Use category as a dropdown with lazy loading
```

### Example Input for side-drawer preference

```text
Create Customer CRUD in module crm with 6 fields: code, name, phone, email, type, isActivated.
Use a common quick-edit experience.
```

Expected detail mode:
```text
side-drawer
```

### If the user does not specify module

```text
User input: "Create Product CRUD screens with product code and product name"

Agent must ask:
"<localized text>"
```


## 5. Spec Templates (Functional Testing)
Detailed spec.ts code is in `_refs/angular/templates/entity-tests.md`. Default coverage is `standard` (no clarify needed — write RED-first without asking); override to `minimal`/`full` only on explicit user request.

## 6. Example Output
Worked Product entity (full code samples for domain/data contracts, data access,
routed page containers, and approved architecture-derived feature components)
lives at `_refs/angular/templates/example-product.md`. Treat it as a sanity
reference, not a paste source.

## Implementation Checklist

- [ ] Read `./reuse-existing-entities.md` and complete the reuse preflight
- [ ] Complete `_refs/shared/frontend-architecture.md` with detected conventions,
      reuse decisions, component tree, state/service ownership, provider scope,
      registration, public exports, tests, and decomposition rationale
- [ ] Identify primary and related entities
- [ ] Scan existing model/interface/type/dto files and symbols
- [ ] Scan existing service/api/repository/store files and symbols
- [ ] Record reuse/extend/create-new decision for each entity
- [ ] Reuse imported related entity types/services or minimally extend existing files before creating new contracts
- [ ] If mock API/API-contract input exists, complete `./mock-api-input.md` contract mapping before creating models/services/screens
- [ ] Create model file with SaveReq interface and DTO type
- [ ] Classify every ambiguous field as raw API, Service input/output, Component ViewModel, or UI state before adding it to a type
- [ ] Create `services/[entity].mock-data.ts` only for approved `seed-data`,
      with the approved count and domain-realistic values
- [ ] Use mock-first CRUD only for an approved technical-prototype
      `mock-service`; otherwise follow the approved runnable backend contract
- [ ] Add mapper/internal API types when raw backend shape differs from the Service contract
- [ ] Create route/page list container with @SdTabComponent and only the approved feature-local children
- [ ] Create route/page detail container with 3-state machine and only the approved form/workflow/collection children
- [ ] Define route configuration with lazy loading
- [ ] Register standalone imports or NgModule declarations/imports/exports and providers according to detected project style
- [ ] Keep route pages and feature-local children private; export only symbols with verified external consumers
- [ ] State every service/collaborator provider scope and lifecycle reason; do not default mutable feature state to root
- [ ] Test route/page orchestration and each meaningful child input/output/state contract
- [ ] Test CREATE/UPDATE/DETAIL flows
- [ ] Validate form before save
- [ ] Test file upload functionality
- [ ] Test permission directives
- [ ] Test server-side pagination
