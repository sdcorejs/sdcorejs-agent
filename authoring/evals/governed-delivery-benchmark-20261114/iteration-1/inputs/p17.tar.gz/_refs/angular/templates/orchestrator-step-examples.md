# Write-Code Orchestrator — Step Examples

Walkthrough examples referenced from [`write-code.md`](../../write-code.md) (the `sdcorejs-angular` orchestrator). The skill body owns the dispatch table, TDD gate, input resolution, semantic inference rules, and the file/naming conventions; these examples show what the on-demand reference packs it loads (`init-entity`, `screen-list`, etc.) ultimately produce. Use them when you want to picture the end shape, or when explaining the flow to someone reading the orchestrator for the first time.

For the canonical entity-skeleton + tests + product example actually used by the init-entity pack, see the sibling refs [`entity-skeleton.md`](./entity-skeleton.md), [`entity-tests.md`](./entity-tests.md), and [`example-product.md`](./example-product.md).

## Table of contents

- [Step 1 — Build EntitySchema](#step-1--build-entityschema)
  - [User-provided fields (Product)](#user-provided-fields-product)
  - [Inferred schema (Promotion — fields omitted)](#inferred-schema-promotion--fields-omitted)
- [Step 2 — Generate Model (`product.model.ts`)](#step-2--generate-model-productmodelts)
- [Step 3 — Generate Mock Data + Service](#step-3--generate-mock-data--service)
  - [product.service.ts](#productservicets)
  - [promotion.mock-data.ts (inferred schema, domain-realistic)](#promotionmock-datats-inferred-schema-domain-realistic)
- [Step 4 — Generate Routes (`product.routes.ts`)](#step-4--generate-routes-productroutests)
- [Step 5 / Step 6 — Routed pages and approved feature components](#step-5--step-6--routed-pages-and-approved-feature-components)
- [Worked end-to-end — Employee entity](#worked-end-to-end--employee-entity)

---

## Step 1 — Build EntitySchema

### User-provided fields (Product)

When the user supplies fields:

```
Module: sample
Entity: product
Label: Product
Fields:
  - code (string, required, max 32)
  - name (string, required, max 255)
  - categoryId (select, label: Product type, api: /api/categories)
  - price (decimal, required, min 0)
  - stock (number, required, min 0)
  - description (textarea)
```

Resulting `EntitySchema`:

```typescript
const PRODUCT_SCHEMA: EntitySchema = {
  module: 'sample',
  entity: 'product',
  entityPascal: 'Product',
  entityLabel: '<localized text>',
  entityLabelPlural: '<localized text>',
  apiEndpoint: 'product',

  fields: [
    { name: 'code', type: 'string', label: '<localized text>', required: true, maxLength: 32, visibleInList: true },
    { name: 'name', type: 'string', label: '<localized text>', required: true, maxLength: 255, visibleInList: true },
    { name: 'categoryId', type: 'select', label: '<localized text>', selectApiEndpoint: '/api/categories', selectApiValueField: 'id', selectApiLabelField: 'name' },
    { name: 'price', type: 'decimal', label: '<localized text>', required: true, min: 0, decimals: 2, visibleInList: true, columnFormat: 'currency' },
    { name: 'stock', type: 'number', label: '<localized text>', required: true, min: 0, visibleInList: true },
    { name: 'description', type: 'textarea', label: '<localized text>' }
  ],

  detailLayout: 'full-page',
  listPageSize: 10,
  permissionCreate: 'SAMPLE_PRODUCT_CREATE',
  permissionUpdate: 'SAMPLE_PRODUCT_UPDATE',
  permissionDelete: 'SAMPLE_PRODUCT_DELETE'
};
```

### Inferred schema (Promotion — fields omitted)

When the user only names the entity:

```text
Request: "<localized text>"
```

The orchestrator applies the Semantic Inference Fallback (see skill body §"Semantic Inference Fallback") and produces a first-pass `EntitySchema`:

```typescript
const PROMOTION_SCHEMA: EntitySchema = {
  module: 'sales',
  entity: 'promotion',
  entityPascal: 'Promotion',
  entityLabel: '<localized text>',
  entityLabelPlural: '<localized text>',
  apiEndpoint: 'promotion',

  fields: [
    { name: 'code', type: 'string', label: '<localized text>', required: true, maxLength: 32, visibleInList: true },
    { name: 'name', type: 'string', label: '<localized text>', required: true, maxLength: 255, visibleInList: true },
    { name: 'type', type: 'select', label: '<localized text>', required: true, visibleInList: true },
    { name: 'discountValue', type: 'decimal', label: '<localized text>', required: true, min: 0, visibleInList: true },
    { name: 'startDate', type: 'date', label: '<localized text>', required: true, visibleInList: true },
    { name: 'endDate', type: 'date', label: '<localized text>', required: true, visibleInList: true },
    { name: 'status', type: 'select', label: '<localized text>', required: true, visibleInList: true },
    { name: 'description', type: 'textarea', label: '<localized text>' }
  ],

  detailLayout: 'full-page',
  listPageSize: 10,
  permissionCreate: 'SALES_PROMOTION_CREATE',
  permissionUpdate: 'SALES_PROMOTION_UPDATE',
  permissionDelete: 'SALES_PROMOTION_DELETE'
};
```

## Step 2 — Generate Model (`product.model.ts`)

From the `EntitySchema`, generate:

- `<EntityPascal>SaveReq` interface (writable business fields)
- `<EntityPascal>DTO` type (public Service output contract; scaffold default can be `SaveReq` + `BaseEntity`)
- `<ENTITY>_ROLES` constant when there are static select options
- JSDoc comments above each field explaining the UI control + validation hints
- For Vietnamese portals, labels/comments preserve full diacritics

```typescript
import { BaseEntity } from '@sample/services';

export interface ProductSaveReq {
  // UI: sd-input (required, maxLength 32)
  code?: string;
  // UI: sd-input (required, maxLength 255)
  name?: string;
  // UI: sd-select (Dynamic API: /api/categories, valueField: id, labelField: name)
  categoryId?: string;
  // UI: sd-input-number (required, decimals 2, min 0)
  price?: number;
  // UI: sd-input-number (required, min 0)
  stock?: number;
  // UI: sd-textarea
  description?: string;
}

// Scaffold default Service output contract. If the raw API differs, keep an
// internal ProductApiRes in ProductService and map it into ProductDTO.
export type ProductDTO = Required<ProductSaveReq> & BaseEntity;
```

## Step 3 — Generate Mock Data + Service

Pattern: one centralized mock data file per entity + a service wired to a localStorage-backed `MockCrudStore`. This step is mandatory after semantic schema inference — the list page should render with real-looking data on first load.

Service model rule: `ProductSaveReq` and `ProductDTO` are what `ProductService` accepts/returns to components. They do not have to match a raw backend response 1:1 when the Service owns a mapper. Do not add UI-only fields such as `checked`, `selected`, `expanded`, `children`, `label`, or `displayName` to these models unless the Service derives and guarantees them.

### product.service.ts

This example selects feature-route scope because the mock store is owned only by
the Product sample. A real generation run must use the provider scope approved
by `_refs/shared/frontend-architecture.md`; use `providedIn: 'root'` only when a
stateless service has stable app-wide consumers and matches project convention.

```typescript
import { Injectable } from '@angular/core';
import { MockCrudStore } from '@sample/services';
import { ProductDTO, ProductSaveReq } from './product.model';
import { PRODUCT_SEED_DATA } from './product.mock-data';

@Injectable()
export class ProductService {
  readonly #store = new MockCrudStore<ProductDTO, ProductSaveReq>(
    'product',
    () => [...PRODUCT_SEED_DATA],
    (existing, req) => ({
      ...(existing ?? ({} as ProductDTO)),
      code: String(req.code ?? existing?.code ?? ''),
      name: String(req.name ?? existing?.name ?? ''),
      price: Number(req.price ?? existing?.price ?? 0),
      isActivated: Boolean(req.isActivated ?? existing?.isActivated ?? true),
      note: String(req.note ?? existing?.note ?? ''),
    })
  );

  paging = this.#store.paging;
  search = this.#store.search;
  all = this.#store.all;
  detail = this.#store.detail;
  create = this.#store.create;
  update = this.#store.update;
  remove = this.#store.remove;
}
```

### promotion.mock-data.ts (inferred schema, domain-realistic)

This worked example assumes `seed-data` and a 30-row count were explicitly
approved. Mock-data rules for this example:

- Produce exactly **30 rows**
- Distribute select/enum values across every option (don't use one value for all rows)
- Spread dates across the past ~12 months
- Use plausible numeric ranges that match the domain (percentage 1–50, fixed amount 10k–500k, stock 0–1000)
- Vietnamese portal → Vietnamese business names with full diacritics
- `id: uuidv4()` on every row so `MockCrudStore` can address records
- `isActivated` ~70/30 unless domain logic says otherwise

```typescript
import { v4 as uuidv4 } from 'uuid';
import { PromotionDTO } from './promotion.model';

export const PROMOTION_SEED_DATA: PromotionDTO[] = [
  {
    id: uuidv4(), code: 'KM-2024-01', name: '<localized text>',
    type: 'PERCENT', discountValue: 15,
    startDate: '2024-06-01', endDate: '2024-08-31',
    status: 'INACTIVE', description: '<localized text>',
    isActivated: false, createdAt: '2024-05-20T08:00:00Z', updatedAt: '2024-05-20T08:00:00Z',
  },
  {
    id: uuidv4(), code: 'KM-2024-02', name: '<localized text>',
    type: 'FIXED', discountValue: 50000,
    startDate: '2024-12-01', endDate: '2024-12-31',
    status: 'INACTIVE', description: '<localized text>',
    isActivated: false, createdAt: '2024-11-10T09:00:00Z', updatedAt: '2024-11-10T09:00:00Z',
  },
  {
    id: uuidv4(), code: 'KM-2025-01', name: 'Flash sale 1/1/2025',
    type: 'PERCENT', discountValue: 20,
    startDate: '2025-01-01', endDate: '2025-01-01',
    status: 'INACTIVE', description: '<localized text>',
    isActivated: false, createdAt: '2024-12-20T10:00:00Z', updatedAt: '2024-12-20T10:00:00Z',
  },
  // ... continue to the approved 30 rows, distributed evenly across type/status
];
```

## Step 4 — Generate Routes (`product.routes.ts`)

Lazy-load components. This example registers the feature-owned mock service at
the route so its mutable state lifecycle follows the feature. Omit the route
provider only when the approved architecture selects an app/root-provided
stateless service. Lib-scoped configuration tokens remain wired by
`<Lib>Module.useValue({...})` at root (see [`init-module.md`](../write-code/init-module.md)
§`[module].module.ts`).

```typescript
import { Routes } from '@angular/router';
import { ProductService } from './services/product.service';

export const productRoutes: Routes = [
  {
    path: '',
    providers: [ProductService],
    children: [
      { path: '', loadComponent: () => import('./pages/list/list.component').then(m => m.ListComponent) },
      { path: 'create', loadComponent: () => import('./pages/detail/detail.component').then(m => m.DetailComponent) },
      { path: 'detail/:id', loadComponent: () => import('./pages/detail/detail.component').then(m => m.DetailComponent) },
      { path: 'update/:id', loadComponent: () => import('./pages/detail/detail.component').then(m => m.DetailComponent) }
    ]
  }
];
```

## Step 5 / Step 6 — Routed pages and approved feature components

For route/page shells and any approved feature-local children (`SdTable`, audit
columns, filters, actions, `CREATE/UPDATE/DETAIL` state, form sections, child
collections), defer to the screen reference packs the orchestrator loads on
demand:

- List page → see [`screen-list.md`](../write-code/screen-list.md)
- Detail component (shell + CREATE / UPDATE / DETAIL states + form refinement) → see [`screen-detail.md`](../write-code/screen-detail.md)
- Action buttons layered on top (workflow / bulk / custom side-effects) → see [`actions.md`](../write-code/actions.md)
- Architecture-driven page/child/collaborator/test templates → see
  [`feature-component-boundaries.md`](./feature-component-boundaries.md)

## Worked end-to-end — Employee entity

**User request:**

```
生成 sample 模块的员工 CRUD
字段: code, name, role, salary, birthday, isActivated, note
```

**Agent process:**

1. Confirm module `sample` exists
2. Entity name: `employee`
3. Label: `<localized text>`
4. Fields confirmed with types/validation
5. Generate `EMPLOYEE_SCHEMA` (Step 1)
6. Generate `employee.model.ts` (Step 2)
7. Generate `employee.mock-data.ts` (Step 3)
8. Generate `employee.service.ts` (Step 3)
9. Generate `employee.routes.ts` (Step 4)
10. Generate the list route/page container and any feature-local children approved for cohesive list responsibilities (Step 5 — using the `screen-list` reference pack)
11. Generate the detail route/page container and any approved form, workflow, or child-collection boundaries (Step 6 — using the `screen-detail` reference pack, all CREATE/UPDATE/DETAIL states)
12. Verify all files compile without errors
13. Return complete code package ready to add to module

**Result tree:**

```
src/libs/sample/features/employee/
├── services/
│   ├── employee.model.ts
│   ├── employee.mock-data.ts
│   ├── employee.service.ts
│   └── index.ts
├── pages/
│   ├── list/list.component.ts
│   └── detail/detail.component.ts
└── routes.ts
```

This simple worked request has no separately justified summary, filter,
form-section, child-collection, or workflow boundary, so its two cohesive routed
page containers are intentional. A more complex approved architecture may add
feature-local children under `components/`; this example tree is not a maximum
component count.
