> **Reference for the `sdcorejs-angular` orchestrator.** Loaded on demand when the
> confirmed plan includes initializing a brand-new portal repo. Not a standalone skill — the
> orchestrator reads this file when its dispatch table routes a step here.

# Init Portal — Angular Portal Project Initialization

## Contents

- [Overview](#overview)
- [Template-first Baseline](#template-first-portal-baseline)
- [Core UI Source Of Truth](#source-of-truth--core-ui-package)
- [When To Use](#when-to-use)
- [Input Resolution](#input-resolution)
- [Generation Steps](#generation-steps)
- [Rules](#3-rules)
- [Template](#4-template)
- [Validation](#validation-checklist-apply-at-end-of-generation)
- [Post-init Summary](#post-init--write-the-project-summary)
- [Examples](#5-example-input)

## Overview

Generates a production-ready Angular portal starter from the mapped portal-shell
templates in
[`_refs/angular/templates/init-portal-templates.md`](_refs/angular/templates/init-portal-templates.md).
Generate the sample module and entities through `init-module.md` and
`init-entity.md`; the structure tree describes the combined result rather than
an unconditional template inventory. No external baseline directory is required.

**Output:** Complete portal with sample lib (1 module, 2 entities), dev tools, ready for `npm start`.

## Template-first portal baseline

This reference is the only portal-shell creation path for explicitly approved
Angular technical prototypes. Render the Core UI starter template first, then
modify only the approved configuration, routes, modules, entities, and optional
mock data inside that generated structure. Do not design a custom portal shell,
bespoke navigation/sidebar/header, standalone dashboard, or alternative
list/detail/form framework before this baseline exists.

---

## Source of truth — Core UI package

This reference uses two placeholders wherever the Core UI package appears:

| Placeholder | Resolved from `_refs/angular/core-version.md` field |
|---|---|
| `<CORE_UI_PACKAGE_NAME>` | `packageName` |
| `<CORE_VERSION>` | `currentVersion` |

> The actual values live ONLY in [`_refs/angular/core-version.md`](_refs/angular/core-version.md). Do not duplicate them here — the drift-check hook will block any literal version or any import statement that hardcodes the Core UI package name in this file.

**BEFORE generating any file**, the agent MUST:

1. Read [`_refs/angular/core-version.md`](_refs/angular/core-version.md) and extract `packageName` + `currentVersion`
2. Substitute every `<CORE_UI_PACKAGE_NAME>` / `<CORE_VERSION>` token in this reference's output with those values
3. Apply the same substitution to import statements, resolving `<CORE_UI_PACKAGE_NAME>` from `core-version.md` (default `@sdcorejs/angular`).
4. NEVER hardcode a literal version string in generated `package.json` / commit message / verification text

Single-file bump: change `_refs/angular/core-version.md` and every future portal picks it up. Do NOT find-replace placeholders inside this reference file itself — they are intentional.

If `_refs/angular/core-version.md` is missing or malformed, STOP and ask the user — never guess the version or package name.

---

## When to Use

- "<localized text>"
- "Gen new sales portal starter"
- "Create angular with CRUD module"

---

## Input Resolution

Before generating, clarify with user:

1. **Project Name** (required) — e.g. `hr-portal`, `sales-portal`
2. **Environments** (optional, defaults: `dev`, `qc`, `uat`, `prod`)
3. **Application Title** (optional, default: `Portal`)
4. **Sample Entity Names** (optional, defaults: `order`, `customer`; generate a
   selector abstraction only if the approved sample contract needs remote/search
   selection and passes the reuse/stability/consumer gate in `./init-module.md`)
5. **Additional Modules** (optional) — answer: "Use the init-module reference (`./init-module.md`) after generation"

> **Port** is fixed at `4200` (Angular default). Do not ask.

### Explicit technical-prototype/no-backend mode

When this reference is used from an explicitly approved `technical-prototype`:

- Generate a portal that boots locally with no backend auth/API dependency.
- Treat the Core UI starter template as the prototype baseline; prototype
  screens are added as modules/entities after the starter has been rendered.
- Set `PermissionConfiguration.disabled = true` only when permission bypass is
  explicitly approved as a demo-only assumption.
- Do not add login, auth redirects, live API base URLs, or permission data
  requirements unless the user explicitly requests them.
- Generate/keep admin screens only when `admin-screens` is an approved optional
  feature. Keep only approved sample/demo routes reachable for review.
- Report that permission is bypassed for prototype review and can be re-enabled
  when the real permission backend exists.

---

## Generation Steps

### Step 1: Render Starter From Templates

**Source:** Render every unconditional file plus only the conditional selector
files approved by the frontend architecture plan. Portal-shell files come from
[`_refs/angular/templates/init-portal-templates.md`](_refs/angular/templates/init-portal-templates.md);
sample module/entity files come from `init-module.md` and `init-entity.md`.
Substitute `<CORE_UI_PACKAGE_NAME>` / `<CORE_VERSION>` before writing.

**Brand asset (logo):**
- Copy [`_refs/angular/assets/logo.png`](_refs/angular/assets/logo.png) into the generated portal at `public/logo.png`.
- Wire it in [`src/app/configurations/layout.configuration.ts`](_refs/angular/templates/init-portal-templates.md#layoutconfigurationts) as `sidebar.logoUrl: '/logo.png'` (template handles this).
- If the user supplies a project-specific logo later, they only need to replace `public/logo.png` — no code change.

**Render Exclusion Rule (MANDATORY):**
- Never render local AI/tooling folders into the target starter repo
- Exclude at minimum: `.claude`, `.github`, `.git`, `.vscode-test`
- Exclude `.gitkeep` placeholders in generated output, especially under `src/libs/**`
- If these folders appear in output, remove them before returning generation result

**Result:** Fresh portal project with:

```
portal-new/
├── package.json                   # <CORE_UI_PACKAGE_NAME>: <CORE_VERSION> (npm) + @sdcorejs/utils
├── tsconfig.json                  # baseUrl + @sample paths
├── angular.json                   # build/serve configs
├── src/
│   ├── main.ts                    # Bootstrap with config providers
│   ├── app/
│   │   ├── app.component.ts       # RouterOutlet
│   │   ├── app.routes.ts          # Lazy-load layout + sample
│   │   └── configurations/        # Auth, Layout, Permission
│   └── libs/
│       └── sample/                # ONE sample lib only
│           ├── sample.configuration.ts
│           ├── sample.module.ts
│           ├── routes.ts
│           ├── configurations/    # API interceptor, upload config
│           ├── services/base/     # BaseService with CRUD
│           ├── components/        # optional; only approved module-level reusables
│           │   ├── base-select/   # conditional shared dropdown contract
│           │   └── customer-select/ # conditional; only when consumed by Order
│           └── features/          # greenfield fallback; preserve established project roots
│               ├── order/         # AdaptiveSplitDetail — approved customer-selection boundary
│               └── customer/      # UnifiedCompact full-page detail
├── .prettierrc.json
└── .vscode/
```

### Step 2: Dependency Management

Run `npm install`. See `package.json` template below — pins `<CORE_UI_PACKAGE_NAME>@<CORE_VERSION>` and includes `@sdcorejs/utils` as a direct dependency for shared helpers.

### Step 3: Build Verification

```
npm run build-dev
# Expect: exit code 0, dist/ folder produced
```

### Step 4: Dev Server

```
npm start
# Expect: server at http://localhost:4200/
```

### Step 5: Test Verification (Mandatory)

```bash
# Unit/integration
npm run test -- --watch=false

# E2E (only when project has e2e script/config)
npm run e2e
```

Report pass/fail summary and failing spec names. If E2E missing, report blocker.

---

## 3. Rules

### MUST DO ✅
- Read `_refs/angular/core-version.md` and substitute placeholders BEFORE writing any file
- Render all mapped portal-shell templates from
  [`_refs/angular/templates/init-portal-templates.md`](_refs/angular/templates/init-portal-templates.md),
  then use the module/entity references for the sample feature; materialize
  selector files only when the approved conditional gate selects them
- Use this template-first portal baseline for new approved technical prototypes
  before approved module/entity/list/detail/create/update generation; admin
  screens remain conditional
- Copy [`_refs/angular/assets/logo.png`](_refs/angular/assets/logo.png) to `<project>/public/logo.png` and ensure `LayoutConfiguration.sidebar.logoUrl === '/logo.png'`
- Generate exactly ONE sample lib with TWO entities: `order` + `customer`. Record whether Order reuses an existing/Core UI customer selector, creates a feature-local domain selector, or keeps the selection UI inline; do not require a generic wrapper to demonstrate reuse.
- For greenfield portals, use `features/` at the lib level: `src/libs/<lib>/features/<entity>/`.
- In an established project, preserve its coherent feature root and naming (`modules/`, `features/`, or another discovered convention). Change it only under an approved migration plan.
- Place a sample selector at module level only after
  `_refs/shared/frontend-architecture.md` and `./init-module.md` prove a stable
  cross-feature contract, no compatible existing/Core UI selector, and an actual
  same-change consumer. Otherwise use a feature-local domain selector or no
  wrapper.
- Keep the layout route lazy-loaded from Core UI: `loadChildren: () => import('<CORE_UI_PACKAGE_NAME>/modules/layout').then(m => m.SdLayoutModule)`
- Permission code convention is **flexible per project, consistent within a project**:
  - Scaffold default: `<MODULE>_<ENTITY>_<ACTION>` (e.g. `SAMPLE_ORDER_LIST`)
  - Acceptable variants: `<MODULE>_C_<ENTITY>_<ACTION>` (e.g. `SAMPLE_C_ORDER_LIST`), `<MODULE>_<ENTITY>:<ACTION>`, etc.
  - REQUIREMENT: Module → Entity → Action order, large-to-small, AND a single convention across the whole portal. Never mix two conventions in one project.
  - When applying to an existing project, detect the established convention and follow it
- Permission Configuration in starter MUST default to `disabled = true` so the portal boots without a permission backend
- Add a final double-check report covering: routes, provider wiring, environment scripts, unresolved imports

### MUST NOT ❌
- Do not hard-code fixed home/about restrictions; starter may include a customizable `src/app/pages/home` and wire `LayoutConfiguration.homeUrl`
- Do not skip `src/libs/sample` in starter generation
- Do not skip seeding 2 sample entities (`order`, `customer`)
- Do not use local tarball dependency style (`file:sd-angular-core-*.tgz`)
- Do not leave broken path aliases to removed libs in `tsconfig.json`
- Do not generate a starter that requires backend auth, permissions, or APIs to boot locally
- Do not replace `<CORE_UI_PACKAGE_NAME>` with ad-hoc local components
- Do not create a custom portal shell, bespoke navigation/sidebar/header,
  standalone dashboard, or alternative page/form/table framework for a prototype
  instead of rendering the Core UI starter template
- Do not hard-code environment names different from the developer request
- Do not place `SD_PERMISSION_CONFIGURATION` / `SD_UPLOAD_FILE_CONFIGURATION` in module or route providers with `multi: true` and expect root services to consume them
- Do not enable permission checks by default (`disabled = true`) when permission backend/data source is not ready
- Do not mix two permission-code conventions in the same project
- Do not generate external scaffold-generator files, package scripts, or dependencies beyond the standard template dependencies. This skill renders files directly from refs/templates.

---

## 4. Template

### Preconditions
```text
Required before applying this reference:
- `_refs/angular/templates/init-portal-templates.md` is present (file-content templates)
- `_refs/angular/core-version.md` is present (packageName + currentVersion)
- `_refs/angular/assets/logo.png` is present (default brand logo)
- developer confirmed project name
- developer confirmed environment names
- developer confirmed starter should include sample scaffold under `src/libs/sample`
```

### Clarification Questions
```text
Ask the developer:
1. What is the new portal project name? (example: portal-ops)
2. Which environments are needed? Default: dev, qc, uat, prod
3. What default portal/sidebar title should be used?
4. Keep the two default sample entities (`order`, `customer`) or rename them?
```

### Expected Starter Structure
```text
[project-name]/
├── angular.json
├── package.json
├── tsconfig.json
├── tsconfig.app.json
├── tsconfig.spec.json
├── eslint.config.js
├── public/
│   ├── silent-renew.html
│   └── logo.png                    # copied from _refs/angular/assets/logo.png; replace per project
├── src/
│   ├── index.html
│   ├── main.ts
│   ├── styles.scss
│   ├── app/
│   │   ├── app.component.ts
│   │   ├── app.routes.ts
│   │   ├── components/
│   │   │   └── main/
│   │   │       ├── main.component.ts
│   │   │       └── main.component.html
│   │   └── configurations/
│   │       ├── auth.configuration.ts
│   │       ├── layout.configuration.ts
│   │       ├── permission.configuration.ts
│   │       └── index.ts
│   └── environments/
│       ├── environment.model.ts
│       ├── environment.ts
│       ├── environment.dev.ts
│       ├── environment.qc.ts
│       ├── environment.uat.ts
│       └── environment.prod.ts
└── src/libs/
    └── sample/
        ├── sample.configuration.ts
        ├── sample.module.ts
        ├── routes.ts
        ├── index.ts
        ├── configurations/
        │   ├── api.configuration.ts
        │   └── upload-file.configuration.ts
        ├── services/
        │   └── base/
        │       └── base.service.ts
        ├── components/                         # optional; omit when no approved shared selector exists
        │   ├── base-select/                    # conditional stable shared abstraction
        │   │   ├── base-select.component.ts
        │   │   └── base-select.component.html
        │   └── customer-select/                # conditional actual domain consumer
        │       └── customer-select.component.ts
        └── features/                           # greenfield default; use the discovered root in established projects
            ├── order/
            │   ├── routes.ts
            │   ├── services/
            │   │   ├── order.model.ts
            │   │   └── order.service.ts
            │   └── pages/
            │       ├── list/list.component.ts
            │       └── detail/detail.component.ts
            └── customer/
                ├── routes.ts
                ├── services/
                │   ├── customer.model.ts
                │   └── customer.service.ts
                └── pages/
                    ├── list/list.component.ts
                    └── detail/detail.component.ts
```

### Code templates

All file-content templates referenced by the Generation Steps above live in [`_refs/angular/templates/init-portal-templates.md`](_refs/angular/templates/init-portal-templates.md). Read it when writing the corresponding files:

| File to generate | Section in templates ref |
|---|---|
| `package.json` | [`#packagejson`](_refs/angular/templates/init-portal-templates.md#packagejson) |
| `src/app/app.routes.ts` | [`#approutests`](_refs/angular/templates/init-portal-templates.md#approutests) |
| `src/main.ts` | [`#maints`](_refs/angular/templates/init-portal-templates.md#maints) — most rationale-heavy; preserve the inline `// Why ...` comments verbatim |
| `src/app/configurations/permission.configuration.ts` | [`#permissionconfigurationts-starter-default--disabled`](_refs/angular/templates/init-portal-templates.md#permissionconfigurationts-starter-default--disabled) |
| `src/app/configurations/layout.configuration.ts` | [`#layoutconfigurationts`](_refs/angular/templates/init-portal-templates.md#layoutconfigurationts) — wires `sidebar.logoUrl: '/logo.png'` |
| `public/logo.png` | copy raw bytes from [`_refs/angular/assets/logo.png`](_refs/angular/assets/logo.png) (no substitution) |
| `src/libs/sample/routes.ts` | [`#sampleroutests`](_refs/angular/templates/init-portal-templates.md#sampleroutests) |

Resolve `<CORE_UI_PACKAGE_NAME>` and `<CORE_VERSION>` from `_refs/angular/core-version.md` **before** materializing any of these files (see §"<localized text>" at the top of this reference).

### Verification Steps
```text
After generation:
1. Confirm package name, Angular project name, and output path match developer request
2. Confirm every unconditional file and every approved conditional file in §"Expected Starter Structure" was rendered from `_refs/angular/templates/init-portal-templates.md`, omitted selector files were not generated, and no workspace-external dependency is referenced
3. Confirm `public/logo.png` exists in the target project (copied from `_refs/angular/assets/logo.png`) and `LayoutConfiguration.sidebar.logoUrl === '/logo.png'`
4. Confirm `tsconfig.json` has no unnecessary `compilerOptions.baseUrl` (or document why it is needed)
5. Run npm install
6. Run npm start
7. Open /sample/order and /sample/customer routes — verify the sidebar renders the logo from `/logo.png`
8. Open Order detail and verify the approved customer-selection decision: reused selector, feature-local selector, or cohesive inline selection
9. If build config exists, run npm run build-dev
10. Run starter unit tests (at minimum route/bootstrap smoke specs)
```

---

## Validation Checklist (apply at end of generation)

- [ ] `_refs/angular/core-version.md` read; placeholders substituted (no literal version/package string left in generated files)
- [ ] `_refs/angular/templates/init-portal-templates.md` read and all mapped
      portal-shell sections rendered; module/entity references used for sample
      feature files; unapproved conditional selectors omitted
- [ ] Template-first portal baseline confirmed for explicit technical-prototype mode; no custom portal shell was generated before the Core UI starter template
- [ ] `public/logo.png` copied from `_refs/angular/assets/logo.png`; `LayoutConfiguration.sidebar.logoUrl === '/logo.png'`
- [ ] `package.json` pins `<CORE_UI_PACKAGE_NAME>@<CORE_VERSION>` (npm, not tgz)
- [ ] `package.json` includes `@sdcorejs/utils` as a direct dependency
- [ ] `tsconfig.json` has `"baseUrl": "./"` + `"@sample": ["./src/libs/sample"]` + `"@sample/*": ["./src/libs/sample/*"]`
- [ ] `app.routes.ts` lazy-loads sample lib + Core UI layout
- [ ] `SampleModule.useValue({ host: environment.sampleBackendUrl })` wired at root in `main.ts` (no route-level providers)
- [ ] Sample lib has 2 entities under the approved feature root (`src/libs/sample/features/` for greenfield; the discovered coherent root for established projects):
  - [ ] `order/` — Order list + detail; customer selection follows the recorded reuse/feature-local/inline decision
  - [ ] `customer/` — Customer list + detail
- [ ] Module-level selector decision recorded:
  - [ ] Reuse an existing/Core UI selector, or
  - [ ] Generate `src/libs/sample/components/base-select/` only when the stable
        abstraction gate passes and an actual sample consumer exists
  - [ ] Generate `src/libs/sample/components/customer-select/` only when the
        sample Order form consumes it
- [ ] Permission code convention is consistent across the generated portal (single style)
- [ ] Permission behavior matches the approved profile; any bypass is explicit,
      demo-only, and not production evidence
- [ ] `npm install` succeeds
- [ ] `npm run build-dev` exits 0
- [ ] `npm start` serves at `http://localhost:4200/`
- [ ] Order list renders; create flow opens with the approved customer-selection UI populated
- [ ] Prettier formats code on save
- [ ] `.vscode` extensions recommended

---

## Post-init — write the project summary

An approved project initialization owns the first project index. After the
validation checklist passes, the sequential workflow or integration owner may
run `sdcorejs-explore (summary-refresh)` to create summary v2 with
repository-relative evidence and workspace/dependency/source-root fingerprints.
Do not include branch, current HEAD as the freshness key, task/session state, or
current verification. Emit the summary as a conditional shared artifact in
`artifact_context`. If the refresh cannot run safely, leave summary missing and
let later work use targeted reads; project work must not be blocked.

---

## 5. Example Input

```text
Khoi tao du an portal-starter-moi co cac moi truong dev, qc, uat va prod.
Can include sample scaffold de demo module + entity-select pattern.
Tich hop san <CORE_UI_PACKAGE_NAME>.
Tao src/libs/sample va seed 2 entity order, customer (Order su dung customer-select).
```

## 6. Example Output

### Agent Decision
```text
Render the mapped portal-shell files from _refs/angular/templates/init-portal-templates.md.
Generate sample module/entity files from their focused references and omit any
selector not approved by the architecture plan.
Copy _refs/angular/assets/logo.png to public/logo.png and wire sidebar.logoUrl.
Create project portal-starter-moi.
Keep app shell, core configuration, environments, and generated sample files.
Generate src/libs/sample scaffold with:
  - conditional components/base-select only when the approved stable search contract requires it
  - conditional components/customer-select only when the Order sample consumes it
  - features/order (uses the approved reused, feature-local, or inline customer-selection boundary)
  - features/customer
Pin <CORE_UI_PACKAGE_NAME> to npm version <CORE_VERSION> via _refs/angular/core-version.md (no local tgz).
Ship PermissionConfiguration with disabled=true so the portal boots without a permission backend.
Then run npm install and npm start to verify the starter boots.
```

### Files Generated/Updated
```text
[project-name]/package.json
[project-name]/angular.json
[project-name]/tsconfig.json
[project-name]/src/main.ts
[project-name]/src/app/app.routes.ts
[project-name]/src/app/components/main/main.component.ts
[project-name]/src/app/components/main/main.component.html
[project-name]/src/app/configurations/auth.configuration.ts
[project-name]/src/app/configurations/layout.configuration.ts
[project-name]/src/app/configurations/permission.configuration.ts
[project-name]/public/logo.png
[project-name]/src/libs/sample/sample.configuration.ts
[project-name]/src/libs/sample/sample.module.ts
[project-name]/src/libs/sample/routes.ts
[project-name]/src/libs/sample/components/base-select/base-select.component.ts      # conditional
[project-name]/src/libs/sample/components/base-select/base-select.component.html    # conditional
[project-name]/src/libs/sample/components/customer-select/customer-select.component.ts # conditional
[project-name]/src/libs/sample/features/order/routes.ts
[project-name]/src/libs/sample/features/order/services/order.service.ts
[project-name]/src/libs/sample/features/order/services/order.model.ts
[project-name]/src/libs/sample/features/customer/routes.ts
[project-name]/src/libs/sample/features/customer/services/customer.service.ts
[project-name]/src/libs/sample/features/customer/services/customer.model.ts
[project-name]/src/environments/environment.dev.ts
[project-name]/src/environments/environment.qc.ts
[project-name]/src/environments/environment.uat.ts
[project-name]/src/environments/environment.prod.ts
```
