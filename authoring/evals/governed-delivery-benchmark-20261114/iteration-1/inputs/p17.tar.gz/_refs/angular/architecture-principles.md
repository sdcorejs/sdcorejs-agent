# Angular Portal — Architecture Principles

Source of truth for **WHY** SDCoreJS Angular portals look the way they do. Loaded on demand by `sdcorejs-brainstorming`, `sdcorejs-spec`, `11-init-module`, `12-init-entity`, and `sdcorejs-review`.

If a generated file contradicts a principle here, that file is wrong. If a principle here contradicts a real-world need, **the principle is wrong** — surface it as feedback, don't silently break it.

---

## 1. Project conventions first; feature-first fallback

Inspect and preserve an existing portal's coherent module, route, component,
service, public API, and test structure. The tree below is the greenfield Core UI
fallback, not a migration rule.

```
src/
├── app/                          ← thin shell only
│   ├── app.routes.ts             ← top-level routes (lazy-load modules)
│   ├── app.component.{ts,html}
│   └── main.ts                   ← bootstrap + root configurations
└── libs/
    └── <module>/                 ← feature module (catalog, sales, hr, …)
        ├── <module>.configuration.ts
        ├── <module>.module.ts    ← static providers
        ├── routes.ts             ← lazy-load children
        ├── guards/<module>.guard.ts
        ├── configurations/
        └── features/
            └── <entity>/         ← one entity vertical slice
                ├── <entity>.routes.ts
                ├── pages/list/   ← route/page shell + .spec.ts
                ├── pages/detail/ ← route/page shell (or side-drawer)
                ├── components/   ← only cohesive feature-local boundaries approved by the architecture plan
                └── services/
                    ├── <entity>.model.ts
                    ├── <entity>.mock-data.ts
                    ├── <entity>.service.ts
                    └── index.ts
```

**Why feature-first is the fallback**: when you delete a feature, you delete one
folder. When you find a bug in `product`, you grep one folder. A project with a
different established but coherent convention keeps that convention.

---

## 2. Module = bounded context

Each `libs/<module>/` is an **encapsulated bounded context**:

- Own configuration token, providers, guards, interceptors
- Own permission code prefix (`<MODULE>_*`)
- Own routes lazy-loaded at the app level
- Own upload-file configuration if relevant

A new module is justified when ≥1 of: distinct user persona, distinct permission boundary, distinct data lifecycle, distinct deployment surface. **Not** when there are "many entities" — those go into ONE module if they share a context.

**Rule of thumb**: if two entities never appear together on the same screen and never share a service method, they probably belong to different modules.

---

## 3. No cross-module imports (the killer rule)

Module A **MUST NOT** import from Module B directly. Both modules import from:

- `@sdcorejs/angular` — Core UI components, base classes, shared utilities
- `src/shared/` (if it exists) — cross-cutting types, interceptors, app-wide guards

If `module-a` needs data from `module-b`, the contract goes through `@sdcorejs/angular` (a base `<Entity>Service` extension) OR through a shared service registered at app root.

**Why**: cross-module imports create a dependency spiral. Module A imports
Module B's lazy chunk, so A cannot be code-split; CI build time grows and
refactoring B can break A silently.

**Enforce by**: `eslint-plugin-boundaries` rules (config in target project), and `sdcorejs-review` flags violations as **Critical**.

---

## 3a. Codebase-first entity reuse

Before generating any model, DTO, interface, type, service, store, repository, or
API client, scan the target codebase for the primary entity and every related
entity. External artifacts describe the new contract; existing code decides
what to reuse, extend, or create.

Rules:
- Reuse an existing related model/service/type when one exists.
- Extend existing contracts minimally and compatibly when a new field or method
  is required.
- Create a new contract only after searching common file and symbol variants.
- Model relation ids as `<entity>Id` when the API only returns an id.
- Reuse summary/minimal relation types for partial nested payloads.
- Do not inline a full related entity object inside another model when that
  related entity already has its own contract.
- Do not create duplicate services such as `OrderCustomerService` when
  `CustomerService` owns customer API logic.

See `_refs/angular/write-code/reuse-existing-entities.md` for the operational
preflight used by `sdcorejs-angular`.

---

## 4. UI components are dumb; services own logic

Component responsibilities:
- Wire user input → service method calls
- Display state via signals/computed
- Navigate via `inject(Router)`

Service responsibilities:
- Fetch / mutate data (mock or API)
- Business rules (validation, transitions, derived data)
- Caching / state coordination

**Anti-pattern**: `<button (click)="if (item.status==='DRAFT' && hasPermission('APPROVE')) updateStatus(item, 'APPROVED')">`. Move the condition + transition to `service.approve(item)`.

If a method on a service is >50 lines, split it. If a component method is >15 lines, push to service.

---

## 5. Signal-first state, RxJS only at boundaries

Default state primitive:
- `signal<T>(initial)` for mutable UI state (loading flags, current entity, table options, dialog open/close, selection)
- `computed(() => derive(...))` for derived state (button visibility, header title, isDirty, hasError)
- `effect(() => ...)` only for true side-effects (reload data on route param change, sync URL with filter state)

Use RxJS at **boundaries** only:
- HTTP via `HttpClient` (returns Observable; convert to signal in service)
- Form valueChanges (sometimes signal-incompatible; OK to subscribe + manage)
- 3rd-party libs that ship Observable APIs

**Why**: signals are change-detection-friendly (OnPush works automatically), readable in templates (`{{ entity().name }}`), and free of subscription leaks. RxJS is powerful but easy to abuse.

**Migration rule**: when refactoring legacy code, convert `BehaviorSubject` → `signal`, `combineLatest` → `computed`, `subscribe` → `effect` (or stream-end via `takeUntilDestroyed`).

---

## 6. `inject()`, not constructor DI

```ts
// ✅ correct
export class ProductListComponent {
  readonly #router = inject(Router);
  readonly #svc = inject(ProductService);
}

// ❌ legacy — do not generate
constructor(private router: Router, private svc: ProductService) {}
```

**Why**: `inject()` works in functional contexts (guards, interceptors, route resolvers), removes constructor noise, and pairs with `#private` fields for true encapsulation. `sdcorejs-review` flags `<localized text>` as Critical.

---

## 7. `ChangeDetectionStrategy.OnPush` by default

Every generated component declares `changeDetection: ChangeDetectionStrategy.OnPush`. State changes flow through signals → OnPush is "free" (no `markForCheck` needed for signal reads).

When you have async state update **before** assigning to a non-signal field, either:
- Migrate the field to `signal()` (preferred), OR
- Inject `ChangeDetectorRef` and call `#cdr.markForCheck()` after assignment.

**Why OnPush is the default**: a portal with 50+ components on a page can have 1000+ change-detection cycles per click in default mode. OnPush brings it down to "only what touched a signal".

---

## 8. Mock-first data boundary until backend contract is explicit

```ts
@Injectable() // example feature-scoped choice; use root only when justified
export class ProductService extends MockCrudStore<ProductDTO, ProductSaveReq> {
  constructor() { super('product', PRODUCT_SEED); }
}
```

- For an explicitly approved `technical-prototype`, use
  `MockCrudStore`/`localStorage` only when `mock-service` is approved; generate
  seed rows only when `seed-data` and its row count are approved
- For technical prototypes driven by mock API docs, match the approved contract shape
- Switch to `BaseService.register('<entity>')` only when a runnable backend endpoint/configuration and project service convention are provided
- Choose provider scope from responsibility and consumers: stateless shared API
  services may follow the existing app/root convention; mutable feature
  facades/stores belong at route/feature/page scope; overlay coordinators belong
  at component scope; pure mappers/validators remain functions when appropriate

**Why**: frontend can ship + iterate without a backend. Mock rows must be **domain-realistic** (`<localized text>` not `"Name 1"`) — bad seed data hides UX issues (column too narrow for real names, sort key collisions).

---

## 9. Four canonical detail layouts (no inventing new ones)

| Layout | When | Component shell |
|---|---|---|
| **side-drawer** | ≤6 fields, 1 section, no workflow, quick CRUD | `components/<entity>-side-drawer/` |
| **UnifiedCompact** | medium form, mixed user skill, same layout for CREATE/UPDATE/DETAIL | `pages/detail/` |
| **UnifiedSplit** | title context always visible (left), form right | `pages/detail/` |
| **AdaptiveSplitDetail** | workflow heavy, multi-section, DETAIL uses read-only blocks via `sd-section-item` | `pages/detail/` |

**Why constrain to 4**: layout consistency across modules is more important than perfect per-screen UX. A user opening a new screen recognizes the pattern in 2 seconds. Custom layouts = retraining cost per screen.

If a screen genuinely does not fit these variants, return to design approval;
do not silently invent a fifth variant.

---

## 10. Permission codes are route-data, not component-logic

```ts
{
  path: 'product',
  loadChildren: () => import('./product.routes').then(m => m.routes),
  data: { permission: 'CRM_PRODUCT_LIST' }
}
```

The **module-level guard** reads `data.permission` and blocks navigation. Components **never** call `permission.check('CRM_PRODUCT_LIST')` themselves for route-level access (that's duplication; the guard already did it).

**Component-level permission** only for in-screen buttons:
```html
<sd-button *sdHasPermission="'CRM_PRODUCT_APPROVE'"><localized label></sd-button>
```

Code naming: `<MODULE>_<ENTITY>_<ACTION>` UPPERCASE. Module → Entity → Action order, never the reverse. Project may use `<MODULE>_C_<ENTITY>_<ACTION>` if `_C_` is the established convention — **detect from existing code, don't impose**.

---

## 11. Audit columns on every primary list

Every list of top-level entities ends with 4 columns:
- `createdAt` (datetime, 180px)
- `createdBy` (string, min 180px)
- `updatedAt` (datetime, 180px)
- `updatedBy` (string, min 180px)

**Skip only** for: sub-tables on detail pages, lookup/enum tables (code+name only), dialog/drawer compact tables, or user-explicit "no audit needed".

**Why**: backoffice users debug data quality by audit fields. Without them, every "this data is wrong" investigation requires a backend log dig.

Field names vary per backend framework (`createdAt` vs `CreatedDate` vs `created_at`). **Always check the actual DTO** — never assume.

---

## 12. Bilingual: VI is first-class, English is structural

Vietnamese portal (default for SDCoreJS):
- Labels, headers, button text, validation messages → **VI with full diacritics** (`<localized text>` not `"Phe duyet"`)
- Permission codes, route paths, file names, code identifiers → **English** always

Future bilingual support (VI + EN): keep labels in i18n JSON, default to VI, structure-ready for `next-intl`-style switching. Do NOT machine-translate.

**Why**: VI-only users can't trust English. EN-only stakeholders need structure-ready code. Permission codes in English avoid encoding pitfalls when codes flow through middleware / Kafka / logs.

---

## 13. Standalone-first; hybrid mode supported

New code → **standalone components** with `imports: [...]` on each.

Hybrid NgModule + standalone (legacy portal migration): supported but flagged. `sdcorejs-brainstorming` asks "<localized text>" when generation could go either way.

**Why**: Angular's direction is standalone. NgModules add a layer of indirection (declarations / exports / imports) that's purely ceremonial when you have standalone.

---

## 14. Core UI first; custom UI is a flagged exception

Order of preference when picking a UI primitive:
1. `@sdcorejs/angular` component fits → use it
2. Composition of Core UI components fits → use them
3. No Core UI fit → generate custom with explicit marker:
   ```ts
   // CUSTOM_UI: <reason — what Core UI lacks>
   ```
   Render a placeholder block, render its actions disabled with a `<localized label>` hint that the action is not implemented yet, and list each one in the generation summary. Do not wire alert calls or TODO tags (see [`_refs/shared/static-analysis-compatibility.md`](../shared/static-analysis-compatibility.md)).

**Why**: Core UI ships consistent a11y, theming, RTL support, and behavior. Custom UI re-litigates these per-component, badly. The flagged exception forces the conversation: "<localized text>"

Run `node _refs/angular/core-docs-fetch.mjs --list` for the full inventory (on-demand; docs not committed).

---

## 15. Tests live with the code they test

`product.service.ts` ↔ `product.service.spec.ts` (same folder).
`list.component.ts` ↔ `list.component.spec.ts` (same folder).

No central `__tests__/` directory; no parallel `tests/` tree.

**Why**: when you delete a feature folder, the tests die with it (correct). When you rename a service, your IDE renames the spec next to it (correct). When a reviewer reads a service, the spec is one tab over (correct).

Test coverage defaults to `standard` and the approach defaults to `TDD` (RED-first) — specs are a mandatory deliverable, written before their production file, never gated behind a question. `sdcorejs-brainstorming` only records an OVERRIDE (`minimal`/`full`, or `post-hoc` ordering) when the user explicitly asks; absent that, the agent proceeds with standard + RED-first.

---

## 16. Utility-first styling — reuse the shipped system, don't hand-roll CSS

Core UI (`@sdcorejs/angular`) ships a complete SCSS utility system (`assets/scss/sd-core.scss`): flex, grid, spacing, sizing, color, typography, border, elevation. Generated templates style with those classes (`d-flex gap-16`, `col-md-6`, `text-primary`, `T14M`, `rounded-8`, `mat-elevation-z2`); component `.scss` stays near-empty. If the consumer app ships Tailwind, its utilities are equally valid — match the system the existing components already use.

**Why**: a utility class is themed, reviewed, and consistent across the whole portal; a bespoke `display:flex; gap:16px` rule in one component drifts from the design system, bloats files, and trains readers to skim past CSS. Custom `.scss` is reserved for genuine one-offs (computed gradient, off-scale size, animation) — token-based and commented with a `// why:`. The class list is ALWAYS fetched on demand (`node _refs/angular/core-docs-fetch.mjs --print assets/STYLE-GUIDE`) and never committed/hardcoded — a stored copy drifts from the published library; the operational rules (not the class list) live in `_refs/angular/styling.md`.

Gotcha that causes real bugs: Core UI spacing/sizing is **absolute px, integer 0–200** (`mb-16` = 16px), not Bootstrap multipliers — use multiples of 4, never off-scale values.

## 17. The portal is not the agent

This skill set generates Angular portals. The principles above govern the **generated code**, not this `sdcorejs-agent` repo. When a developer asks "why does the generated module have X", the answer comes from this file — not from the skill body that emitted X.

When a principle here changes, propagate to:
- The skill that generates it (e.g. `11-init-module.md`, `12-init-entity.md`)
- The reviewer that enforces it (`sdcorejs-review.md`)
- The auto-docs template if it touches the dimension being changed

---

## Anti-principles (NOT to do)

- ❌ "Move fast, refactor later" — refactoring cross-module imports later costs 10× more than getting them right now
- ❌ "Add a new layout because this screen is special" — there are only 4 layouts; if your screen doesn't fit, you're solving the wrong problem
- ❌ "Skip OnPush for this one component" — once one component opts out, the change-detection cost cascades unpredictably
- ❌ "Use a BehaviorSubject because the team knows RxJS" — signal is the new default; RxJS knowledge transfers, signal-knowledge doesn't yet, fix the gap, not the architecture
- ❌ "Hardcode permission check in component" — route guard owns access; component owns action-button visibility (different concerns)
- ❌ "<localized text>" — bad mock data hides real UX bugs; spend the 10 minutes to write domain-realistic rows
- ❌ "Skip audit columns on this list because we're in a hurry" — they cost 4 lines of code and save hours of debugging

---

## Related references

- `_refs/angular/core-version.md` — pinned `@sdcorejs/angular` version
- Core UI components inventory — `node _refs/angular/core-docs-fetch.mjs --list` (on-demand; docs not committed)
- `_refs/angular/entity-field-types.md` — field-type → form-control mapping
- `_refs/angular/write-code/reuse-existing-entities.md` — codebase-first model/service/entity reuse preflight
- `_refs/shared/frontend-architecture.md` — mandatory component, state, service,
  provider, registration, and public API preflight
- `_refs/angular/templates/feature-component-boundaries.md` — route/page,
  feature-local child, collaborator, and architecture-test templates
- `_refs/angular/templates/entity-skeleton.md` — canonical code templates these principles produce
- `_refs/angular/templates/example-product.md` — worked example end-to-end
- `sdcorejs-documentation (code-documentation mode)` + `_refs/documentation/code-documentation.md` — when/how to document public contracts and WHY these principles applied in a specific decision
