# SDCoreJS SDLC Agent

Engineering pack for developers and technical teams with 25 public skills: product/design/test, Angular, NestJS, Next.js, AI-agent and generic workflows. Private Node workspace: validation-only.

Runtime-localized output preserves locale marks; identifiers, permissions, env keys and routes stay English.

Social editorial work routes to `sdcorejs-content`; technical docs, PRDs and code keep their
own owners. Content drafts require no engineering artifact chain and grant no
publishing/scheduling/messaging permission. Apply `_refs/shared/session-authority.md`
at workflow transitions; reuse scoped authorization without inventing review.

For pack authoring, follow `authoring/prerequisites.md`: install
required skills before implementation and run independent NVIDIA audit afterward.
Consumers are exempt.

## Skill Source Language

Author `skills/**`, `_refs/**`, prompts, templates, reusable examples, and
generated mirrors in English only. Runtime localization belongs to the
consuming project/session; use locale-neutral placeholders such as
`<localized label>` in reusable sources.

Localization test prompts may use non-English input when they are explicitly
fixtures for dispatch/runtime-localization behavior. Expected source text and
generated prose remain English-only and locale-neutral.

## Dispatch

Dispatch by `name:` frontmatter and the `description:` trigger. Load only frontmatter at session start; read a skill body only after selecting that skill.

Use `_refs/shared/system-registry.json` as the versioned source for tracks,
stack profiles, artifact kinds, repository roles, review/repair/ship support,
and evidence classes. Keep track, stack profile, capability profile, artifact
owner, repository role, and execution host as separate fields. The current
working directory is never evidence of artifact ownership.

When multiple skills match, apply this priority before reading a body:

1. Explicit skill name from the user.
2. Approved spec: architecture when required; approved plan:
   `sdcorejs-execute-plan`; explicit delegated execution:
   `sdcorejs-subagent-driven-development`.
3. Product, design, or direct test work: `sdcorejs-product`,
   `sdcorejs-design`, or `sdcorejs-test`; failing-test diagnosis uses
   `sdcorejs-debug`.
4. Dedicated utility intent: `sdcorejs-cleanup`, `sdcorejs-simplify`, `sdcorejs-explore`,
   `sdcorejs-documentation`, `sdcorejs-review`, `sdcorejs-repair-loop`,
   `sdcorejs-debug`, `sdcorejs-ship`, or `sdcorejs-git`.
5. Confirmed track implementation: `sdcorejs-ai-agent`, `sdcorejs-angular`,
   `sdcorejs-nestjs`, or `sdcorejs-nextjs`.
6. Open-ended, ambiguous, or under-specified scope: `sdcorejs-brainstorming`.

Review repair belongs to `sdcorejs-repair-loop`; readiness belongs to
`sdcorejs-ship`; Git artifacts belong to `sdcorejs-git` after the required
ship evidence. Broad refactors and under-specified AI-agent work return to
brainstorming. `sdcorejs-simplify` is only for bounded, behavior-preserving
source refinement.

`sdcorejs-cleanup` owns bounded output/asset/doc hygiene (default read-only).
Offers authorize analysis only; mutations require its exact authority gate.
Load `_refs/cleanup/workflow.md` for risk, recovery and task-tail rules.

## Workflow

```text
brainstorming -> spec -> architecture when required -> plan -> execute-plan
  -> selected executor or generic harness -> mandatory finish gate
  -> test -> optional simplify -> focused tests -> review -> repair
  -> required docs/traceability -> authorized convention sync
  -> authorized current-task cleanup -> affected verification
  -> validation evidence -> convergence -> final read-only branch-ready
```

Project conventions live under `.sdcorejs/conventions/**`, one rule per file.
`sdcorejs-review` reads them and reports naming, API, route, casing,
vocabulary, cross-layer, and mapping drift while staying read-only. Only
`sdcorejs-explore (conventions-sync-write-approved)` persists them, run by the
sequential or fan-in integration owner after the final code writes. See
`_refs/shared/convention-context.md` and `_refs/shared/review-consistency.md`.

Decision identities, conditional architecture, validation-map evidence, and
convergence are executable gates. Repair classifies external feedback before
writes. Internal `authoring/**` skills are never public or mirrored.

No write-producing step may run after final branch-ready unless branch-ready is
run again before any Git artifact handoff.

Approved-plan delegation uses `sdcorejs-subagent-driven-development`, with
parent fallback. Read-only parallel audits use `sdcorejs-parallel-dispatch`.
Debug/review/explore also assess 2+ substantial independent domains without
parallel wording; owner hooks preserve host/session authority, sequential/no-agent
choices and non-recursion. Require safe ownership, isolation and fan-in;
unknown independence stays with the owner. Unapproved writes return to planning.

Answer pure Q&A directly. Bounded low-risk fixes use targeted context, minimal
edits, focused verification and concise review without spec/plan artifacts.
Scope, ownership, risk or behavior growth requires the full workflow.

Canonical skills declare semantic `required-actions`; provider mappings and
tri-state capabilities live in `_refs/harness/capability-contract.json`.
Unsupported or unknown capabilities use portable Markdown and sequential
fallbacks.

Use compact, complete professional sentences. Use detailed output for approval,
security, destructive actions, ambiguity, conflicts, blockers and failed checks.
Load `_refs/harness/communication-economy.md` for profiles, progress and handoffs.
Preserve exact identifiers, evidence and typed context. Use validated portable
handoffs when runtime context channels are unsupported or unknown.

## Production SDLC Scope Decision

Current approved scope is an engineering-focused SDLC skill pack: governed
product/design/test evidence, supported code generation, AI-agent application
contracts, technical security guidance, branch hygiene, Git artifacts, and
recovery memory.

Do **not** add new production-SDLC skills or refs for CI/CD pipelines, IaC, staging/production promotion, observability, incident response, SRE runbooks, migration rollout, compliance gates, or release governance until the user explicitly approves that expansion. If requested, start with `sdcorejs-brainstorming` and an approved spec/plan before authoring new skill/ref surfaces.

## Mandatory Execution Discipline

For non-trivial execution, use `_refs/shared/tasklist.md`: create outcome-based runtime progress before work and update only for meaningful events. Completion or readiness claims require verification or explicit disclosure of skipped checks.

## Mandatory Rules

1. Project context first when needed: apply the read-only
   `_refs/shared/project-context.md`; use summary when valid and targeted reads
   when it is missing or stale.
2. Requirements before code: use `sdcorejs-brainstorming` until minimum blockers are confirmed.
3. Spec/plan gates use explicit approval or scoped session delegation; silence is neither.
4. Approved snapshots: `sdcorejs-spec` and `sdcorejs-plan` write approved snapshots themselves before the next phase.
5. Execute approved plans through `sdcorejs-execute-plan`; it owns track,
   profile, generic fallback, and execution-mode resolution.
6. Finish gate is mandatory after every code-generation run, including direct track executor requests.
7. Evidence before claims: never say pass, fixed, built, or done without current verification output.
8. Durable execution records and explicitly owned backlog artifacts write to
   the target project, not to this agent repo. Live task progress remains in
   the thread/harness.
9. Mojibake is a blocking defect in prompts, docs, skills, comments, and user-facing strings.
10. Use supported native interaction when available and portable numbered
    Markdown otherwise. Written replies remain authoritative.
11. Keep source English-only and localize generated runtime output.
12. Do not author new skills without explicit user approval.
13. Do not expand into production SDLC skill/ref coverage without the explicit approval described in **Production SDLC Scope Decision**.
14. Local runtime/Visual Companion state needs purpose-bound consent and stays
    `local_only`. Capability and visual selection are not approval; browser
    opening has separate consent.

## Session-Start Ritual

Apply `_refs/shared/project-context.md`: explicit/current evidence first, then
valid summary sections and relationship-matched artifacts. Ignore legacy session
checkpoints. Read persona only when relevant; live progress stays in the runtime.

## Reference Loading

Follow `_refs/shared/runtime-protocols.md` for mandatory shared JIT hooks;
its context, progress, communication, delegation and visual rules apply at
their declared triggers. Additional loading:

- `_refs/harness/capability-contract.json` for semantic action/capability resolution.
- `_refs/shared/artifact-lifecycle.md` before `.sdcorejs/**` writes or Git closure.
- `_refs/shared/user-choice-prompt.md` before choices, approvals or mode selection.
- Relevant `_refs/sdlc/*.md` for brainstorming, architecture, spec or plan.
- `_refs/shared/testing-philosophy.md` for test-track work.
- Decision coverage, validation-map, and convergence references at their gates.
- `_refs/simplify/**` for bounded behavior-preserving source refinement.
- `_refs/angular/core-docs-fetch.mjs` before using Core UI components.
- `_refs/<track>/review-*.md` during review.
- `_refs/orchestration/workspace-isolation.md` for execution workspace isolation.
- `_refs/orchestration/tail/verify-before-done.md` during `sdcorejs-ship (verify-before-done mode)`.
- `_refs/orchestration/tail/branch-ready.md` during `sdcorejs-ship (branch-ready mode)`.

## Shared reference

Before track execution or its finish chain, read the relevant executor/provider and tail sections of `AGENTS.reference.md`.

For small edits, apply the risk baseline in `_refs/shared/finish-gate.md`.
