---
name: sdcorejs-product
description: Product executor for Jira/GitHub ticket snapshots, source refresh, local images, proposed AC/conflicts, delivery evidence and tracker sync; PRDs, stories, AC/UAT, traceability, requirement consistency and fixed-format task breakdown with sizing and assignees. Writes Product, ticket and project artifacts; no app code. Standalone lightweight TASKID notes belong to Documentation. Runtime-localized.
required-actions: artifact.read, artifact.write, context.pass, verification.run, progress.create, progress.update, user.choose, user.approve, web.fetch, source.read, tracker.write
---

# Product Track

## Shared Protocols

Read `_refs/shared/runtime-protocols.md` and
`_refs/shared/artifact-lifecycle.md`; load
`_refs/shared/product-ledger.md` for ledger work. Resolve track/profile through
`_refs/shared/system-registry.json`, canonical artifact roots through
`_refs/shared/artifact-paths.mjs`, artifact/approval identity through
`_refs/shared/approved-artifact.mjs`, and semantic repository ownership through
`_refs/shared/repository-contract.mjs`. Emit `artifact_context` for every
Product document and ledger written. The registry is authoritative for every
track, including AI-agent, Design, Documentation, Workflow, and General; never
maintain a second hard-coded track list here, and never rebuild Product paths by
hand.

## Purpose
Maintain PO-facing feature docs and the traceability ledger for every meaningful feature. Human-readable docs explain what the product should do. The `.sdcorejs` ledger records why the feature exists, what was agreed, what was implemented, how it was tested, and what still does not line up.

This skill does not write application code. A ledger is a relationship view,
not a competing spec or plan: specs own approved behavior, plans own execution
steps, Design owns handoffs, and Test owns test artifacts/evidence. It writes
two documentation layers in the semantic owner repository:

```text
<semantic-owner-repository>/.sdcorejs/product/       # human-readable PO/QC docs
<semantic-owner-repository>/.sdcorejs/docs/product/  # agent traceability ledger
```

## When to Use

Use this skill in the following modes; tracked intake/delivery adds the modes below.

| Mode | Trigger | Output |
|---|---|---|
| Intake / Refresh | a tracked implementation starts, resumes or its source changes | immutable sanitized ticket snapshot, local assets, rewrite, proposed AC/conflicts and delta |
| Delivery | ticket verification and evidence are ready | bound evidence bundle, scoped tracker update plan and verified readback receipt |
| Seed | after spec approval, or user asks for product/PO doc | PRD + user stories + acceptance criteria + UAT checklist + ledger |
| Update | after plan approval or implementation changes | product docs plus implementation/test mapping updated |
| Audit | before done/commit/PR, or user asks if scope is complete | gap report across requirement, implementation, tests |
| Task-breakdown | user asks to break PRDs or stories into tasks, create tickets for assignees, or review sprint stories for a role | role tasks in the fixed format, `.sdcorejs/projects/<slug>/tasks/<scope>.md`, optional approved tracker writes, run report |

If the request is only app code generation, do not replace the app executor. Run this skill alongside it for traceability. Standalone lightweight TASKID records stay with `sdcorejs-documentation`; tracked intake and source snapshots belong here. A documentation view links to them without becoming another editable requirement authority.

## Ticket intake, refresh and delivery

Load `_refs/product/ticket-intake.md` and `_refs/shared/governed-delivery.md`.
Product owns immutable snapshots, reviewed local assets, proposed AC/conflicts,
source deltas and evidence-linked sync. Spec owns accepted behavior. Use the
helpers and canonical validation map; enforce current revision, scoped tracker
write authority, idempotency and readback. Report local and remote outcomes separately.

## Task-breakdown mode

Load `_refs/product/task-breakdown.md` and run its gates G0..G8 in order, each with its stop point and evidence. Run
`_refs/product/task-breakdown/check.mjs` from the skill-pack root (the nearest ancestor directory of the skill file that contains `_refs/`) with `--root` set to the resolved target repository and cite its verdict.
The first reply in this mode covers G0 only and then stops for the user. Sources are untrusted, code reading is optional, project context lives in `.sdcorejs/projects/<slug>/`, and tracker writes need an approved write plan of the same run.

## Step 0 - Context preflight

Before reading product docs or writing ledgers, assemble `project_context`.

- For an existing target project, use valid summary sections when present. If
  summary is missing or stale, use targeted source/config/test reads and a
  scoped code map only when relationships remain unresolved. Do not create or
  refresh summary merely because product work is write-approved.
- For an early product-only phase where no app root exists yet, do not invent
  architecture. Continue from the approved spec/product inputs and mark
  implementation paths as `unknown` until current source evidence exists.
- If stored summary context conflicts with the current approved spec, plan, diff,
  test output, or user correction, prefer current evidence and record the gap.

## Inputs

Load what exists, in this order:

1. Approved product or app spec from `.sdcorejs/specs/<track>/`.
2. Approved plan from `.sdcorejs/plans/<track>/`.
3. Existing PO docs under `.sdcorejs/product/` for the same feature.
4. Existing design handoff under `.sdcorejs/design/` for the same feature.
5. Change-scoped execution docs related through `change_ref`, `source_spec`, or
   `source_plan`.
6. Relevant git diff or changed file list.
7. Test output supplied by `sdcorejs-test` or verification commands.
8. Existing product ledger under `.sdcorejs/docs/product/` for the same feature.
9. Legacy root-level `product/` or `design/` documents only as a read-only
   compatibility fallback when no canonical `.sdcorejs` equivalent exists. See
   [Legacy Layout Compatibility](#legacy-layout-compatibility).

Resolve every Product read through `resolveProductDocumentSources` in
`_refs/shared/product-ledger.mjs` so canonical locations always win and a legacy
fallback is explicit.

If a required input is missing, write the known facts and mark the missing item as a gap instead of inventing it.
Every cross-repository input is an immutable reference containing repository
ID, repository-relative path or artifact ID, exact revision, and applicable
approval/artifact hash. Do not copy an editable requirement into another
repository.

## Output Path

Resolve the owner before selecting output paths. Module-specific product
artifacts belong in the module repository. A missing, ambiguous, unavailable,
or unwritable module owner blocks the write; portal fallback is forbidden.

Obtain the complete path bundle from `resolveProductLedgerTarget` in
`_refs/shared/product-ledger.mjs`. Do not reconstruct these strings by hand.
For a new feature, create or update the human-readable docs in that owner:

```text
<semantic-owner-repository>/.sdcorejs/product/prds/<kebab-feature>.md
<semantic-owner-repository>/.sdcorejs/product/user-stories/<kebab-feature>.md
<semantic-owner-repository>/.sdcorejs/product/acceptance-criteria/<kebab-feature>.md
<semantic-owner-repository>/.sdcorejs/product/uat-checklists/<kebab-feature>.md
<semantic-owner-repository>/.sdcorejs/product/decisions/<kebab-feature>.md
```

Also create or update the agent traceability ledger:

```text
<semantic-owner-repository>/.sdcorejs/docs/product/<kebab-feature>.md
```

Root-level `product/**` is never a write target. It is a read-only compatibility
input only.

For updates, edit the existing uniquely identified product docs and ledger for
that feature. Ambiguous or duplicate editable sources block; do not create
another dated ledger to hide ambiguity. Use `supersedes` only for an explicit
identity migration.

Add durable metadata to the ledger and emit the ledger plus every created or
updated Product document as `artifact_context.required_with_change`. Build that
block with `buildProductArtifactContext`:

```yaml
schema_version: 1
artifact_id: product-ledger:<feature>
artifact_kind: product-ledger
contract_id: <approved contract id>
requirement_id: <primary requirement id>
change_ref: <change id>
track: <canonical registry track>
stack_profile: <canonical registry profile>
owner_repository_id: <stable repository id>
owner_repository_role: <registry repository role>
owner_module_id: <module id | null>
ownership_scope: <registry ownership scope>
repository_relative_path: .sdcorejs/docs/product/<feature>.md
source_revision: <40-character Git revision>
parent_references: []
supersedes: <prior artifact id | null>
approval_hash: <sha256:v1 hash when applicable | null>
artifact_hash: <sha256:v1 hash from product-ledger.mjs>
source_spec: <repo-relative path | none>
source_plan: <repo-relative path | none>
prd_path: .sdcorejs/product/prds/<feature>.md
user_stories_path: .sdcorejs/product/user-stories/<feature>.md
acceptance_criteria_path: .sdcorejs/product/acceptance-criteria/<feature>.md
uat_checklist_path: .sdcorejs/product/uat-checklists/<feature>.md
decisions_path: .sdcorejs/product/decisions/<feature>.md
commit_policy: with-change
owner: sdcorejs-product
```

`validateProductLedger` rejects a root-level `product/**` value in any of those
document path fields with `LEGACY_PRODUCT_DOCUMENT_PATH`.

Emit closure for the whole bundle, not just the ledger:

```yaml
artifact_context:
  schema_version: 1
  change_ref: <change id>
  required_with_change:
    - path: .sdcorejs/product/prds/<feature>.md
      kind: product-doc
    - path: .sdcorejs/product/user-stories/<feature>.md
      kind: product-doc
    - path: .sdcorejs/product/acceptance-criteria/<feature>.md
      kind: product-doc
    - path: .sdcorejs/product/uat-checklists/<feature>.md
      kind: product-doc
    - path: .sdcorejs/product/decisions/<feature>.md
      kind: product-doc
    - path: .sdcorejs/docs/product/<feature>.md
      kind: product-ledger
```

Never emit only the ledger while omitting PRD, user stories, acceptance
criteria, UAT, or decisions from artifact closure.

A cross-module Product view may belong to the portal integration owner only as
`view_kind: cross-module-view` with `editable_requirements: false`. It must
reference module artifacts with repository/module/path/revision/artifact-hash
provenance and a source-owned `acceptance_criterion_id: AC-001` in canonical
zero-padded positive-integer form, and never duplicate their editable
requirements. Preserve that identity verbatim: reordering or inserting module
references must not reassign existing criteria. Missing, noncanonical, or
duplicate `acceptance_criterion_id` values fail closed and block generation.

## Human-Readable Doc Templates

Every durable Product Markdown document carries lifecycle frontmatter using the
shared vocabulary from `_refs/shared/artifact-lifecycle.md`. Do not invent a
Product-only lifecycle vocabulary.

```yaml
---
artifact_id: product-doc:<kind>:<kebab-feature>
artifact_kind: product-doc
change_ref: <change id>
source_spec: <repo-relative path | none>
source_plan: <repo-relative path | none>
commit_policy: with-change
owner: sdcorejs-product
---
```

`<kind>` is `prd`, `user-stories`, `acceptance-criteria`, `uat-checklist`, or
`decisions`. Prepend this block to each template below.

### PRD

```markdown
# PRD - <Feature Title>

## Problem
<The user/business problem.>

## Goal
<Outcome the software should create.>

## Users
- <role> - <need>

## Scope
- <included capability>

## Out Of Scope
- <explicit non-goal>

## Success Criteria
- <observable result>
```

### User Stories

```markdown
# User Stories - <Feature Title>

| ID | As a | I want to | So that | Priority | Acceptance Criteria |
|---|---|---|---|---|---|
| US1 | <role> | <action> | <benefit> | Must | AC-001, AC-002 |
```

### Acceptance Criteria

```markdown
# Acceptance Criteria - <Feature Title>

| ID | User Story | Criterion | Verification | Status |
|---|---|---|---|---|
| AC-001 | US1 | <observable behavior> | unit / integration / e2e / UAT | agreed |
```

### UAT Checklist

```markdown
# UAT Checklist - <Feature Title>

| Scenario | Steps | Expected Result | Owner | Status |
|---|---|---|---|---|
| <scenario> | <manual steps> | <visible result> | PO / QC | pending |
```

### Decisions

```markdown
# Decisions - <Feature Title>

| Date | Decision | Reason | Impact |
|---|---|---|---|
| <date> | <decision> | <why> | <affected tracks> |
```

## Ledger Template

```markdown
---
schema_version: 1
artifact_id: product-ledger:<feature>
artifact_kind: product-ledger
contract_id: <contract id>
requirement_id: <requirement id>
change_ref: <change id>
feature: <kebab-feature>
status: draft | planned | implemented | verified | partial
track: <canonical registry track>
stack_profile: <canonical registry profile>
owner_repository_id: <stable repository id>
owner_repository_role: <registry repository role>
owner_module_id: <module id | null>
ownership_scope: <registry ownership scope>
repository_relative_path: .sdcorejs/docs/product/<kebab-feature>.md
source_revision: <40-character Git revision>
parent_references: []
supersedes: <artifact id | null>
approval_hash: <sha256:v1 hash when applicable | null>
artifact_hash: <sha256:v1 hash>
source_spec: <relative path or none>
source_plan: <relative path or none>
prd_path: .sdcorejs/product/prds/<kebab-feature>.md
user_stories_path: .sdcorejs/product/user-stories/<kebab-feature>.md
acceptance_criteria_path: .sdcorejs/product/acceptance-criteria/<kebab-feature>.md
uat_checklist_path: .sdcorejs/product/uat-checklists/<kebab-feature>.md
decisions_path: .sdcorejs/product/decisions/<kebab-feature>.md
updated_at: <ISO-8601 timestamp>
commit_policy: with-change
owner: sdcorejs-product
---

# Product Feature Ledger - <Title>

## Business Goal
<Why this matters and who benefits.>

## Users And Scenarios
- <user role> can <goal> so that <outcome>.

## Requirement Contract
| ID | Requirement / Acceptance Criterion | Priority | Source | Status |
|---|---|---|---|---|
| AC-001 | <criterion> | Must | spec/user | agreed |

## Traceability Map
| Requirement | AC | Design | Plan | Implementation | Test | Evidence | Delivery |
|---|---|---|---|---|---|---|---|
| <requirement id/ref> | AC-001 | <handoff ref or missing> | <plan ref or missing> | <repository/path/revision or missing> | <test ref or missing> | <class/result/revision or missing> | draft / planned / implemented / verified / partial / stale / blocked / deferred |

## UAT Checklist
| Scenario | Steps | Expected Result | Owner | Status |
|---|---|---|---|---|
| <business scenario> | <manual steps or link to test> | <observable result> | PO / QC | pending / pass / fail / deferred |

## Gap Review
- Requirement gaps:
- Design gaps:
- Plan gaps:
- Implementation gaps:
- Test gaps:
- Evidence freshness gaps:
- Ambiguities:

## Decisions
- <decision and reason>

## Open Questions
- <question or "None">

## Related Docs
- PRD: .sdcorejs/product/prds/<kebab-feature>.md
- User stories: .sdcorejs/product/user-stories/<kebab-feature>.md
- Acceptance criteria: .sdcorejs/product/acceptance-criteria/<kebab-feature>.md
- UAT checklist: .sdcorejs/product/uat-checklists/<kebab-feature>.md
- Decisions: .sdcorejs/product/decisions/<kebab-feature>.md
- Design handoff: .sdcorejs/design/specs/<kebab-feature>.md
- Spec: <path>
- Plan: <path>
- Change execution records: <path>
```

## Legacy Layout Compatibility

Older target projects keep Product documents in a root-level `product/**`
directory. That layout is a read-only compatibility input; it is never a write
target.

1. New writes always use `.sdcorejs/product/**`.
2. Canonical paths are always preferred for reads.
3. A legacy path is read only when no canonical equivalent exists.
4. Never create a second canonical copy silently.
5. When the user asks to update a legacy-only Product artifact, migrate that
   feature bundle to `.sdcorejs/product/**` inside the same approved change and
   update every internal reference, including ledger metadata.
6. Never bulk-migrate unrelated historical artifacts. Migration scope is the
   requested feature bundle.
7. When canonical and legacy copies both exist for the same logical identity:
   equivalent copies must not both remain editable, so retire the legacy copy in
   the same change; conflicting copies block with an explicit ambiguity, and
   competing requirement sources are never silently merged.
8. Portal fallback remains forbidden during migration. The module owner still
   owns module-specific Product artifacts.
9. Preserve repository ownership, artifact identity, source revisions, approval
   hashes, artifact hashes, and `supersedes` semantics across the move.
10. Never write a legacy path into newly generated metadata.

Use `planProductArtifactMigration` in `_refs/shared/product-ledger.mjs`. It
returns `not-required`, `migration-required`, or `blocked` plus the exact
`migrations`, `retirements`, `conflicts`, and blockers.

## Audit Rules

For each acceptance criterion:

1. It must map to at least one implementation artifact or a deliberate "not implemented" decision.
2. It must map to at least one verification artifact: unit, integration, e2e, UAT, or explicit manual check.
3. Preserve applicable Design and approved Plan references without copying
   their bodies or taking ownership of them.
4. Compare evidence revision with the current owner repository revision.
   Mismatches are `STALE`/`stale`, never pass.
5. If implementation exists with no requirement, mark it as scope creep.
6. If test exists with no requirement, mark it as orphan coverage.
7. If requirement exists with no implementation, current test, or current
   evidence, mark it as a blocker before `verified` unless the user explicitly
   defers it. Missing test/evidence is not pass.

Status vocabulary:

- `done`: requirement, implementation, and test evidence all align.
- `verified`: requirement, implementation, test, and current `PASSED` evidence align.
- `partial`: one side is present but incomplete.
- `missing`: no matching artifact.
- `stale`: evidence is bound to an older repository revision.
- `deferred`: user explicitly postponed it.
- `n/a`: not applicable and explained.

## Report Format

Load `_refs/product/traceability-report.md` for the concise AC/implementation/test
report. Display canonical paths and only real gaps.

## Rules

### Must Do

- Write product docs to the target project, never to the `sdcorejs-agent` repo unless it is the explicit target.
- Write every Product document under `.sdcorejs/product/**` and every ledger
  under `.sdcorejs/docs/product/**`.
- Resolve paths through `resolveProductLedgerTarget`; never hardcode a Product
  root in prose or output.
- Keep `.sdcorejs/product/` docs and the `.sdcorejs/docs/product/` ledger in sync for the same feature.
- Emit every created or updated Product document plus the ledger in
  `artifact_context.required_with_change`.
- Preserve the user's language for prose.
- Keep identifiers, route paths, permission codes, and env keys in English.
- Link PRDs, user stories, specs, plans, changed files, and test outputs by path instead of pasting full file contents.
- Preserve requirement, acceptance criterion, Design, Plan, implementation,
  Test, evidence, and delivery references with stable artifact/repository
  identity and exact revisions.
- Treat requirement/implementation/test mismatch as a product gap, not just a testing gap.
- Mark inferred requirements as "inferred - needs confirmation" unless already approved.
- In Task-breakdown mode, check every draft and file with the check CLI; write `tasks/<scope>.md` only after the proposal is approved.

### Must Not

- Generate app code.
- Invent acceptance criteria to make a trace look complete.
- Claim a feature is covered without current evidence.
- Hide deferred or missing tests.
- Treat stale evidence as pass.
- Overwrite an unrelated product ledger.
- Duplicate editable module requirements in a portal or cross-module view.
- Write application code, a replacement spec/plan, or Test-owned evidence.
- Create or update a root-level `product/**` path.
- Emit a root-level `product/**` path in new or updated metadata, reports, or
  links.
- Keep an editable legacy copy alongside an equivalent canonical copy.
- Silently merge conflicting canonical and legacy requirement sources.
- Update `.sdcorejs/docs/product/` without updating the matching `.sdcorejs/product/` docs when the user-facing requirement changed.
- Write to a tracker without an approved write plan of the current run, delete
  a ticket, change its status, store a secret, or invent an unread source.
- Never treat a menu choice as write-plan approval. Never overwrite a whole ticket description.

## Cross-references

- `sdcorejs-brainstorming` - confirms requirements.
- `sdcorejs-spec` - source of approved acceptance criteria.
- `sdcorejs-plan` - source of planned implementation and verification.
- `sdcorejs-design` - reads `.sdcorejs/product/**` and maps product stories and acceptance criteria to screens, wireframes, PNG previews, and FE handoff under `.sdcorejs/design/**`.
- `_refs/shared/artifact-paths.mjs` - single canonical source for Product and Design roots.
- `sdcorejs-test` - source of test evidence.
- `sdcorejs-ship (verify-before-done mode)` - final acceptance gate; product gaps should be resolved or deferred before done.
